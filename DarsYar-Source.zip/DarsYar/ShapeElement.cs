using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using DarsYar.Services;
using ShapePath = System.Windows.Shapes.Path;

namespace DarsYar;

public interface IShapeHost
{
    void ShapeChanged();
    void ShapeSelected(ShapeElement element);
    void ShapeDeleteRequested(ShapeElement element);
    Point MouseInLayer();
}

/// <summary>
/// An editable geometric shape on a page: drag to move, 8 handles to resize, round handle to rotate (360°),
/// colour / fill / thickness changeable. Handles are shown only while the shape is selected.
/// </summary>
public sealed class ShapeElement : Grid
{
    private const double HandleSize = 22;
    private const double MinSize = 12;

    public ShapeItem Item { get; }
    public bool IsSelected { get; private set; }

    private readonly IShapeHost _host;
    private readonly ShapePath _path = new();
    private readonly Border _frame = new();
    private readonly Thumb _body = new();
    private readonly List<(Thumb Thumb, int Hx, int Hy)> _handles = new();
    private Thumb _rotate = null!;
    private Button _close = null!;

    public ShapeElement(ShapeItem item, IShapeHost host)
    {
        Item = item;
        _host = host;
        RenderTransformOrigin = new Point(0.5, 0.5);

        _path.StrokeLineJoin = PenLineJoin.Round;
        _path.StrokeStartLineCap = PenLineCap.Round;
        _path.StrokeEndLineCap = PenLineCap.Round;
        _path.IsHitTestVisible = false;

        _frame.BorderBrush = new SolidColorBrush(Color.FromRgb(37, 99, 235));
        _frame.BorderThickness = new Thickness(1);
        _frame.IsHitTestVisible = false;

        _body.Template = MakeTemplate("Rectangle", false);
        _body.Background = Brushes.Transparent;
        _body.Cursor = Cursors.SizeAll;
        _body.PreviewMouseLeftButtonDown += (_, _) => _host.ShapeSelected(this);
        _body.DragDelta += (_, e) => MoveBy(e.HorizontalChange, e.VerticalChange);
        _body.DragCompleted += (_, _) => _host.ShapeChanged();

        Children.Add(_path);
        Children.Add(_frame);
        Children.Add(_body);

        foreach (var (hx, hy) in new[] { (-1, -1), (0, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (0, 1), (1, 1) })
            AddResizeHandle(hx, hy);
        AddRotateHandle();
        AddCloseButton();

        UpdateStyle();
        ApplyLayout();
        SetSelected(false);
    }

    private static ControlTemplate MakeTemplate(string shape, bool outline)
    {
        string stroke = outline ? " Stroke='White' StrokeThickness='2'" : "";
        return (ControlTemplate)XamlReader.Parse(
            "<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='Thumb'>" +
            "<" + shape + " Fill='{TemplateBinding Background}'" + stroke + "/></ControlTemplate>");
    }

    private bool LineLike => ShapeBuilder.IsLineLike(Item.Kind);

    // ------------------------------------------------------------------ layout & style

    public void ApplyLayout()
    {
        Width = Item.W;
        Height = Item.H;
        Canvas.SetLeft(this, Item.X);
        Canvas.SetTop(this, Item.Y);
        RenderTransform = new RotateTransform(Item.Angle);
        RebuildGeometry();
    }

    private void RebuildGeometry() =>
        _path.Data = ShapeBuilder.CreateGeometry(Item.Kind, Math.Max(1, Item.W), Math.Max(1, Item.H),
            Item.Thickness, ShapeBuilder.CanFill(Item.Kind));

    private static Color ParseColor(string? s, Color fallback)
    {
        try { return string.IsNullOrEmpty(s) ? fallback : (Color)ColorConverter.ConvertFromString(s); }
        catch { return fallback; }
    }

    private void UpdateStyle()
    {
        _path.Stroke = new SolidColorBrush(ParseColor(Item.Stroke, Colors.Black));
        _path.StrokeThickness = Item.Thickness;
        _path.Fill = (Item.Fill != null && ShapeBuilder.CanFill(Item.Kind))
            ? new SolidColorBrush(ParseColor(Item.Fill, Colors.Transparent))
            : null;
    }

    public void SetStrokeColor(Color c) { Item.Stroke = c.ToString(); UpdateStyle(); _host.ShapeChanged(); }
    public void SetFill(Color? c) { Item.Fill = c?.ToString(); UpdateStyle(); _host.ShapeChanged(); }

    public void SetThickness(double t)
    {
        Item.Thickness = Math.Clamp(t, 1, 40);
        UpdateStyle();
        RebuildGeometry();
        _host.ShapeChanged();
    }

    public void SetSelected(bool selected)
    {
        IsSelected = selected;
        var v = selected ? Visibility.Visible : Visibility.Collapsed;
        _frame.Visibility = v;
        foreach (var (thumb, _, hy) in _handles)
            thumb.Visibility = selected && !(LineLike && hy != 0) ? Visibility.Visible : Visibility.Collapsed;
        _handles.ForEach(h => { if (LineLike && h.Hx != 0 && h.Hy != 0) h.Thumb.Visibility = Visibility.Collapsed; });
        _rotate.Visibility = v;
        _close.Visibility = v;
    }

    // ------------------------------------------------------------------ interaction

    private (double C, double S) Rot()
    {
        double a = Item.Angle * Math.PI / 180.0;
        return (Math.Cos(a), Math.Sin(a));
    }

    private void MoveBy(double dx, double dy)
    {
        var (c, s) = Rot();      // thumb deltas are in the rotated local frame
        Item.X += dx * c - dy * s;
        Item.Y += dx * s + dy * c;
        ApplyLayout();
    }

    private void ResizeBy(int hx, int hy, double dx, double dy)
    {
        double newW = Item.W, newH = Item.H;
        if (hx != 0) newW = Math.Max(MinSize, Item.W + hx * dx);
        if (hy != 0 && !LineLike) newH = Math.Max(MinSize, Item.H + hy * dy);

        double effDx = (newW - Item.W) * hx;      // growth towards the dragged side
        double effDy = (newH - Item.H) * hy;
        var (c, s) = Rot();
        double lx = effDx / 2, ly = effDy / 2;    // centre moves half-way, in the local frame
        double cx = Item.X + Item.W / 2 + (lx * c - ly * s);
        double cy = Item.Y + Item.H / 2 + (lx * s + ly * c);

        Item.W = newW;
        Item.H = newH;
        Item.X = cx - newW / 2;
        Item.Y = cy - newH / 2;
        ApplyLayout();
    }

    private void RotateToMouse()
    {
        var p = _host.MouseInLayer();
        double cx = Item.X + Item.W / 2, cy = Item.Y + Item.H / 2;
        double ang = Math.Atan2(p.Y - cy, p.X - cx) * 180.0 / Math.PI + 90.0;   // handle sits above the shape
        if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) ang = Math.Round(ang / 15.0) * 15.0;
        while (ang < 0) ang += 360;
        while (ang >= 360) ang -= 360;
        Item.Angle = ang;
        ApplyLayout();
    }

    // ------------------------------------------------------------------ handles

    private static Cursor CursorFor(int hx, int hy) =>
        hx == 0 ? Cursors.SizeNS : hy == 0 ? Cursors.SizeWE : (hx == hy ? Cursors.SizeNWSE : Cursors.SizeNESW);

    private void AddResizeHandle(int hx, int hy)
    {
        double h = HandleSize / 2;
        var t = new Thumb
        {
            Template = MakeTemplate("Rectangle", true),
            Width = HandleSize,
            Height = HandleSize,
            Background = new SolidColorBrush(Color.FromArgb(220, 37, 99, 235)),
            Cursor = CursorFor(hx, hy),
            HorizontalAlignment = hx < 0 ? HorizontalAlignment.Left : hx > 0 ? HorizontalAlignment.Right : HorizontalAlignment.Center,
            VerticalAlignment = hy < 0 ? VerticalAlignment.Top : hy > 0 ? VerticalAlignment.Bottom : VerticalAlignment.Center,
            Margin = new Thickness(hx < 0 ? -h : 0, hy < 0 ? -h : 0, hx > 0 ? -h : 0, hy > 0 ? -h : 0)
        };
        t.DragStarted += (_, _) => _host.ShapeSelected(this);
        t.DragDelta += (_, e) => ResizeBy(hx, hy, e.HorizontalChange, e.VerticalChange);
        t.DragCompleted += (_, _) => _host.ShapeChanged();
        _handles.Add((t, hx, hy));
        Children.Add(t);
    }

    private void AddRotateHandle()
    {
        _rotate = new Thumb
        {
            Template = MakeTemplate("Ellipse", true),
            Width = HandleSize,
            Height = HandleSize,
            Background = new SolidColorBrush(Color.FromArgb(230, 245, 158, 11)),
            Cursor = Cursors.Hand,
            ToolTip = "چرخش (با Shift هر ۱۵ درجه)",
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Top,
            Margin = new Thickness(0, -(HandleSize + 24), 0, 0)
        };
        _rotate.DragStarted += (_, _) => _host.ShapeSelected(this);
        _rotate.DragDelta += (_, _) => RotateToMouse();
        _rotate.DragCompleted += (_, _) => _host.ShapeChanged();
        Children.Add(_rotate);
    }

    private void AddCloseButton()
    {
        _close = new Button
        {
            Content = "✕",
            Width = HandleSize,
            Height = HandleSize,
            Padding = new Thickness(0),
            Background = new SolidColorBrush(Color.FromArgb(230, 220, 38, 38)),
            Foreground = Brushes.White,
            BorderThickness = new Thickness(0),
            ToolTip = "حذف شکل",
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Top,
            Margin = new Thickness(0, -(HandleSize + 24), -HandleSize / 2, 0)
        };
        _close.Click += (_, _) => _host.ShapeDeleteRequested(this);
        Children.Add(_close);
    }
}
