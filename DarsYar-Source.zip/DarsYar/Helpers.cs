using System.Windows;

namespace DarsYar;

public static class AppPaths
{
    public static string DataDir { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DarsYar");

    public static string DbFile => Path.Combine(DataDir, "darsyar.db");
    public static string LogFile => Path.Combine(DataDir, "error.log");

    public static void LogError(Exception? ex)
    {
        if (ex == null) return;
        try
        {
            Directory.CreateDirectory(DataDir);
            File.AppendAllText(LogFile, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex}\n\n");
        }
        catch { /* logging must never crash the app */ }
    }
}

public static class Dialogs
{
    private const MessageBoxOptions Rtl = MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign;

    public static void Error(Window? owner, string message) =>
        Show(owner, message, MessageBoxImage.Error);

    public static void Info(Window? owner, string message) =>
        Show(owner, message, MessageBoxImage.Information);

    public static bool Confirm(Window? owner, string message) =>
        MessageBox.Show(owner ?? Application.Current.MainWindow, message, "درس‌یار",
            MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No, Rtl) == MessageBoxResult.Yes;

    /// <summary>Yes = save, No = discard unsaved changes, Cancel = stay open.</summary>
    public static MessageBoxResult AskSave(Window? owner, string message) =>
        MessageBox.Show(owner ?? Application.Current.MainWindow, message, "درس‌یار",
            MessageBoxButton.YesNoCancel, MessageBoxImage.Question, MessageBoxResult.Yes, Rtl);

    private static void Show(Window? owner, string message, MessageBoxImage icon)
    {
        var w = owner ?? Application.Current?.MainWindow;
        if (w != null)
            MessageBox.Show(w, message, "درس‌یار", MessageBoxButton.OK, icon, MessageBoxResult.OK, Rtl);
        else
            MessageBox.Show(message, "درس‌یار", MessageBoxButton.OK, icon, MessageBoxResult.OK, Rtl);
    }
}

/// <summary>Pure geometry helpers (unit-tested).</summary>
public static class ViewMath
{
    public const double MinZoom = 0.2;
    public const double MaxZoom = 6.0;

    public static double Clamp(double z) => Math.Min(MaxZoom, Math.Max(MinZoom, z));

    public static double FitWidth(double viewWidth, double pageWidth, double margin = 48)
        => pageWidth <= 0 ? 1 : Clamp((viewWidth - margin) / pageWidth);

    public static double FitPage(double viewWidth, double viewHeight, double pageWidth, double pageHeight, double margin = 48)
    {
        if (pageWidth <= 0 || pageHeight <= 0) return 1;
        return Clamp(Math.Min((viewWidth - margin) / pageWidth, (viewHeight - margin) / pageHeight));
    }

    /// <summary>Screen (zoomed) coordinates -> stable page coordinates.</summary>
    public static (double X, double Y) ViewToPage(double vx, double vy, double zoom) => (vx / zoom, vy / zoom);

    /// <summary>Stable page coordinates -> screen (zoomed) coordinates.</summary>
    public static (double X, double Y) PageToView(double px, double py, double zoom) => (px * zoom, py * zoom);
}
