using System.Windows;
using System.Windows.Media;

namespace DarsYar;

public static class ThemeManager
{
    public static void Apply(bool dark)
    {
        var r = Application.Current.Resources;
        Set(r, "Bg", dark ? "#111827" : "#F3F4F6");
        Set(r, "PanelBg", dark ? "#1F2937" : "#FFFFFF");
        Set(r, "Fg", dark ? "#F9FAFB" : "#1F2937");
        Set(r, "ViewerBg", dark ? "#374151" : "#CBD5E1");
        Set(r, "Accent", dark ? "#3B82F6" : "#2563EB");
        Set(r, "Line", dark ? "#4B5563" : "#CBD5E1");
    }

    private static void Set(ResourceDictionary r, string key, string hex) =>
        r[key] = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
}
