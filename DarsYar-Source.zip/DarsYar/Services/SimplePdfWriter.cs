using System.Globalization;
using System.Text;

namespace DarsYar.Services;

/// <summary>
/// Minimal PDF writer: one JPEG image per page (DCTDecode). No third-party dependency.
/// Output pages are images (the original text layer is NOT preserved in this version).
/// </summary>
public sealed class SimplePdfWriter
{
    private readonly Stream _out;
    private readonly Dictionary<int, long> _offsets = new();
    private long _pos;
    private int _pages;
    private bool _finished;

    public int PageCount => _pages;

    public SimplePdfWriter(Stream output)
    {
        _out = output;
        WriteBytes(new byte[] { 0x25, 0x50, 0x44, 0x46, 0x2D, 0x31, 0x2E, 0x34, 0x0A, 0x25, 0xE2, 0xE3, 0xCF, 0xD3, 0x0A });
    }

    private static string F(double d) => d.ToString("0.###", CultureInfo.InvariantCulture);

    private void WriteBytes(byte[] b)
    {
        _out.Write(b, 0, b.Length);
        _pos += b.Length;
    }

    private void Write(string s) => WriteBytes(Encoding.ASCII.GetBytes(s));

    private void BeginObj(int n)
    {
        _offsets[n] = _pos;
        Write(n + " 0 obj\n");
    }

    public void AddJpegPage(byte[] jpeg, int pixelWidth, int pixelHeight, double pointWidth, double pointHeight)
    {
        if (_finished) throw new InvalidOperationException("PDF already finished.");
        int pageObj = 3 + 3 * _pages;
        int contentObj = pageObj + 1;
        int imageObj = pageObj + 2;

        string content = $"q {F(pointWidth)} 0 0 {F(pointHeight)} 0 0 cm\n/Im0 Do\nQ\n";

        BeginObj(pageObj);
        Write($"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {F(pointWidth)} {F(pointHeight)}] " +
              $"/Resources << /XObject << /Im0 {imageObj} 0 R >> /ProcSet [/PDF /ImageC] >> /Contents {contentObj} 0 R >>\nendobj\n");

        BeginObj(contentObj);
        Write($"<< /Length {content.Length} >>\nstream\n{content}endstream\nendobj\n");

        BeginObj(imageObj);
        Write($"<< /Type /XObject /Subtype /Image /Width {pixelWidth} /Height {pixelHeight} " +
              $"/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length {jpeg.Length} >>\nstream\n");
        WriteBytes(jpeg);
        Write("\nendstream\nendobj\n");

        _pages++;
    }

    public void Finish()
    {
        if (_finished) return;
        _finished = true;

        BeginObj(1);
        Write("<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");

        var kids = new StringBuilder();
        for (int i = 0; i < _pages; i++) kids.Append(3 + 3 * i).Append(" 0 R ");
        BeginObj(2);
        Write($"<< /Type /Pages /Count {_pages} /Kids [ {kids}] >>\nendobj\n");

        int total = 3 + 3 * _pages; // objects 0..total-1
        long xrefPos = _pos;
        var xref = new StringBuilder();
        xref.Append("xref\n0 ").Append(total).Append('\n');
        xref.Append("0000000000 65535 f \n");
        for (int n = 1; n < total; n++)
            xref.Append(_offsets[n].ToString("D10", CultureInfo.InvariantCulture)).Append(" 00000 n \n");
        Write(xref.ToString());
        Write($"trailer\n<< /Size {total} /Root 1 0 R >>\nstartxref\n{xrefPos}\n%%EOF\n");
        _out.Flush();
    }
}
