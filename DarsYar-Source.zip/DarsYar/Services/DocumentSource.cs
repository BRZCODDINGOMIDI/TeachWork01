using System.Windows;
using System.Windows.Media.Imaging;
using Windows.Data.Pdf;
using Windows.Storage;
using Windows.Storage.Streams;

namespace DarsYar.Services;

/// <summary>
/// Abstraction over "a document that has pages": PDF (Windows built-in renderer, offline,
/// no third-party license) or a single image. Page sizes are in 96-dpi device-independent units.
/// </summary>
public abstract class DocumentSource : IDisposable
{
    public abstract string Type { get; }
    public abstract int PageCount { get; }
    public abstract Task<Size> GetPageSizeAsync(int index);
    public abstract Task<BitmapSource> RenderAsync(int index, double scale);
    public virtual void Dispose() { }

    public static readonly string[] SupportedExtensions = { ".pdf", ".jpg", ".jpeg", ".png", ".bmp" };

    public static bool IsSupported(string path) =>
        SupportedExtensions.Contains(Path.GetExtension(path).ToLowerInvariant());

    public static async Task<DocumentSource> OpenAsync(string path)
    {
        var ext = Path.GetExtension(path).ToLowerInvariant();
        if (ext == ".pdf") return await PdfDocumentSource.CreateAsync(path);
        if (ext is ".jpg" or ".jpeg" or ".png" or ".bmp") return await ImageDocumentSource.CreateAsync(path);
        throw new NotSupportedException("فرمت فایل پشتیبانی نمی‌شود: " + ext);
    }

    internal static BitmapSource Decode(byte[] bytes)
    {
        var bi = new BitmapImage();
        bi.BeginInit();
        bi.CacheOption = BitmapCacheOption.OnLoad;
        bi.StreamSource = new MemoryStream(bytes);
        bi.EndInit();
        bi.Freeze();
        return bi;
    }
}

public sealed class PdfDocumentSource : DocumentSource
{
    private readonly PdfDocument _doc;
    // Windows.Data.Pdf allows only one open page per document at a time -> serialize all access.
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly Dictionary<int, Size> _sizes = new();

    private PdfDocumentSource(PdfDocument doc) { _doc = doc; }

    public override string Type => "pdf";
    public override int PageCount => (int)_doc.PageCount;

    public static async Task<PdfDocumentSource> CreateAsync(string path)
    {
        var file = await StorageFile.GetFileFromPathAsync(path);
        var doc = await PdfDocument.LoadFromFileAsync(file);
        return new PdfDocumentSource(doc);
    }

    public override async Task<Size> GetPageSizeAsync(int index)
    {
        lock (_sizes) { if (_sizes.TryGetValue(index, out var s)) return s; }
        await _gate.WaitAsync();
        try
        {
            using var page = _doc.GetPage((uint)index);
            var size = new Size(page.Size.Width, page.Size.Height);
            lock (_sizes) { _sizes[index] = size; }
            return size;
        }
        finally { _gate.Release(); }
    }

    public override async Task<BitmapSource> RenderAsync(int index, double scale)
    {
        byte[] bytes;
        await _gate.WaitAsync();
        try
        {
            using var page = _doc.GetPage((uint)index);
            var opt = new PdfPageRenderOptions
            {
                DestinationWidth = (uint)Math.Max(1, Math.Round(page.Size.Width * scale)),
                DestinationHeight = (uint)Math.Max(1, Math.Round(page.Size.Height * scale))
            };
            using var ms = new InMemoryRandomAccessStream();
            await page.RenderToStreamAsync(ms, opt);
            bytes = await ReadAllAsync(ms);
        }
        finally { _gate.Release(); }
        return await Task.Run(() => Decode(bytes));
    }

    private static async Task<byte[]> ReadAllAsync(InMemoryRandomAccessStream ms)
    {
        uint size = (uint)ms.Size;
        using var reader = new DataReader(ms.GetInputStreamAt(0));
        await reader.LoadAsync(size);
        var bytes = new byte[size];
        reader.ReadBytes(bytes);
        return bytes;
    }
}

public sealed class ImageDocumentSource : DocumentSource
{
    private readonly BitmapSource _image;
    private ImageDocumentSource(BitmapSource image) { _image = image; }

    public override string Type => "image";
    public override int PageCount => 1;

    public static async Task<ImageDocumentSource> CreateAsync(string path)
    {
        var bytes = await Task.Run(() => File.ReadAllBytes(path));
        var img = await Task.Run(() => Decode(bytes));
        return new ImageDocumentSource(img);
    }

    public override Task<Size> GetPageSizeAsync(int index)
    {
        double w = _image.Width > 0 ? _image.Width : _image.PixelWidth;
        double h = _image.Height > 0 ? _image.Height : _image.PixelHeight;
        return Task.FromResult(new Size(w, h));
    }

    public override Task<BitmapSource> RenderAsync(int index, double scale) => Task.FromResult(_image);
}
