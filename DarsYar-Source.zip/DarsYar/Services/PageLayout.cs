namespace DarsYar.Services;

/// <summary>Builds the flattened page list: original pages plus user-inserted blank pages.</summary>
public static class PageLayout
{
    public static string OriginalKey(int index) => "p" + index;
    public static string BlankKey(string id) => "b" + id;

    public static List<PageEntry> Build(IReadOnlyList<(double W, double H)> originals, IReadOnlyList<BlankRecord> blanks)
    {
        // followers of a page key, newest first (so a new blank sits right after the page it was added to)
        var followers = blanks
            .GroupBy(b => b.AfterKey)
            .ToDictionary(g => g.Key, g => g.OrderByDescending(b => b.Seq).ToList());

        var result = new List<PageEntry>();
        var seen = new HashSet<string>();

        void Emit(string key)
        {
            if (!followers.TryGetValue(key, out var list)) return;
            foreach (var b in list)
            {
                if (!seen.Add(b.Id)) continue;
                var bk = BlankKey(b.Id);
                result.Add(new PageEntry { Key = bk, IsBlank = true, BlankId = b.Id, Width = b.W, Height = b.H });
                Emit(bk);
            }
        }

        for (int i = 0; i < originals.Count; i++)
        {
            result.Add(new PageEntry
            {
                Key = OriginalKey(i), IsBlank = false, SourceIndex = i,
                Width = originals[i].W, Height = originals[i].H
            });
            Emit(OriginalKey(i));
        }
        return result;
    }
}
