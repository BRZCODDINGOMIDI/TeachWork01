using System.Globalization;
using System.Windows;
using System.Windows.Ink;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DarsYar.Services;

/// <summary>
/// Builds a NEW pdf: every page = original page (or blank page) + images + ink + notes, flattened to JPEG.
/// The original file is never opened for writing. Must run on the UI thread (WPF rendering).
/// </summary>
public static class ExportService
{
    /// <summary>Render scale relative to 96-dpi page size. 2.5 ≈ 240 dpi.</summary>
    public const double PageScale = 2.5;
    public const int JpegQuality = 88;

    public static async Task ExportAsync(
        DocumentSource source, Database db, string docId, IReadOnlyList<PageEntry> entries, string destPath,
        IProgress<(int Done, int Total)>? progress, CancellationToken ct)
    {
        string tmp = destPath + ".tmp";
        try
        {
            using (var fs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                var writer = new SimplePdfWriter(fs);
                int n = entries.Count;
                for (int i = 0; i < n; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    var e = entries[i];
                    Size size;
                    BitmapSource? bg = null;
                    if (e.IsBlank)
                    {
                        size = new Size(e.Width, e.Height);
                    }
                    else
                    {
                        size = await source.GetPageSizeAsync(e.SourceIndex);
                        bg = await source.RenderAsync(e.SourceIndex, PageScale);
                    }
                    var (ink, notes) = db.LoadPage(docId, e.Key);

                    int pw = Math.Max(1, (int)Math.Round(size.Width * PageScale));
                    int ph = Math.Max(1, (int)Math.Round(size.Height * PageScale));
                    byte[] jpeg = ComposePage(db, bg, size, pw, ph, ink, notes);
                    writer.AddJpegPage(jpeg, pw, ph, size.Width * 0.75, size.Height * 0.75);

                    progress?.Report((i + 1, n));
                    await Task.Delay(1, ct); // let the UI breathe
                }
                writer.Finish();
            }
            File.Move(tmp, destPath, true);
        }
        catch
        {
            try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
            throw;
        }
    }

    private static byte[] ComposePage(Database db, BitmapSource? bg, Size size, int pw, int ph, byte[]? ink, string? notesJson)
    {
        var extras = PageExtras.Parse(notesJson);
        var dv = new DrawingVisual();
        using (var dc = dv.RenderOpen())
        {
            var rect = new Rect(0, 0, size.Width, size.Height);
            dc.DrawRectangle(Brushes.White, null, rect);
            if (bg != null) dc.DrawImage(bg, rect);

            // same stacking order as on screen: images, ink, notes
            foreach (var img in extras.Images)
            {
                var bytes = db.LoadImage(img.Id);
                if (bytes == null) continue;
                try { dc.DrawImage(DocumentSource.Decode(bytes), new Rect(img.X, img.Y, img.W, img.H)); }
                catch { /* skip undecodable image */ }
            }

            foreach (var sh in extras.Shapes) DrawShape(dc, sh);

            if (ink != null && ink.Length > 0)
            {
                using var ms = new MemoryStream(ink);
                new StrokeCollection(ms).Draw(dc);
            }

            foreach (var n in extras.Notes) DrawNote(dc, n);
        }

        double dpiX = 96.0 * pw / size.Width;
        double dpiY = 96.0 * ph / size.Height;
        var rtb = new RenderTargetBitmap(pw, ph, dpiX, dpiY, PixelFormats.Pbgra32);
        rtb.Render(dv);

        var enc = new JpegBitmapEncoder { QualityLevel = JpegQuality };
        enc.Frames.Add(BitmapFrame.Create(rtb));
        using var o = new MemoryStream();
        enc.Save(o);
        return o.ToArray();
    }

    private static Color ParseColor(string? s, Color fallback)
    {
        try { return string.IsNullOrEmpty(s) ? fallback : (Color)ColorConverter.ConvertFromString(s); }
        catch { return fallback; }
    }

    private static void DrawShape(DrawingContext dc, ShapeItem sh)
    {
        var geo = ShapeBuilder.CreateGeometry(sh.Kind, Math.Max(1, sh.W), Math.Max(1, sh.H), sh.Thickness,
            ShapeBuilder.CanFill(sh.Kind));
        var stroke = new SolidColorBrush(ParseColor(sh.Stroke, Colors.Black));
        var pen = new Pen(stroke, sh.Thickness) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round, LineJoin = PenLineJoin.Round };
        Brush? fill = (sh.Fill != null && ShapeBuilder.CanFill(sh.Kind))
            ? new SolidColorBrush(ParseColor(sh.Fill, Colors.Transparent)) : null;

        dc.PushTransform(new TranslateTransform(sh.X, sh.Y));
        dc.PushTransform(new RotateTransform(sh.Angle, sh.W / 2, sh.H / 2));
        dc.DrawGeometry(fill, pen, geo);
        dc.Pop();
        dc.Pop();
    }

    private static void DrawNote(DrawingContext dc, NoteItem n)
    {
        double w = n.W > 0 ? n.W : 200;
        var ft = new FormattedText(
            n.Text ?? "", CultureInfo.GetCultureInfo("fa-IR"), FlowDirection.RightToLeft,
            new Typeface("Segoe UI"), 16, Brushes.Black, 1.0)
        {
            MaxTextWidth = Math.Max(40, w - 12),
            TextAlignment = TextAlignment.Right
        };
        double top = n.Y + NoteItem.HeaderHeight;
        var box = new Rect(n.X, top, w, ft.Height + 12);
        dc.DrawRectangle(new SolidColorBrush(Color.FromRgb(255, 249, 196)),
            new Pen(new SolidColorBrush(Color.FromRgb(212, 175, 55)), 1), box);
        dc.DrawText(ft, new Point(n.X + 6, top + 6));
    }
}
