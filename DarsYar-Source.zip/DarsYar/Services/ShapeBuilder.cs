using System.Windows;

namespace DarsYar.Services;

/// <summary>
/// Turns a drag (corner a -> corner b) into one or more polylines for a 2D/3D shape (wireframe).
/// Pure geometry, no UI.
/// </summary>
public static class ShapeBuilder
{
    public static List<List<Point>> Build(ShapeKind kind, Point a, Point b, double thickness)
    {
        double l = Math.Min(a.X, b.X), r = Math.Max(a.X, b.X);
        double t = Math.Min(a.Y, b.Y), bt = Math.Max(a.Y, b.Y);
        double w = r - l, h = bt - t;
        double cx = (l + r) / 2, cy = (t + bt) / 2;
        var result = new List<List<Point>>();

        switch (kind)
        {
            case ShapeKind.Line:
                result.Add(new List<Point> { a, b });
                break;

            case ShapeKind.Arrow:
            {
                var d = b - a;
                if (d.Length < 1e-6) { result.Add(new List<Point> { a, b }); break; }
                d.Normalize();
                double len = Math.Max(16, thickness * 5);
                var back = -d * len;
                result.Add(new List<Point> { a, b, b + Rotate(back, 25), b, b + Rotate(back, -25) });
                break;
            }

            case ShapeKind.Rectangle:
                result.Add(Rect(l, t, r, bt));
                break;

            case ShapeKind.Ellipse:
                result.Add(Ellipse(cx, cy, w / 2, h / 2, 0, 360));
                break;

            case ShapeKind.Triangle:
                result.Add(new List<Point> { new(cx, t), new(r, bt), new(l, bt), new(cx, t) });
                break;

            case ShapeKind.RightTriangle:
                result.Add(new List<Point> { new(l, t), new(l, bt), new(r, bt), new(l, t) });
                break;

            case ShapeKind.Diamond:
                result.Add(new List<Point> { new(cx, t), new(r, cy), new(cx, bt), new(l, cy), new(cx, t) });
                break;

            case ShapeKind.Pentagon:
                result.Add(Polygon(cx, cy, w / 2, h / 2, 5, -90));
                break;

            case ShapeKind.Hexagon:
                result.Add(Polygon(cx, cy, w / 2, h / 2, 6, 0));
                break;

            case ShapeKind.Star:
            {
                var pts = new List<Point>();
                for (int i = 0; i <= 10; i++)
                {
                    double ang = (-90 + i * 36) * Math.PI / 180.0;
                    double k = (i % 2 == 0) ? 1.0 : 0.4;
                    pts.Add(new Point(cx + Math.Cos(ang) * w / 2 * k, cy + Math.Sin(ang) * h / 2 * k));
                }
                result.Add(pts);
                break;
            }

            case ShapeKind.Cube:
            {
                double d = 0.3 * Math.Min(w, h);
                result.Add(Rect(l, t + d, r - d, bt));          // front
                result.Add(Rect(l + d, t, r, bt - d));          // back
                result.Add(new List<Point> { new(l, t + d), new(l + d, t) });
                result.Add(new List<Point> { new(r - d, t + d), new(r, t) });
                result.Add(new List<Point> { new(r - d, bt), new(r, bt - d) });
                result.Add(new List<Point> { new(l, bt), new(l + d, bt - d) });
                break;
            }

            case ShapeKind.Cylinder:
            {
                double ry = Math.Max(4, 0.12 * h);
                result.Add(Ellipse(cx, t + ry, w / 2, ry, 0, 360));                  // top
                result.Add(Ellipse(cx, bt - ry, w / 2, ry, 0, 180));                 // bottom (front half)
                result.Add(new List<Point> { new(l, t + ry), new(l, bt - ry) });
                result.Add(new List<Point> { new(r, t + ry), new(r, bt - ry) });
                break;
            }

            case ShapeKind.Cone:
            {
                double ry = Math.Max(4, 0.12 * h);
                result.Add(Ellipse(cx, bt - ry, w / 2, ry, 0, 360));                 // base
                result.Add(new List<Point> { new(cx, t), new(l, bt - ry) });
                result.Add(new List<Point> { new(cx, t), new(r, bt - ry) });
                break;
            }

            case ShapeKind.Sphere:
                result.Add(Ellipse(cx, cy, w / 2, h / 2, 0, 360));
                result.Add(Ellipse(cx, cy, w / 2, Math.Max(3, 0.2 * h / 2), 0, 180)); // equator (front half)
                break;

            case ShapeKind.Pyramid:
            {
                double d = 0.2 * h;
                var a1 = new Point(l, bt);
                var b1 = new Point(r - d, bt);
                var c1 = new Point(r, bt - d);
                var d1 = new Point(l + d, bt - d);
                var apex = new Point(cx, t);
                result.Add(new List<Point> { a1, b1, c1, d1, a1 });
                result.Add(new List<Point> { apex, a1 });
                result.Add(new List<Point> { apex, b1 });
                result.Add(new List<Point> { apex, c1 });
                break;
            }
        }
        return result;
    }

    /// <summary>Adds intermediate points so thick round strokes render smoothly.</summary>
    public static List<Point> Densify(List<Point> pts, double step)
    {
        var res = new List<Point>();
        for (int i = 0; i < pts.Count - 1; i++)
        {
            var p0 = pts[i];
            var p1 = pts[i + 1];
            double dist = (p1 - p0).Length;
            int n = Math.Max(1, (int)Math.Ceiling(dist / step));
            for (int k = 0; k < n; k++)
                res.Add(new Point(p0.X + (p1.X - p0.X) * k / n, p0.Y + (p1.Y - p0.Y) * k / n));
        }
        if (pts.Count > 0) res.Add(pts[pts.Count - 1]);
        return res;
    }

    private static List<Point> Rect(double l, double t, double r, double b) =>
        new() { new(l, t), new(r, t), new(r, b), new(l, b), new(l, t) };

    private static List<Point> Ellipse(double cx, double cy, double rx, double ry, double fromDeg, double toDeg)
    {
        var pts = new List<Point>();
        int n = 72;
        for (int i = 0; i <= n; i++)
        {
            double ang = (fromDeg + (toDeg - fromDeg) * i / n) * Math.PI / 180.0;
            pts.Add(new Point(cx + Math.Cos(ang) * rx, cy + Math.Sin(ang) * ry));
        }
        return pts;
    }

    private static List<Point> Polygon(double cx, double cy, double rx, double ry, int sides, double startDeg)
    {
        var pts = new List<Point>();
        for (int i = 0; i <= sides; i++)
        {
            double ang = (startDeg + 360.0 * i / sides) * Math.PI / 180.0;
            pts.Add(new Point(cx + Math.Cos(ang) * rx, cy + Math.Sin(ang) * ry));
        }
        return pts;
    }

    private static Vector Rotate(Vector v, double degrees)
    {
        double r = degrees * Math.PI / 180.0;
        double c = Math.Cos(r), s = Math.Sin(r);
        return new Vector(v.X * c - v.Y * s, v.X * s + v.Y * c);
    }
}
