using System.ComponentModel;
using System.Text.Json;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DarsYar;

public enum Tool { Pen, Highlighter, Eraser, EraserPoint, EraserLasso, Select, Shape, Note }

public enum ShapeKind
{
    Line, Arrow, Rectangle, Ellipse, Triangle, RightTriangle, Diamond, Pentagon, Hexagon, Star,
    Cube, Cylinder, Cone, Sphere, Pyramid
}

/// <summary>Shared tool settings (singleton). Views subscribe to Changed.</summary>
public sealed class ToolState
{
    public static ToolState Instance { get; } = new();

    public Tool Tool { get; private set; } = Tool.Pen;
    public ShapeKind Shape { get; private set; } = ShapeKind.Line;
    public Color PenColor { get; private set; } = Colors.Black;
    public Color HighlighterColor { get; private set; } = Colors.Yellow;
    public double Thickness { get; private set; } = 3;
    /// <summary>One finger writes (two fingers always scroll/zoom).</summary>
    public bool AllowTouchInk { get; private set; } = true;

    public event Action? Changed;

    public void SetTool(Tool t) { Tool = t; Changed?.Invoke(); }
    public void SetShape(ShapeKind k) { Shape = k; Tool = Tool.Shape; Changed?.Invoke(); }

    public void SetColor(Color c)
    {
        if (Tool == Tool.Highlighter) HighlighterColor = c; else PenColor = c;
        Changed?.Invoke();
    }

    public void SetThickness(double v) { Thickness = Math.Clamp(v, 1, 40); Changed?.Invoke(); }
    public void SetAllowTouchInk(bool v) { AllowTouchInk = v; Changed?.Invoke(); }
}

/// <summary>A text note, stored in stable page coordinates (96-dpi units at zoom 1).</summary>
public sealed class NoteItem
{
    public double X { get; set; }
    public double Y { get; set; }
    public double W { get; set; }
    public string Text { get; set; } = "";

    public const double HeaderHeight = 24;
}

/// <summary>An image placed on a page. Bytes live in the images table (referenced by Id).</summary>
public sealed class ImageItem
{
    public string Id { get; set; } = "";
    public double X { get; set; }
    public double Y { get; set; }
    public double W { get; set; }
    public double H { get; set; }
}

/// <summary>Non-ink content of a page (notes + images), stored as JSON.</summary>
public sealed class PageExtras
{
    public List<NoteItem> Notes { get; set; } = new();
    public List<ImageItem> Images { get; set; } = new();

    public bool IsEmpty => Notes.Count == 0 && Images.Count == 0;

    public static PageExtras Parse(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return new PageExtras();
        var t = json.TrimStart();
        if (t.StartsWith("["))   // legacy format: plain list of notes
            return new PageExtras { Notes = JsonSerializer.Deserialize<List<NoteItem>>(json) ?? new() };
        return JsonSerializer.Deserialize<PageExtras>(json) ?? new PageExtras();
    }

    public string? ToJson() => IsEmpty ? null : JsonSerializer.Serialize(this);
}

/// <summary>One page of the flattened document: an original page or an inserted blank page.</summary>
public sealed class PageEntry
{
    public string Key { get; init; } = "";        // "p{index}" or "b{guid}"
    public bool IsBlank { get; init; }
    public int SourceIndex { get; init; }         // original pages only
    public string? BlankId { get; init; }         // blank pages only
    public double Width { get; init; }
    public double Height { get; init; }
}

public sealed record BlankRecord(string Id, string AfterKey, int Seq, double W, double H);

public sealed record PinRecord(string Id, string Key, string Label, int Seq);

public sealed class PinItem
{
    public string Id { get; init; } = "";
    public string Key { get; init; } = "";
    public string Label { get; init; } = "";
    public string Display { get; init; } = "";
}

public sealed record DocumentRecord(string Id, string Path, string Type, DateTime LastUsed, int LastPage, double LastZoom);

public sealed class ThumbItem : INotifyPropertyChanged
{
    private BitmapSource? _image;
    public int Index { get; init; }
    public string Key { get; init; } = "";
    public string Label { get; init; } = "";
    public BitmapSource? Image
    {
        get => _image;
        set { _image = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Image))); }
    }
    public event PropertyChangedEventHandler? PropertyChanged;
}
