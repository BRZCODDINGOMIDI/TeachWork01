using System.Collections.ObjectModel;
using System.Globalization;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DarsYar.Services;

namespace DarsYar;

/// <summary>
/// One open document: continuous vertical scroll of all pages, lazy page realization,
/// pen/mouse/one-finger writing, two-finger scroll + pinch zoom, pins, blank pages, images.
/// </summary>
public partial class DocumentView : UserControl
{
    private enum FitMode { None, Width, Page }

    private const double TopMargin = 24;   // == PagesPanel.Margin (not scaled by zoom)

    private readonly Database _db;
    private DocumentSource _source = null!;
    private string _docId = "";

    private readonly List<(double W, double H)> _origSizes = new();
    private List<PageEntry> _entries = new();
    private readonly List<PageView> _pages = new();
    private double[] _tops = Array.Empty<double>();   // logical top of each page inside the panel

    private double _zoom = 1;
    private FitMode _fit = FitMode.Width;
    private int _currentIndex;
    private int _pendingScrollIndex = -1;

    private readonly DispatcherTimer _saveTimer;
    private readonly DispatcherTimer _scrollTimer;
    private readonly DispatcherTimer _zoomTimer;
    private Task _writeChain = Task.CompletedTask;
    private DateTime _lastSave = DateTime.UtcNow;
    private bool _penActive;

    // shared input state (read by PageView)
    public bool PenInRange { get; private set; }
    public bool PenInverted { get; private set; }
    public bool MouseActive { get; private set; }
    public bool Gesture { get; private set; }
    public bool DiscardStrokes { get; private set; }
    public PageView? ActivePage { get; set; }

    private readonly Dictionary<int, Point> _touches = new();
    private Point _lastCenter;
    private double _lastDist;

    private readonly ObservableCollection<ThumbItem> _thumbs = new();
    private readonly Dictionary<string, BitmapSource> _thumbCache = new();
    private CancellationTokenSource _thumbCts = new();
    private bool _updatingThumbSelection;

    private readonly ObservableCollection<PinItem> _pinItems = new();
    private bool _updatingPins;
    private readonly Stack<double> _backStack = new();

    public string FilePath { get; private set; } = "";
    public string FileName => Path.GetFileName(FilePath);
    public string DocId => _docId;
    public DocumentSource Source => _source;
    public IReadOnlyList<PageEntry> Entries => _entries;
    public Database Db => _db;
    public int CurrentIndex => _currentIndex;

    private DocumentView(Database db)
    {
        _db = db;
        InitializeComponent();
        Thumbs.ItemsSource = _thumbs;
        PinsList.ItemsSource = _pinItems;

        PreviewTouchDown += View_PreviewTouchDown;
        PreviewTouchMove += View_PreviewTouchMove;
        PreviewTouchUp += View_PreviewTouchUp;
        PreviewMouseDown += (_, e) =>
        {
            if (e.StylusDevice == null && _touches.Count > 0) { _touches.Clear(); EndGesture(); }
        };
        Scroller.PreviewMouseWheel += (_, e) =>
        {
            if (Keyboard.Modifiers == ModifierKeys.Control)
            {
                e.Handled = true;
                SetZoomAround(e.Delta > 0 ? _zoom * 1.15 : _zoom / 1.15, e.GetPosition(Scroller), false);
            }
        };

        _saveTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };
        _saveTimer.Tick += (_, _) =>
        {
            _saveTimer.Stop();
            if (_penActive) { _saveTimer.Start(); return; }   // never save in the middle of a stroke
            SaveAll(false);
        };

        _scrollTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(120) };
        _scrollTimer.Tick += (_, _) =>
        {
            _scrollTimer.Stop();
            UpdateRealization();
            try { _db.SavePosition(_docId, _currentIndex, _fit == FitMode.None ? _zoom : 0); } catch { }
        };

        _zoomTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(350) };
        _zoomTimer.Tick += (_, _) => { _zoomTimer.Stop(); RerenderIfNeeded(); };

        ToolState.Instance.Changed += OnToolChanged;
    }

    // ------------------------------------------------------------------ creation

    public static async Task<DocumentView> CreateAsync(Database db, string path)
    {
        var view = new DocumentView(db) { FilePath = path };
        view._source = await DocumentSource.OpenAsync(path);
        int n = view._source.PageCount;
        if (n < 1) throw new InvalidDataException("سند هیچ صفحه‌ای ندارد.");

        view._docId = await Task.Run(() => Database.ComputeFileId(path));
        var rec = db.OpenDocument(view._docId, path, view._source.Type);
        view.FileNameText.Text = view.FileName;

        for (int i = 0; i < n; i++)
        {
            var s = await view._source.GetPageSizeAsync(i);
            view._origSizes.Add((s.Width, s.Height));
        }

        if (rec.LastZoom > 0) { view._fit = FitMode.None; view._zoom = ViewMath.Clamp(rec.LastZoom); }
        view.ZoomTransform.ScaleX = view._zoom;
        view.ZoomTransform.ScaleY = view._zoom;

        view.BuildLayout();
        view._pendingScrollIndex = Math.Clamp(rec.LastPage, 0, view._entries.Count - 1);
        view.RefreshPins();
        view.UpdateBar();
        return view;
    }

    private void BuildLayout()
    {
        _entries = PageLayout.Build(_origSizes, _db.GetBlanks(_docId));
        PagesPanel.Children.Clear();
        _pages.Clear();
        ActivePage = null;

        _tops = new double[_entries.Count];
        double y = 0;
        for (int i = 0; i < _entries.Count; i++)
        {
            var pv = new PageView(this, _entries[i], i);
            _pages.Add(pv);
            PagesPanel.Children.Add(pv);
            _tops[i] = y;
            y += _entries[i].Height + PageView.Gap;
        }
        if (_currentIndex >= _entries.Count) _currentIndex = Math.Max(0, _entries.Count - 1);
        RebuildThumbs();
    }

    // ------------------------------------------------------------------ scrolling & current page

    private int IndexAtViewportY(double viewportY)
    {
        if (_tops.Length == 0) return 0;
        double y = (Scroller.VerticalOffset + viewportY - TopMargin) / _zoom;
        int lo = 0, hi = _tops.Length - 1;
        while (lo < hi)
        {
            int mid = (lo + hi + 1) / 2;
            if (_tops[mid] <= y) lo = mid; else hi = mid - 1;
        }
        return lo;
    }

    private double ViewportHeight => Scroller.ViewportHeight > 0 ? Scroller.ViewportHeight : Scroller.ActualHeight;
    private double ViewportWidth => Scroller.ViewportWidth > 0 ? Scroller.ViewportWidth : Scroller.ActualWidth;

    private void ScrollToIndex(int index)
    {
        if (index < 0 || index >= _tops.Length) return;
        Scroller.ScrollToVerticalOffset(Math.Max(0, TopMargin + _tops[index] * _zoom - 6));
    }

    private void Scroller_ScrollChanged(object sender, ScrollChangedEventArgs e)
    {
        int idx = IndexAtViewportY(ViewportHeight * 0.4);
        if (idx != _currentIndex)
        {
            _currentIndex = idx;
            UpdateBar();
        }
        _scrollTimer.Stop();
        _scrollTimer.Start();
    }

    private void Scroller_SizeChanged(object sender, SizeChangedEventArgs e)
    {
        if (Scroller.ActualWidth <= 0 || Scroller.ActualHeight <= 0) return;
        if (_fit != FitMode.None) ApplyFit();

        if (_pendingScrollIndex >= 0)
        {
            int i = _pendingScrollIndex;
            _pendingScrollIndex = -1;
            Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
            {
                Scroller.UpdateLayout();
                ScrollToIndex(i);
                _currentIndex = i;
                UpdateBar();
                UpdateRealization();
            }));
        }
        else
        {
            _scrollTimer.Stop();
            _scrollTimer.Start();
        }
    }

    public void NextPage() => ScrollToIndex(Math.Min(_currentIndex + 1, _entries.Count - 1));
    public void PrevPage() => ScrollToIndex(Math.Max(_currentIndex - 1, 0));

    private void Prev_Click(object s, RoutedEventArgs e) => PrevPage();
    private void Next_Click(object s, RoutedEventArgs e) => NextPage();

    private void PageBox_KeyDown(object s, KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        if (int.TryParse(ToLatinDigits(PageBox.Text), NumberStyles.Integer, CultureInfo.InvariantCulture, out int n)
            && n >= 1 && n <= _entries.Count)
        {
            RememberPosition();
            ScrollToIndex(n - 1);
        }
        else
        {
            UpdateBar();
            SetStatus($"شماره صفحه باید بین ۱ و {_entries.Count} باشد.");
        }
        Keyboard.ClearFocus();
        Focus();
    }

    private void PageBox_LostFocus(object s, RoutedEventArgs e) => UpdateBar();

    private static string ToLatinDigits(string s)
    {
        var sb = new System.Text.StringBuilder(s.Length);
        foreach (char c in s)
        {
            if (c >= '۰' && c <= '۹') sb.Append((char)('0' + (c - '۰')));
            else if (c >= '٠' && c <= '٩') sb.Append((char)('0' + (c - '٠')));
            else sb.Append(c);
        }
        return sb.ToString().Trim();
    }

    private void UpdateBar()
    {
        PageBox.Text = (_currentIndex + 1).ToString(CultureInfo.InvariantCulture);
        PageCountText.Text = "از " + _entries.Count.ToString(CultureInfo.InvariantCulture);
        ZoomText.Text = (_zoom * 100).ToString("0", CultureInfo.InvariantCulture) + "%";
        if (_thumbs.Count > _currentIndex)
        {
            _updatingThumbSelection = true;
            Thumbs.SelectedIndex = _currentIndex;
            if (Thumbs.SelectedItem != null) Thumbs.ScrollIntoView(Thumbs.SelectedItem);
            _updatingThumbSelection = false;
        }
    }

    // ------------------------------------------------------------------ zoom

    private Point ViewportCenter => new(ViewportWidth / 2, ViewportHeight / 2);

    private void SetZoomAround(double z, Point focus, bool fromFit)
    {
        z = ViewMath.Clamp(z);
        if (!fromFit) _fit = FitMode.None;
        if (Math.Abs(z - _zoom) < 1e-6) return;

        double lx = (Scroller.HorizontalOffset + focus.X) / _zoom;
        double ly = (Scroller.VerticalOffset + focus.Y - TopMargin) / _zoom;
        _zoom = z;
        ZoomTransform.ScaleX = z;
        ZoomTransform.ScaleY = z;
        Scroller.UpdateLayout();
        Scroller.ScrollToHorizontalOffset(Math.Max(0, lx * z - focus.X));
        Scroller.ScrollToVerticalOffset(Math.Max(0, ly * z + TopMargin - focus.Y));

        ZoomText.Text = (_zoom * 100).ToString("0", CultureInfo.InvariantCulture) + "%";
        _zoomTimer.Stop();
        _zoomTimer.Start();
        _scrollTimer.Stop();
        _scrollTimer.Start();
    }

    public void ZoomIn() => SetZoomAround(_zoom * 1.25, ViewportCenter, false);
    public void ZoomOut() => SetZoomAround(_zoom / 1.25, ViewportCenter, false);

    private void ApplyFit()
    {
        if (_fit == FitMode.None || _entries.Count == 0) return;
        double vw = Scroller.ActualWidth - SystemParameters.VerticalScrollBarWidth;
        double vh = Scroller.ActualHeight - SystemParameters.HorizontalScrollBarHeight;
        if (vw <= 60 || vh <= 60) return;
        var e = _entries[Math.Clamp(_currentIndex, 0, _entries.Count - 1)];
        double z = _fit == FitMode.Width
            ? ViewMath.FitWidth(vw, e.Width)
            : ViewMath.FitPage(vw, vh, e.Width, e.Height);
        SetZoomAround(z, ViewportCenter, true);
    }

    private void ZoomIn_Click(object s, RoutedEventArgs e) => ZoomIn();
    private void ZoomOut_Click(object s, RoutedEventArgs e) => ZoomOut();
    private void FitWidth_Click(object s, RoutedEventArgs e) { _fit = FitMode.Width; ApplyFit(); }
    private void FitPage_Click(object s, RoutedEventArgs e) { _fit = FitMode.Page; ApplyFit(); }

    // ------------------------------------------------------------------ page realization (lazy loading)

    private double DesiredScale()
    {
        double dpi = VisualTreeHelper.GetDpi(this).DpiScaleX;
        return Math.Clamp(_zoom * dpi, 1.5, 4.0);
    }

    private void UpdateRealization()
    {
        if (_pages.Count == 0) return;
        double vh = ViewportHeight;
        if (vh <= 0) return;
        double y0 = (Scroller.VerticalOffset - TopMargin) / _zoom;
        double y1 = (Scroller.VerticalOffset + vh - TopMargin) / _zoom;
        double span = Math.Max(1, y1 - y0);
        double wantLo = y0 - span * 0.75, wantHi = y1 + span * 0.75;
        double keepLo = y0 - span * 2.0, keepHi = y1 + span * 2.0;

        for (int i = 0; i < _pages.Count; i++)
        {
            var pv = _pages[i];
            double top = _tops[i], bot = top + pv.Entry.Height;
            bool want = bot >= wantLo && top <= wantHi;
            bool keep = bot >= keepLo && top <= keepHi;
            if (want && !pv.Realized && !pv.Loading)
                _ = RealizeAsync(pv);
            else if (!keep && (pv.Realized || pv.Loading))
                Unrealize(pv);
        }
    }

    private async Task RealizeAsync(PageView pv)
    {
        pv.Loading = true;
        int gen = ++pv.Generation;
        try
        {
            if (!_writeChain.IsCompleted) await _writeChain;     // make sure we read what was just saved
            if (gen != pv.Generation) return;

            var (ink, notes) = _db.LoadPage(_docId, pv.Entry.Key);
            pv.CreateLayers();
            pv.LoadContent(ink, notes);
            pv.Loading = false;
            if (pv.Entry.IsBlank) return;

            double scale = DesiredScale();
            var bmp = await _source.RenderAsync(pv.Entry.SourceIndex, scale);
            if (gen != pv.Generation || !pv.Realized) return;
            pv.SetBackground(bmp, scale);
        }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            SetStatus("نمایش یک صفحه ناموفق بود: " + ex.Message);
        }
        finally
        {
            if (gen == pv.Generation) pv.Loading = false;
        }
    }

    private void Unrealize(PageView pv)
    {
        SavePage(pv, false);
        pv.Generation++;
        pv.Loading = false;
        if (ReferenceEquals(ActivePage, pv)) ActivePage = null;
        pv.ClearContent();
    }

    private void RerenderIfNeeded()
    {
        if (_source.Type == "image") return;
        double want = DesiredScale();
        foreach (var pv in _pages)
        {
            if (!pv.Realized || pv.Entry.IsBlank || pv.RenderedScale <= 0) continue;
            if (Math.Abs(want - pv.RenderedScale) / pv.RenderedScale > 0.25)
                _ = RerenderAsync(pv, want);
        }
    }

    private async Task RerenderAsync(PageView pv, double scale)
    {
        int gen = pv.Generation;
        try
        {
            var bmp = await _source.RenderAsync(pv.Entry.SourceIndex, scale);
            if (gen != pv.Generation || !pv.Realized) return;
            pv.SetBackground(bmp, scale);
        }
        catch (Exception ex) { AppPaths.LogError(ex); }
    }

    // ------------------------------------------------------------------ input arbitration (pen / mouse / touch)

    private void OnToolChanged()
    {
        foreach (var pv in _pages) if (pv.Realized) pv.ApplyTool();
    }

    private void UpdateAllModes()
    {
        foreach (var pv in _pages) if (pv.Realized) pv.UpdateMode();
    }

    public void OnMouseSeen()
    {
        if (MouseActive) return;
        MouseActive = true;
        PenInRange = false;
        UpdateAllModes();
    }

    public void OnStylusInRange(StylusDevice? dev)
    {
        if (dev?.TabletDevice?.Type != TabletDeviceType.Stylus) return;
        PenInRange = true;
        MouseActive = false;
        PenInverted = dev.Inverted;
        UpdateAllModes();
    }

    public void OnStylusOutOfRange()
    {
        PenInRange = false;
        PenInverted = false;
        UpdateAllModes();
    }

    public void OnPenDown(PageView pv)
    {
        _penActive = true;
        ActivePage = pv;
    }

    public void OnPenUp()
    {
        _penActive = false;
        if ((DateTime.UtcNow - _lastSave).TotalSeconds > 10)
            Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => SaveAll(false)));
    }

    // two fingers: scroll + pinch zoom ; one finger: write (handled by the InkCanvas)
    private void View_PreviewTouchDown(object? sender, TouchEventArgs e)
    {
        _touches[e.TouchDevice.Id] = e.GetTouchPoint(Scroller).Position;
        if (_touches.Count >= 2)
        {
            if (!Gesture)
            {
                Gesture = true;
                DiscardStrokes = true;      // the first finger's partial stroke is thrown away
                UpdateAllModes();
            }
            ResetGestureBaseline();
            e.Handled = true;
        }
    }

    private void View_PreviewTouchMove(object? sender, TouchEventArgs e)
    {
        int id = e.TouchDevice.Id;
        if (!_touches.ContainsKey(id)) return;
        _touches[id] = e.GetTouchPoint(Scroller).Position;
        if (!Gesture || _touches.Count < 2) return;
        e.Handled = true;

        var pts = _touches.Values.Take(2).ToArray();
        var center = new Point((pts[0].X + pts[1].X) / 2, (pts[0].Y + pts[1].Y) / 2);
        double dist = (pts[0] - pts[1]).Length;

        double ratio = _lastDist > 1 ? dist / _lastDist : 1;
        if (Math.Abs(ratio - 1) > 0.01)
        {
            SetZoomAround(_zoom * ratio, _lastCenter, false);
            _lastDist = dist;
        }

        Scroller.ScrollToHorizontalOffset(Scroller.HorizontalOffset - (center.X - _lastCenter.X));
        Scroller.ScrollToVerticalOffset(Scroller.VerticalOffset - (center.Y - _lastCenter.Y));
        _lastCenter = center;
    }

    private void View_PreviewTouchUp(object? sender, TouchEventArgs e)
    {
        _touches.Remove(e.TouchDevice.Id);
        if (_touches.Count == 0) EndGesture();
        else if (Gesture) ResetGestureBaseline();
    }

    private void ResetGestureBaseline()
    {
        var pts = _touches.Values.Take(2).ToArray();
        if (pts.Length < 2) return;
        _lastCenter = new Point((pts[0].X + pts[1].X) / 2, (pts[0].Y + pts[1].Y) / 2);
        _lastDist = (pts[0] - pts[1]).Length;
    }

    private void EndGesture()
    {
        if (!Gesture) return;
        Gesture = false;
        Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
        {
            DiscardStrokes = false;
            UpdateAllModes();
        }));
    }

    // ------------------------------------------------------------------ undo / redo / delete

    private PageView? TargetPage()
    {
        if (ActivePage != null && ActivePage.Realized) return ActivePage;
        if (_currentIndex >= 0 && _currentIndex < _pages.Count && _pages[_currentIndex].Realized)
            return _pages[_currentIndex];
        return null;
    }

    public void Undo() => TargetPage()?.Undo();
    public void Redo() => TargetPage()?.Redo();
    public void DeleteSelection() => TargetPage()?.DeleteSelection();

    // ------------------------------------------------------------------ saving

    public void OnPageDirty(PageView pv)
    {
        ActivePage ??= pv;
        SetStatus("تغییرات ذخیره‌نشده…");
        _saveTimer.Stop();
        _saveTimer.Start();
    }

    private void SavePage(PageView pv, bool sync)
    {
        if (!pv.Dirty || !pv.Realized) return;
        pv.Dirty = false;
        var (ink, extras) = pv.Serialize();
        string key = pv.Entry.Key;
        string id = _docId;
        _lastSave = DateTime.UtcNow;

        if (sync)
        {
            try { _writeChain.Wait(); } catch { }
            try
            {
                _db.SavePage(id, key, ink, extras);
                SetStatus("ذخیره شد ✓ " + DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture));
            }
            catch (Exception ex)
            {
                pv.Dirty = true;
                AppPaths.LogError(ex);
                SetStatus("خطا در ذخیره‌سازی: " + ex.Message);
            }
            return;
        }

        _writeChain = _writeChain.ContinueWith(_ =>
        {
            try
            {
                _db.SavePage(id, key, ink, extras);
                Dispatcher.BeginInvoke(new Action(() =>
                    SetStatus("ذخیره شد ✓ " + DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture))));
            }
            catch (Exception ex)
            {
                AppPaths.LogError(ex);
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    pv.Dirty = true;
                    SetStatus("خطا در ذخیره‌سازی: " + ex.Message);
                }));
            }
        }, TaskScheduler.Default);
    }

    private void SaveAll(bool sync)
    {
        foreach (var pv in _pages) SavePage(pv, sync);
    }

    /// <summary>Manual save / flush (Ctrl+S, before export, on close).</summary>
    public void FlushSave()
    {
        _saveTimer.Stop();
        SaveAll(true);
        try { _writeChain.Wait(); } catch { }
        try { _db.SavePosition(_docId, _currentIndex, _fit == FitMode.None ? _zoom : 0); } catch { }
    }

    public void CloseDocument()
    {
        FlushSave();
        _thumbCts.Cancel();
        _saveTimer.Stop();
        _scrollTimer.Stop();
        _zoomTimer.Stop();
        ToolState.Instance.Changed -= OnToolChanged;
        _source.Dispose();
    }

    // ------------------------------------------------------------------ blank pages

    private void InsertBlank_Click(object s, RoutedEventArgs e) => InsertBlankAfterCurrent();
    private void RemoveBlank_Click(object s, RoutedEventArgs e) => RemoveCurrentBlank();

    public void InsertBlankAfterCurrent()
    {
        if (_entries.Count == 0) return;
        int i = _currentIndex;
        var e = _entries[i];
        SaveAll(true);
        _db.AddBlank(_docId, e.Key, e.Width, e.Height);
        BuildLayout();
        Scroller.UpdateLayout();
        _currentIndex = Math.Min(i + 1, _entries.Count - 1);
        ScrollToIndex(_currentIndex);
        UpdateBar();
        RefreshPins();
        UpdateRealization();
        SetStatus("صفحه خالی اضافه شد.");
    }

    public void RemoveCurrentBlank()
    {
        if (_entries.Count == 0) return;
        int i = _currentIndex;
        var e = _entries[i];
        if (!e.IsBlank || e.BlankId == null)
        {
            SetStatus("فقط صفحه‌های خالیِ اضافه‌شده قابل حذف‌اند.");
            return;
        }
        if (!Dialogs.Confirm(Window.GetWindow(this),
                "این صفحه خالی و هر چه روی آن نوشته‌اید برای همیشه حذف شود؟")) return;

        SaveAll(true);
        _db.RemoveBlank(_docId, e.BlankId);
        BuildLayout();
        Scroller.UpdateLayout();
        _currentIndex = Math.Clamp(i, 0, _entries.Count - 1);
        ScrollToIndex(_currentIndex);
        UpdateBar();
        RefreshPins();
        UpdateRealization();
    }

    // ------------------------------------------------------------------ pins

    private void RememberPosition()
    {
        _backStack.Push(Scroller.VerticalOffset);
        while (_backStack.Count > 30)
        {
            var keep = _backStack.Reverse().Skip(1).ToArray();   // drop the oldest
            _backStack.Clear();
            foreach (var v in keep) _backStack.Push(v);
        }
        BackButton.IsEnabled = true;
    }

    private void Pin_Click(object s, RoutedEventArgs e) => PinCurrentPage(Window.GetWindow(this));

    public void PinCurrentPage(Window? owner)
    {
        if (_entries.Count == 0) return;
        int i = _currentIndex;
        var label = PromptWindow.Ask(owner, "پین صفحه", "نام پین (مثلاً «پاسخ‌نامه»):",
            "صفحه " + (i + 1).ToString(CultureInfo.InvariantCulture));
        if (string.IsNullOrWhiteSpace(label)) return;
        _db.AddPin(_docId, _entries[i].Key, label);
        RefreshPins();
    }

    private void RefreshPins()
    {
        var index = new Dictionary<string, int>();
        for (int i = 0; i < _entries.Count; i++) index[_entries[i].Key] = i;

        _updatingPins = true;
        _pinItems.Clear();
        foreach (var p in _db.GetPins(_docId))
        {
            if (!index.TryGetValue(p.Key, out int pos)) continue;
            _pinItems.Add(new PinItem
            {
                Id = p.Id,
                Key = p.Key,
                Label = p.Label,
                Display = p.Label + "  (ص " + (pos + 1).ToString(CultureInfo.InvariantCulture) + ")"
            });
        }
        _updatingPins = false;
    }

    private void PinsList_SelectionChanged(object s, SelectionChangedEventArgs e)
    {
        if (_updatingPins || PinsList.SelectedItem is not PinItem pin) return;
        _updatingPins = true;
        PinsList.SelectedIndex = -1;       // so the same pin can be clicked again
        _updatingPins = false;

        int target = _entries.FindIndex(x => x.Key == pin.Key);
        if (target < 0) return;
        RememberPosition();
        ScrollToIndex(target);
    }

    private void PinDelete_Click(object s, RoutedEventArgs e)
    {
        if (s is Button { Tag: string id })
        {
            _db.RemovePin(_docId, id);
            RefreshPins();
        }
        e.Handled = true;
    }

    private void Back_Click(object s, RoutedEventArgs e)
    {
        if (_backStack.Count == 0) { BackButton.IsEnabled = false; return; }
        Scroller.ScrollToVerticalOffset(_backStack.Pop());
        BackButton.IsEnabled = _backStack.Count > 0;
    }

    // ------------------------------------------------------------------ thumbnails

    private void RebuildThumbs()
    {
        _thumbCts.Cancel();
        _thumbCts = new CancellationTokenSource();
        _thumbs.Clear();
        var items = new List<ThumbItem>();
        for (int i = 0; i < _entries.Count; i++)
        {
            var it = new ThumbItem
            {
                Index = i,
                Key = _entries[i].Key,
                Label = _entries[i].IsBlank
                    ? (i + 1).ToString(CultureInfo.InvariantCulture) + " (خالی)"
                    : (i + 1).ToString(CultureInfo.InvariantCulture)
            };
            if (_thumbCache.TryGetValue(it.Key, out var cached)) it.Image = cached;
            _thumbs.Add(it);
            items.Add(it);
        }
        _ = LoadThumbnailsAsync(items, _entries, _thumbCts.Token);
    }

    private void Thumbs_SelectionChanged(object s, SelectionChangedEventArgs e)
    {
        if (_updatingThumbSelection || Thumbs.SelectedIndex < 0) return;
        if (Thumbs.SelectedIndex != _currentIndex) ScrollToIndex(Thumbs.SelectedIndex);
    }

    private async Task LoadThumbnailsAsync(List<ThumbItem> items, List<PageEntry> entries, CancellationToken ct)
    {
        try
        {
            await Task.Delay(1200, ct);   // let the first pages render first
            double dpi = VisualTreeHelper.GetDpi(this).DpiScaleX;
            for (int i = 0; i < items.Count && !ct.IsCancellationRequested; i++)
            {
                var e = entries[i];
                if (e.IsBlank || items[i].Image != null) continue;
                double scale = Math.Min(1.0, 130.0 * dpi / Math.Max(1, e.Width));
                var bmp = await _source.RenderAsync(e.SourceIndex, scale);
                if (ct.IsCancellationRequested) return;
                _thumbCache[e.Key] = bmp;
                items[i].Image = bmp;
                await Task.Delay(5, ct);
            }
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) { AppPaths.LogError(ex); }
    }

    // ------------------------------------------------------------------ images

    public void AddImage(Window? owner)
    {
        if (_entries.Count == 0) return;
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Title = "انتخاب تصویر برای افزودن به صفحه",
            Filter = "تصاویر|*.jpg;*.jpeg;*.png;*.bmp"
        };
        if (dlg.ShowDialog(owner) != true) return;

        try
        {
            if (new FileInfo(dlg.FileName).Length > 20 * 1024 * 1024)
            {
                Dialogs.Error(owner, "حجم تصویر بیش از ۲۰ مگابایت است.");
                return;
            }
            byte[] bytes = File.ReadAllBytes(dlg.FileName);
            BitmapSource bmp = DocumentSource.Decode(bytes);

            int i = _currentIndex;
            var pv = _pages[i];
            if (!pv.Realized)
            {
                Dialogs.Info(owner, "صفحه هنوز آماده نشده است؛ چند لحظه صبر کنید و دوباره امتحان کنید.");
                return;
            }

            string id = Convert.ToHexString(SHA256.HashData(bytes));
            _db.SaveImage(id, bytes);

            double pw = pv.Entry.Width, ph = pv.Entry.Height;
            double bw = bmp.Width > 0 ? bmp.Width : bmp.PixelWidth;
            double bh = bmp.Height > 0 ? bmp.Height : bmp.PixelHeight;
            double w = Math.Min(bw, pw * 0.5);
            double h = w * bh / bw;
            if (h > ph * 0.6) { h = ph * 0.6; w = h * bw / bh; }

            double centerY = (Scroller.VerticalOffset + ViewportHeight / 2 - TopMargin) / _zoom - _tops[i];
            var item = new ImageItem
            {
                Id = id,
                X = Math.Max(10, (pw - w) / 2),
                Y = Math.Clamp(centerY - h / 2, 10, Math.Max(10, ph - h - 10)),
                W = w,
                H = h
            };
            pv.AddImage(item, bmp);

            // switch to the "note/image" tool so the picture can be moved/resized right away
            ToolState.Instance.SetTool(Tool.Note);
            SetStatus("تصویر اضافه شد؛ با نوار طلایی جابه‌جا و با مربع آبی تغییر اندازه دهید.");
        }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            Dialogs.Error(owner, "افزودن تصویر ممکن نشد:\n" + ex.Message);
        }
    }

    // ------------------------------------------------------------------ chrome (full screen)

    public void SetChrome(bool visible)
    {
        var v = visible ? Visibility.Visible : Visibility.Collapsed;
        BottomBar.Visibility = v;
        SidePanel.Visibility = v;
    }

    private void SetStatus(string text) => StatusText.Text = text;
}
