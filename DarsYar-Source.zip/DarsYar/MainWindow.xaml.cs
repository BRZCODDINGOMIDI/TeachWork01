using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DarsYar.Services;
using Microsoft.Win32;

namespace DarsYar;

public partial class MainWindow : Window
{
    private sealed class DocTab
    {
        public DocumentView View = null!;
        public Border Header = null!;
        public TextBlock Title = null!;
    }

    private readonly Database? _db;
    private readonly List<DocTab> _tabs = new();
    private DocTab? _current;
    private bool _dark;
    private bool _syncing;
    private bool _fullscreen;
    private bool _fsVertical = true;
    private WindowState _prevState;
    private WindowStyle _prevStyle;

    private static readonly string[] Palette =
    {
        "#000000", "#DC2626", "#2563EB", "#16A34A", "#F59E0B", "#9333EA", "#FFFF00", "#F472B6"
    };

    private static readonly (ShapeKind Kind, string Label)[] Shapes2DList =
    {
        (ShapeKind.Line, "╱ خط"), (ShapeKind.Arrow, "➜ فلش"), (ShapeKind.Rectangle, "▭ مستطیل"),
        (ShapeKind.Ellipse, "⬭ بیضی/دایره"), (ShapeKind.Triangle, "△ مثلث"), (ShapeKind.RightTriangle, "◺ مثلث قائم"),
        (ShapeKind.Diamond, "◇ لوزی"), (ShapeKind.Pentagon, "⬠ پنج‌ضلعی"), (ShapeKind.Hexagon, "⬡ شش‌ضلعی"),
        (ShapeKind.Star, "☆ ستاره")
    };

    private static readonly (ShapeKind Kind, string Label)[] Shapes3DList =
    {
        (ShapeKind.Cube, "🧊 مکعب"), (ShapeKind.Cylinder, "🥫 استوانه"), (ShapeKind.Cone, "🔺 مخروط"),
        (ShapeKind.Sphere, "⚪ کره"), (ShapeKind.Pyramid, "⛰ هرم")
    };

    public MainWindow()
    {
        InitializeComponent();

        try { _db = new Database(AppPaths.DbFile); }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            Dialogs.Error(this, "پایگاه داده محلی باز نشد. برنامه بدون ذخیره‌سازی قابل استفاده نیست.\n" + ex.Message);
            Loaded += (_, _) => Close();
            return;
        }

        foreach (var hex in Palette)
        {
            var color = (Color)ColorConverter.ConvertFromString(hex);
            ColorPanel.Children.Add(MakeColorDot(color));
            if (FsColors.Children.Count < 6)
                FsColors.Children.Add(MakeColorDot(color));
        }

        foreach (var (kind, label) in Shapes2DList) ShapesPanelAdd(Shapes2D, kind, label);
        foreach (var (kind, label) in Shapes3DList) ShapesPanelAdd(Shapes3D, kind, label);

        ToolState.Instance.Changed += SyncTools;
        UpdateEmptyHint();

        Loaded += async (_, _) =>
        {
            foreach (var f in App.StartupFiles)
                if (File.Exists(f) && DocumentSource.IsSupported(f)) await OpenDocumentAsync(f);
        };
    }

    private Button MakeColorDot(Color color)
    {
        var b = new Button { Style = (Style)FindResource("ColorDot"), Background = new SolidColorBrush(color) };
        b.Click += (_, _) => ToolState.Instance.SetColor(color);
        return b;
    }

    private void ShapesPanelAdd(WrapPanel panel, ShapeKind kind, string label)
    {
        var b = new Button
        {
            Style = (Style)FindResource("TbButton"),
            Content = label,
            MinWidth = 100
        };
        b.Click += (_, _) =>
        {
            ToolState.Instance.SetShape(kind);
            ShapesToggle.IsChecked = false;
        };
        panel.Children.Add(b);
    }

    private DocumentView? CurrentView => _current?.View;

    private void UpdateEmptyHint() =>
        EmptyHint.Visibility = _tabs.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

    // ------------------------------------------------------------ tabs

    private void AddTab(DocumentView view)
    {
        var tab = new DocTab { View = view };
        var title = new TextBlock
        {
            Text = view.FileName,
            MaxWidth = 180,
            TextTrimming = TextTrimming.CharacterEllipsis,
            VerticalAlignment = VerticalAlignment.Center,
            ToolTip = view.FilePath
        };
        var close = new Button
        {
            Content = "✕",
            Margin = new Thickness(8, 0, 0, 0),
            Padding = new Thickness(6, 2, 6, 2),
            BorderThickness = new Thickness(0),
            Background = Brushes.Transparent,
            MinWidth = 32,
            MinHeight = 32
        };
        var row = new StackPanel { Orientation = Orientation.Horizontal };
        row.Children.Add(title);
        row.Children.Add(close);
        var header = new Border
        {
            Child = row,
            Padding = new Thickness(10, 2, 6, 2),
            Margin = new Thickness(0, 0, 4, 0),
            CornerRadius = new CornerRadius(8, 8, 0, 0),
            BorderThickness = new Thickness(1),
            BorderBrush = (Brush)FindResource("Line"),
            Cursor = Cursors.Hand
        };
        tab.Header = header;
        tab.Title = title;
        header.MouseLeftButtonDown += (_, _) => SelectTab(tab);
        close.Click += (_, e) => { CloseTab(tab); };

        _tabs.Add(tab);
        TabBar.Children.Add(header);
        SelectTab(tab);
        UpdateEmptyHint();
    }

    private void SelectTab(DocTab tab)
    {
        _current = tab;
        ContentHost.Child = null;
        ContentHost.Child = tab.View;
        tab.View.SetChrome(!_fullscreen);
        foreach (var t in _tabs)
        {
            bool sel = ReferenceEquals(t, tab);
            t.Header.Background = sel ? (Brush)FindResource("Accent") : (Brush)FindResource("PanelBg");
            t.Title.Foreground = sel ? Brushes.White : (Brush)FindResource("Fg");
        }
    }

    private void CloseTab(DocTab tab)
    {
        bool save = true;
        if (tab.View.HasUnsavedChanges)
        {
            var r = Dialogs.AskSave(this, $"«{tab.View.FileName}» تغییرات ذخیره‌نشده دارد.\nذخیره شود؟");
            if (r == MessageBoxResult.Cancel) return;
            save = r == MessageBoxResult.Yes;
            if (save && !tab.View.TrySave())
            {
                Dialogs.Error(this, "ذخیره‌سازی انجام نشد؛ سند بسته نشد. جزئیات: " + AppPaths.LogFile);
                return;
            }
        }
        tab.View.CloseDocument(save);
        int idx = _tabs.IndexOf(tab);
        _tabs.Remove(tab);
        TabBar.Children.Remove(tab.Header);
        if (ReferenceEquals(_current, tab))
        {
            _current = null;
            ContentHost.Child = null;
            if (_tabs.Count > 0) SelectTab(_tabs[Math.Clamp(idx, 0, _tabs.Count - 1)]);
        }
        UpdateEmptyHint();
    }

    // ------------------------------------------------------------ open

    private async Task OpenDocumentAsync(string path)
    {
        if (_db == null) return;
        if (!File.Exists(path))
        {
            Dialogs.Error(this, "فایل اصلی پیدا نشد (جابه‌جا یا حذف شده است):\n" + path +
                "\n\nیادداشت‌های قبلی حذف نشده‌اند. اگر فایل را به‌جای دیگری منتقل کرده‌اید، " +
                "از «باز کردن» همان فایل را انتخاب کنید؛ یادداشت‌ها دوباره به آن متصل می‌شوند.");
            return;
        }

        foreach (var t in _tabs)
            if (string.Equals(t.View.FilePath, path, StringComparison.OrdinalIgnoreCase))
            { SelectTab(t); return; }

        Mouse.OverrideCursor = Cursors.Wait;
        try
        {
            var view = await DocumentView.CreateAsync(_db, path);
            AddTab(view);
        }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            Dialogs.Error(this, "باز کردن فایل ممکن نشد. ممکن است فایل خراب، رمزدار یا ناسازگار باشد.\n\n" +
                path + "\n" + ex.Message);
        }
        finally { Mouse.OverrideCursor = null; }
    }

    private async void Open_Click(object s, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Title = "باز کردن سند",
            Filter = "PDF و تصاویر|*.pdf;*.jpg;*.jpeg;*.png;*.bmp|PDF|*.pdf|تصاویر|*.jpg;*.jpeg;*.png;*.bmp",
            Multiselect = true
        };
        if (dlg.ShowDialog(this) != true) return;
        foreach (var f in dlg.FileNames) await OpenDocumentAsync(f);
    }

    private void Recent_Click(object s, RoutedEventArgs e)
    {
        if (_db == null) return;
        RecentMenu.Items.Clear();
        var items = _db.Recent(15);
        if (items.Count == 0)
            RecentMenu.Items.Add(new MenuItem { Header = "(موردی نیست)", IsEnabled = false });
        foreach (var rec in items)
        {
            bool exists = File.Exists(rec.Path);
            var mi = new MenuItem
            {
                Header = System.IO.Path.GetFileName(rec.Path) + (exists ? "" : "  (فایل پیدا نشد)"),
                ToolTip = rec.Path
            };
            var path = rec.Path;
            mi.Click += async (_, _) => await OpenDocumentAsync(path);
            RecentMenu.Items.Add(mi);
        }
        RecentMenu.PlacementTarget = RecentButton;
        RecentMenu.IsOpen = true;
    }

    private async void Window_Drop(object s, DragEventArgs e)
    {
        if (e.Data.GetData(DataFormats.FileDrop) is not string[] files) return;
        foreach (var f in files)
            if (DocumentSource.IsSupported(f)) await OpenDocumentAsync(f);
    }

    // ------------------------------------------------------------ save / export / backup

    private void Save_Click(object s, RoutedEventArgs e)
    {
        CurrentView?.FlushSave();
        StatusText.Text = "ذخیره شد ✓";
    }

    private async void Export_Click(object s, RoutedEventArgs e)
    {
        var view = CurrentView;
        if (view == null || _db == null) { Dialogs.Info(this, "ابتدا یک سند باز کنید."); return; }

        var dlg = new SaveFileDialog
        {
            Title = "ذخیره PDF همراه با یادداشت‌ها",
            Filter = "PDF|*.pdf",
            FileName = System.IO.Path.GetFileNameWithoutExtension(view.FileName) + "-annotated.pdf",
            OverwritePrompt = true
        };
        if (dlg.ShowDialog(this) != true) return;

        if (string.Equals(System.IO.Path.GetFullPath(dlg.FileName), System.IO.Path.GetFullPath(view.FilePath),
                StringComparison.OrdinalIgnoreCase))
        {
            Dialogs.Error(this, "مسیر خروجی نمی‌تواند همان فایل اصلی باشد. فایل اصلی هرگز بازنویسی نمی‌شود.\nنام یا مسیر دیگری انتخاب کنید.");
            return;
        }

        view.FlushSave();
        IsEnabled = false;
        Mouse.OverrideCursor = Cursors.Wait;
        try
        {
            var progress = new Progress<(int Done, int Total)>(p =>
                StatusText.Text = $"خروجی PDF: صفحه {p.Done} از {p.Total}…");
            await ExportService.ExportAsync(view.Source, _db, view.DocId, view.Entries, dlg.FileName, progress, CancellationToken.None);
            StatusText.Text = "خروجی ساخته شد ✓";
            Dialogs.Info(this, "فایل PDF با موفقیت ساخته شد:\n" + dlg.FileName +
                "\n\nتوجه: در این نسخه هر صفحه به‌صورت تصویر ذخیره می‌شود (متن قابل جست‌وجوی PDF اصلی در خروجی نیست).");
        }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            StatusText.Text = "";
            Dialogs.Error(this, "ساخت PDF ناموفق بود:\n" + ex.Message);
        }
        finally
        {
            Mouse.OverrideCursor = null;
            IsEnabled = true;
        }
    }

    private void Backup_Click(object s, RoutedEventArgs e)
    {
        if (_db == null) return;
        var dlg = new SaveFileDialog
        {
            Title = "نسخه پشتیبان از همه یادداشت‌ها",
            Filter = "پشتیبان درس‌یار|*.db",
            FileName = $"DarsYar-backup-{DateTime.Now:yyyyMMdd-HHmm}.db"
        };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            foreach (var t in _tabs) t.View.FlushSave();
            _db.BackupTo(dlg.FileName);
            Dialogs.Info(this, "نسخه پشتیبان ساخته شد:\n" + dlg.FileName);
        }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            Dialogs.Error(this, "پشتیبان‌گیری ناموفق بود:\n" + ex.Message);
        }
    }

    // ------------------------------------------------------------ tools

    private void Tool_Checked(object s, RoutedEventArgs e)
    {
        if (_syncing) return;
        if (s is RadioButton { Tag: string tag } && Enum.TryParse<Tool>(tag, out var t))
            ToolState.Instance.SetTool(t);
    }

    /// <summary>Keeps both tool strips (normal + full screen) showing the active tool.</summary>
    private void SyncTools()
    {
        _syncing = true;
        try
        {
            string active = ToolState.Instance.Tool.ToString();
            foreach (var rb in TopPanel.Children.OfType<RadioButton>().Concat(FsPanel.Children.OfType<RadioButton>()))
                rb.IsChecked = rb.Tag as string == active;
        }
        finally { _syncing = false; }
    }

    private void Thickness_Changed(object s, RoutedPropertyChangedEventArgs<double> e)
    {
        if (IsLoaded) ToolState.Instance.SetThickness(e.NewValue);
    }

    private void ThickPlus_Click(object s, RoutedEventArgs e) => ChangeThickness(+1);
    private void ThickMinus_Click(object s, RoutedEventArgs e) => ChangeThickness(-1);

    private void ChangeThickness(double delta)
    {
        double v = Math.Clamp(ToolState.Instance.Thickness + delta, 1, 24);
        ThicknessSlider.Value = v;                 // raises ValueChanged -> ToolState
        if (!IsLoaded) ToolState.Instance.SetThickness(v);
    }

    private void AutoSave_Changed(object s, RoutedEventArgs e)
    {
        if (AutoSaveBox == null) return;   // raised while the window is still being built
        ToolState.Instance.SetAutoSave(AutoSaveBox.IsChecked == true);
    }

    private void Fill_Click(object s, RoutedEventArgs e) => CurrentView?.SetSelectedFill(ToolState.Instance.PenColor);
    private void NoFill_Click(object s, RoutedEventArgs e) => CurrentView?.SetSelectedFill(null);

    private void TouchInk_Changed(object s, RoutedEventArgs e)
    {
        if (TouchInkBox == null) return;
        ToolState.Instance.SetAllowTouchInk(TouchInkBox.IsChecked == true);
    }

    private void Undo_Click(object s, RoutedEventArgs e) => CurrentView?.Undo();
    private void Redo_Click(object s, RoutedEventArgs e) => CurrentView?.Redo();
    private void DeleteSel_Click(object s, RoutedEventArgs e) => CurrentView?.DeleteSelection();

    private void AddImage_Click(object s, RoutedEventArgs e)
    {
        if (CurrentView == null) { Dialogs.Info(this, "ابتدا یک سند باز کنید."); return; }
        CurrentView.AddImage(this);
    }

    private void Theme_Click(object s, RoutedEventArgs e)
    {
        _dark = !_dark;
        ThemeManager.Apply(_dark);
    }

    // ------------------------------------------------------------ full screen

    private void Fullscreen_Click(object s, RoutedEventArgs e) => ToggleFullscreen();

    private void ToggleFullscreen()
    {
        _fullscreen = !_fullscreen;
        if (_fullscreen)
        {
            _prevState = WindowState;
            _prevStyle = WindowStyle;
            WindowState = WindowState.Normal;
            WindowStyle = WindowStyle.None;
            WindowState = WindowState.Maximized;
            TopBar.Visibility = Visibility.Collapsed;
            TabBarHost.Visibility = Visibility.Collapsed;
            FsStrip.Visibility = Visibility.Visible;
        }
        else
        {
            FsStrip.Visibility = Visibility.Collapsed;
            TopBar.Visibility = Visibility.Visible;
            TabBarHost.Visibility = Visibility.Visible;
            WindowStyle = _prevStyle;
            WindowState = _prevState;
        }
        CurrentView?.SetChrome(!_fullscreen);
        SyncTools();
    }

    private void FsOrient_Click(object s, RoutedEventArgs e)
    {
        _fsVertical = !_fsVertical;
        FsPanel.Orientation = _fsVertical ? Orientation.Vertical : Orientation.Horizontal;
        FsColors.Orientation = _fsVertical ? Orientation.Vertical : Orientation.Horizontal;
        FsStrip.HorizontalAlignment = _fsVertical ? HorizontalAlignment.Right : HorizontalAlignment.Center;
        FsStrip.VerticalAlignment = _fsVertical ? VerticalAlignment.Center : VerticalAlignment.Bottom;
    }

    // ------------------------------------------------------------ keyboard / closing

    private void Window_PreviewKeyDown(object s, KeyEventArgs e)
    {
        bool ctrl = Keyboard.Modifiers == ModifierKeys.Control;
        bool typing = Keyboard.FocusedElement is TextBox;

        if (e.Key == Key.F11) { ToggleFullscreen(); e.Handled = true; }
        else if (e.Key == Key.Escape && _fullscreen) { ToggleFullscreen(); e.Handled = true; }
        else if (ctrl && e.Key == Key.O) { Open_Click(s, e); e.Handled = true; }
        else if (ctrl && e.Key == Key.S) { Save_Click(s, e); e.Handled = true; }
        else if (ctrl && !typing && e.Key == Key.Z) { CurrentView?.Undo(); e.Handled = true; }
        else if (ctrl && !typing && e.Key == Key.Y) { CurrentView?.Redo(); e.Handled = true; }
        else if (!typing && e.Key == Key.Delete) { CurrentView?.DeleteSelection(); e.Handled = true; }
        else if (!typing && e.Key == Key.PageDown) { CurrentView?.NextPage(); e.Handled = true; }
        else if (!typing && e.Key == Key.PageUp) { CurrentView?.PrevPage(); e.Handled = true; }
    }

    private void Window_Closing(object? s, System.ComponentModel.CancelEventArgs e)
    {
        bool save = true;
        var unsaved = _tabs.Where(t => t.View.HasUnsavedChanges).ToList();
        if (unsaved.Count > 0)
        {
            var names = string.Join("\n", unsaved.Select(t => "• " + t.View.FileName));
            var r = Dialogs.AskSave(this, "تغییرات ذخیره‌نشده در این اسناد هست:\n" + names + "\n\nقبل از بستن ذخیره شود؟");
            if (r == MessageBoxResult.Cancel) { e.Cancel = true; return; }
            save = r == MessageBoxResult.Yes;
        }

        if (save)
        {
            // prove the data reached the database before the window is allowed to close
            foreach (var t in _tabs)
            {
                if (!t.View.TrySave())
                {
                    Dialogs.Error(this, "ذخیره‌سازی «" + t.View.FileName + "» انجام نشد؛ برنامه بسته نمی‌شود تا چیزی از دست نرود.\nجزئیات: " + AppPaths.LogFile);
                    e.Cancel = true;
                    return;
                }
            }
        }

        foreach (var t in _tabs)
        {
            try { t.View.CloseDocument(save); }
            catch (Exception ex) { AppPaths.LogError(ex); }
        }
        Database.ClearPools();
    }
}
