using System.Windows;
using System.Windows.Controls;

namespace DarsYar;

/// <summary>Tiny "enter a text" dialog (WPF has no InputBox).</summary>
public sealed class PromptWindow : Window
{
    private readonly TextBox _box;

    private PromptWindow(string title, string label, string defaultText)
    {
        Title = title;
        Width = 380;
        SizeToContent = SizeToContent.Height;
        ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        FlowDirection = FlowDirection.RightToLeft;
        FontFamily = new System.Windows.Media.FontFamily("Segoe UI");
        FontSize = 14;

        var stack = new StackPanel { Margin = new Thickness(16) };
        stack.Children.Add(new TextBlock { Text = label, Margin = new Thickness(0, 0, 0, 8) });
        _box = new TextBox { Text = defaultText, MinHeight = 40, FontSize = 16, VerticalContentAlignment = VerticalAlignment.Center };
        stack.Children.Add(_box);

        var ok = new Button { Content = "تأیید", MinWidth = 90, MinHeight = 40, Margin = new Thickness(0, 0, 8, 0), IsDefault = true };
        var cancel = new Button { Content = "انصراف", MinWidth = 90, MinHeight = 40, IsCancel = true };
        ok.Click += (_, _) => { DialogResult = true; };
        var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 14, 0, 0) };
        row.Children.Add(ok);
        row.Children.Add(cancel);
        stack.Children.Add(row);
        Content = stack;

        Loaded += (_, _) => { _box.Focus(); _box.SelectAll(); };
    }

    /// <summary>Returns the entered text, or null if cancelled.</summary>
    public static string? Ask(Window? owner, string title, string label, string defaultText)
    {
        var w = new PromptWindow(title, label, defaultText) { Owner = owner };
        return w.ShowDialog() == true ? w._box.Text.Trim() : null;
    }
}
