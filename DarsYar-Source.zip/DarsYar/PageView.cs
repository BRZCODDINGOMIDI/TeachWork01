using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DarsYar.Services;

namespace DarsYar;

/// <summary>
/// One page in the continuous scroll view. The page is a light white placeholder until it is
/// "realized" (near the viewport): then the page image, image layer, ink canvas and notes layer are created.
/// All coordinates inside are stable page coordinates (96-dpi units at zoom 1).
/// </summary>
public sealed class PageView : Grid, IShapeHost
{
    public const double Gap = 14;

    private sealed class UndoEntry
    {
        public StrokeCollection Added { get; set; } = new();
        public StrokeCollection Removed { get; set; } = new();
    }

    private readonly DocumentView _doc;
    private readonly Stack<UndoEntry> _undo = new();
    private readonly Stack<UndoEntry> _redo = new();
    private bool _suppress;
    private bool _inSelection;
    private ShapeElement? _creating;
    private Point _createStart;

    public PageEntry Entry { get; }
    public int Index { get; set; }
    public bool Dirty { get; set; }
    public bool Loading { get; set; }
    public int Generation { get; set; }
    public double RenderedScale { get; set; }

    public Image? Bg { get; private set; }
    public Canvas? ObjectLayer { get; private set; }
    public InkCanvas? Ink { get; private set; }
    public Canvas? NotesLayer { get; private set; }
    public bool Realized => Ink != null;

    public PageView(DocumentView doc, PageEntry entry, int index)
    {
        _doc = doc;
        Entry = entry;
        Index = index;
        Width = entry.Width;
        Height = entry.Height;
        Background = Brushes.White;
        HorizontalAlignment = HorizontalAlignment.Center;
        Margin = new Thickness(0, 0, 0, Gap);
        ClipToBounds = true;
    }

    // ------------------------------------------------------------------ lifecycle

    public void CreateLayers()
    {
        if (Realized) return;

        Bg = new Image { Stretch = Stretch.Fill, IsHitTestVisible = false };
        RenderOptions.SetBitmapScalingMode(Bg, BitmapScalingMode.HighQuality);
        ObjectLayer = new Canvas { Background = Brushes.Transparent, IsHitTestVisible = false };
        var ink = new InkCanvas { Background = Brushes.Transparent, EditingMode = InkCanvasEditingMode.None };
        Stylus.SetIsFlicksEnabled(ink, false);
        Stylus.SetIsPressAndHoldEnabled(ink, false);
        Stylus.SetIsTapFeedbackEnabled(ink, false);
        Stylus.SetIsTouchFeedbackEnabled(ink, false);
        Ink = ink;
        NotesLayer = new Canvas { ClipToBounds = true, IsHitTestVisible = false };

        Children.Add(Bg);
        Children.Add(ObjectLayer);
        Children.Add(ink);
        Children.Add(NotesLayer);

        ink.Strokes.StrokesChanged += OnStrokesChanged;
        ink.StrokeCollected += OnStrokeCollected;
        ink.SelectionChanged += OnSelectionChanged;
        ink.SelectionMoved += (_, _) => MarkDirty();
        ink.SelectionResized += (_, _) => MarkDirty();

        ink.PreviewMouseMove += (_, e) => { if (e.StylusDevice == null) _doc.OnMouseSeen(); };
        ink.StylusInRange += (_, e) => _doc.OnStylusInRange(e.StylusDevice);
        ink.StylusOutOfRange += (_, _) => _doc.OnStylusOutOfRange();
        ink.PreviewStylusDown += (_, _) => _doc.OnPenDown(this);
        ink.PreviewStylusUp += (_, _) => _doc.OnPenUp();
        ink.PreviewMouseLeftButtonDown += (_, e) => { if (e.StylusDevice == null) _doc.OnPenDown(this); };
        ink.PreviewMouseLeftButtonUp += (_, e) => { if (e.StylusDevice == null) _doc.OnPenUp(); };
        ink.PreviewTouchDown += (_, _) => _doc.OnPenDown(this);
        ink.PreviewTouchUp += (_, _) => _doc.OnPenUp();

        ObjectLayer.MouseLeftButtonDown += ObjectLayer_MouseLeftButtonDown;
        ApplyTool();
    }

    /// <summary>Drops all heavy content. Caller must have saved first.</summary>
    public void ClearContent()
    {
        _creating = null;
        Children.Clear();
        Bg = null;
        ObjectLayer = null;
        Ink = null;
        NotesLayer = null;
        _undo.Clear();
        _redo.Clear();
        Dirty = false;
        RenderedScale = 0;
    }

    public void SetBackground(BitmapSource bmp, double scale)
    {
        if (Bg == null) return;
        Bg.Source = bmp;
        RenderedScale = scale;
    }

    // ------------------------------------------------------------------ tools & input mode

    public void ApplyTool()
    {
        if (Ink == null || ObjectLayer == null || NotesLayer == null) return;
        var t = ToolState.Instance;
        var da = new DrawingAttributes
        {
            FitToCurve = true,
            IgnorePressure = false,
            StylusTip = StylusTip.Ellipse,
            Color = t.PenColor,
            Width = t.Thickness,
            Height = t.Thickness,
            IsHighlighter = false
        };

        if (t.Tool == Tool.Highlighter)
        {
            da.IsHighlighter = true;
            da.IgnorePressure = true;
            da.Color = t.HighlighterColor;
            da.StylusTip = StylusTip.Rectangle;
            da.Width = t.Thickness * 4;
            da.Height = t.Thickness * 4;
        }

        Ink.DefaultDrawingAttributes = da;
        double er = t.Thickness * 3 + 6;
        Ink.EraserShape = new EllipseStylusShape(er, er);

        // Layers (z): page image 0, objects 1 (7 while editing objects), ink 5, notes 9.
        // In Select / Note / Shape modes the object layer is lifted above the ink so objects can be grabbed.
        bool note = t.Tool == Tool.Note;
        bool shape = t.Tool == Tool.Shape;
        bool select = t.Tool == Tool.Select;
        bool objectsActive = note || shape || select;

        Ink.IsHitTestVisible = !(note || shape);
        ObjectLayer.IsHitTestVisible = objectsActive;
        ObjectLayer.Background = (note || shape) ? Brushes.Transparent : null;   // null: empty clicks fall through to the ink lasso
        NotesLayer.IsHitTestVisible = note || select;
        SetZIndex(Bg!, 0);
        SetZIndex(ObjectLayer, objectsActive ? 7 : 1);
        SetZIndex(Ink, 5);
        SetZIndex(NotesLayer, 9);
        UpdateMode();
    }

    private static InkCanvasEditingMode DesiredMode(Tool t) => t switch
    {
        Tool.Eraser => InkCanvasEditingMode.EraseByStroke,
        Tool.EraserPoint => InkCanvasEditingMode.EraseByPoint,
        Tool.EraserLasso => InkCanvasEditingMode.Select,
        Tool.Select => InkCanvasEditingMode.Select,
        Tool.Note => InkCanvasEditingMode.None,
        Tool.Shape => InkCanvasEditingMode.None,
        _ => InkCanvasEditingMode.Ink
    };

    public void UpdateMode()
    {
        if (Ink == null) return;
        var mode = DesiredMode(ToolState.Instance.Tool);
        if (_doc.Gesture)
        {
            mode = InkCanvasEditingMode.None;      // two fingers = scroll / zoom
        }
        else
        {
            bool allowed = ToolState.Instance.AllowTouchInk || _doc.PenInRange || _doc.MouseActive;
            if (!allowed) mode = InkCanvasEditingMode.None;
            else if (_doc.PenInRange && _doc.PenInverted && mode == InkCanvasEditingMode.Ink)
                mode = InkCanvasEditingMode.EraseByStroke;   // pen tail = eraser
        }
        if (Ink.EditingMode != mode) Ink.EditingMode = mode;
    }

    // ------------------------------------------------------------------ strokes, undo/redo

    private void MarkDirty()
    {
        if (_suppress) return;
        Dirty = true;
        _doc.OnPageDirty(this);
    }

    private void OnStrokesChanged(object? sender, StrokeCollectionChangedEventArgs e)
    {
        if (_suppress) return;
        _undo.Push(new UndoEntry
        {
            Added = new StrokeCollection(e.Added),
            Removed = new StrokeCollection(e.Removed)
        });
        _redo.Clear();
        _doc.ActivePage = this;
        MarkDirty();
    }

    public void Undo()
    {
        if (Ink == null || _undo.Count == 0) return;
        var e = _undo.Pop();
        _suppress = true;
        try
        {
            if (e.Added.Count > 0) Ink.Strokes.Remove(e.Added);
            if (e.Removed.Count > 0) Ink.Strokes.Add(e.Removed);
        }
        finally { _suppress = false; }
        _redo.Push(e);
        MarkDirty();
    }

    public void Redo()
    {
        if (Ink == null || _redo.Count == 0) return;
        var e = _redo.Pop();
        _suppress = true;
        try
        {
            if (e.Removed.Count > 0) Ink.Strokes.Remove(e.Removed);
            if (e.Added.Count > 0) Ink.Strokes.Add(e.Added);
        }
        finally { _suppress = false; }
        _undo.Push(e);
        MarkDirty();
    }

    public void DeleteSelection()
    {
        if (Ink == null) return;
        var sel = Ink.GetSelectedStrokes();
        if (sel.Count == 0) return;
        Ink.Strokes.Remove(sel);
        Ink.Select(new StrokeCollection());
    }

    /// <summary>Eraser "lasso" mode: whatever the lasso selects is deleted immediately.</summary>
    private void OnSelectionChanged(object? sender, EventArgs e)
    {
        if (_inSelection || Ink == null) return;
        if (ToolState.Instance.Tool != Tool.EraserLasso) return;
        var sel = Ink.GetSelectedStrokes();
        if (sel.Count == 0) return;
        _inSelection = true;
        try
        {
            Ink.Strokes.Remove(sel);
            Ink.Select(new StrokeCollection());
        }
        finally { _inSelection = false; }
    }

    private void Drop(Stroke s)
    {
        if (Ink == null) return;
        _suppress = true;
        try { Ink.Strokes.Remove(s); }
        finally { _suppress = false; }
        if (_undo.Count > 0 && _undo.Peek().Added.Contains(s)) _undo.Pop();
    }

    private void OnStrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
    {
        if (Ink == null) return;

        // the first finger started a stroke, then a second finger arrived: it was a scroll/zoom gesture
        if (_doc.DiscardStrokes) { Drop(e.Stroke); return; }
    }

    // ------------------------------------------------------------------ notes

    private void ObjectLayer_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (ObjectLayer == null || !ReferenceEquals(e.OriginalSource, ObjectLayer)) return;
        var t = ToolState.Instance;

        if (t.Tool == Tool.Note)
        {
            var p = e.GetPosition(ObjectLayer);
            AddNoteElement(new NoteItem
            {
                X = Math.Clamp(p.X, 0, Math.Max(0, Entry.Width - 160)),
                Y = Math.Clamp(p.Y, 0, Math.Max(0, Entry.Height - 80)),
                W = 0,
                Text = ""
            }, true);
            MarkDirty();
            e.Handled = true;
        }
        else if (t.Tool == Tool.Shape)
        {
            // start drawing a new shape object (like Paint): drag from one corner to the opposite one
            _createStart = e.GetPosition(ObjectLayer);
            var item = new ShapeItem
            {
                Kind = t.Shape,
                X = _createStart.X,
                Y = _createStart.Y,
                W = 1,
                H = ShapeBuilder.IsLineLike(t.Shape) ? 16 : 1,
                Stroke = t.PenColor.ToString(),
                Thickness = t.Thickness
            };
            _creating = new ShapeElement(item, this);
            ObjectLayer.Children.Add(_creating);
            ObjectLayer.CaptureMouse();
            e.Handled = true;
        }
    }

    private void ObjectLayer_MouseMove(object sender, MouseEventArgs e)
    {
        if (_creating == null || ObjectLayer == null) return;
        if (_doc.Gesture || e.LeftButton != MouseButtonState.Pressed) { CancelCreate(); return; }

        var p = e.GetPosition(ObjectLayer);
        var it = _creating.Item;
        if (ShapeBuilder.IsLineLike(it.Kind))
        {
            var v = p - _createStart;
            double len = Math.Max(1, v.Length);
            var c = new Point((_createStart.X + p.X) / 2, (_createStart.Y + p.Y) / 2);
            it.W = len;
            it.H = 16;
            it.X = c.X - it.W / 2;
            it.Y = c.Y - it.H / 2;
            it.Angle = Math.Atan2(v.Y, v.X) * 180.0 / Math.PI;
        }
        else
        {
            it.X = Math.Min(_createStart.X, p.X);
            it.Y = Math.Min(_createStart.Y, p.Y);
            it.W = Math.Max(1, Math.Abs(p.X - _createStart.X));
            it.H = Math.Max(1, Math.Abs(p.Y - _createStart.Y));
            it.Angle = 0;
        }
        _creating.ApplyLayout();
    }

    private void ObjectLayer_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (_creating == null || ObjectLayer == null) return;
        ObjectLayer.ReleaseMouseCapture();
        var el = _creating;
        _creating = null;
        var it = el.Item;
        bool tiny = ShapeBuilder.IsLineLike(it.Kind) ? it.W < 8 : (it.W < 8 && it.H < 8);
        if (tiny)
        {
            ObjectLayer.Children.Remove(el);
        }
        else
        {
            _doc.SelectShape(el);
            MarkDirty();
            ToolState.Instance.SetTool(Tool.Select);   // now it can be moved / resized / rotated / recoloured
        }
        e.Handled = true;
    }

    private void CancelCreate()
    {
        if (_creating == null || ObjectLayer == null) return;
        ObjectLayer.ReleaseMouseCapture();
        ObjectLayer.Children.Remove(_creating);
        _creating = null;
    }

    // ---- IShapeHost
    public void ShapeChanged() => MarkDirty();
    public void ShapeSelected(ShapeElement element) => _doc.SelectShape(element);
    public Point MouseInLayer() => ObjectLayer != null ? Mouse.GetPosition(ObjectLayer) : new Point();

    public void ShapeDeleteRequested(ShapeElement element)
    {
        ObjectLayer?.Children.Remove(element);
        if (ReferenceEquals(_doc.SelectedShape, element)) _doc.SelectShape(null);
        MarkDirty();
    }

    private void AddShapeElement(ShapeItem item) => ObjectLayer?.Children.Add(new ShapeElement(item, this));

    /// <summary>Recolours strokes selected with the lasso. Returns false if none are selected.</summary>
    public bool RecolorSelection(Color c)
    {
        if (Ink == null) return false;
        var sel = Ink.GetSelectedStrokes();
        if (sel.Count == 0) return false;
        foreach (var st in sel) st.DrawingAttributes.Color = c;
        MarkDirty();
        return true;
    }

    private void AddNoteElement(NoteItem item, bool focus)
    {
        if (NotesLayer == null) return;
        var layer = NotesLayer;

        var tb = new TextBox
        {
            Text = item.Text,
            AcceptsReturn = true,
            TextWrapping = TextWrapping.Wrap,
            MinWidth = 140,
            MaxWidth = 600,
            BorderThickness = new Thickness(0),
            Background = new SolidColorBrush(Color.FromRgb(255, 249, 196)),
            Foreground = Brushes.Black,
            FontSize = 16,
            Padding = new Thickness(6),
            FlowDirection = FlowDirection.RightToLeft
        };
        if (item.W > 0) tb.Width = item.W;
        tb.TextChanged += (_, _) => MarkDirty();

        var gold = new SolidColorBrush(Color.FromRgb(212, 175, 55));
        var drag = new Thumb
        {
            Height = NoteItem.HeaderHeight - 2,
            Background = gold,
            Cursor = Cursors.SizeAll,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var close = new Button
        {
            Content = "✕",
            Width = 28,
            Height = NoteItem.HeaderHeight - 2,
            Padding = new Thickness(0),
            BorderThickness = new Thickness(0),
            Background = gold,
            Foreground = Brushes.Black
        };
        var header = new DockPanel { LastChildFill = true };
        DockPanel.SetDock(close, Dock.Right);
        header.Children.Add(close);
        header.Children.Add(drag);

        var stack = new StackPanel();
        stack.Children.Add(header);
        stack.Children.Add(tb);
        var box = new Border
        {
            BorderBrush = gold,
            BorderThickness = new Thickness(1),
            Child = stack,
            Tag = tb
        };
        Canvas.SetLeft(box, item.X);
        Canvas.SetTop(box, item.Y);

        drag.DragDelta += (_, e) =>
        {
            Canvas.SetLeft(box, Math.Clamp(Canvas.GetLeft(box) + e.HorizontalChange, 0, Math.Max(0, Entry.Width - 40)));
            Canvas.SetTop(box, Math.Clamp(Canvas.GetTop(box) + e.VerticalChange, 0, Math.Max(0, Entry.Height - 40)));
        };
        drag.DragCompleted += (_, _) => MarkDirty();
        close.Click += (_, _) => { layer.Children.Remove(box); MarkDirty(); };

        layer.Children.Add(box);
        if (focus) Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Input, new Action(() => tb.Focus()));
    }

    // ------------------------------------------------------------------ images

    public void AddImage(ImageItem item, BitmapSource bmp)
    {
        AddImageElement(item, bmp);
        MarkDirty();
    }

    private void AddImageElement(ImageItem item, BitmapSource bmp)
    {
        if (ObjectLayer == null) return;
        var layer = ObjectLayer;
        double aspect = item.W > 0 ? item.H / item.W : 1;

        var holder = new Grid { Width = item.W, Height = item.H, Tag = item };
        var img = new Image { Source = bmp, Stretch = Stretch.Fill };
        RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.HighQuality);

        var gold = new SolidColorBrush(Color.FromArgb(200, 212, 175, 55));
        var drag = new Thumb
        {
            Height = 20,
            Background = gold,
            Cursor = Cursors.SizeAll,
            VerticalAlignment = VerticalAlignment.Top,
            Margin = new Thickness(0, 0, 28, 0)
        };
        var close = new Button
        {
            Content = "✕",
            Width = 28,
            Height = 20,
            Padding = new Thickness(0),
            BorderThickness = new Thickness(0),
            Background = gold,
            Foreground = Brushes.Black,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Top
        };
        var resize = new Thumb
        {
            Width = 22,
            Height = 22,
            Background = new SolidColorBrush(Color.FromArgb(220, 37, 99, 235)),
            Cursor = Cursors.SizeNWSE,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Bottom
        };

        holder.Children.Add(img);
        holder.Children.Add(drag);
        holder.Children.Add(close);
        holder.Children.Add(resize);
        Canvas.SetLeft(holder, item.X);
        Canvas.SetTop(holder, item.Y);

        drag.DragDelta += (_, e) =>
        {
            Canvas.SetLeft(holder, Math.Clamp(Canvas.GetLeft(holder) + e.HorizontalChange, 0, Math.Max(0, Entry.Width - 40)));
            Canvas.SetTop(holder, Math.Clamp(Canvas.GetTop(holder) + e.VerticalChange, 0, Math.Max(0, Entry.Height - 40)));
        };
        drag.DragCompleted += (_, _) => MarkDirty();
        resize.DragDelta += (_, e) =>
        {
            double w = Math.Clamp(holder.Width + e.HorizontalChange, 40, Math.Max(40, Entry.Width * 2));
            holder.Width = w;
            holder.Height = w * aspect;
        };
        resize.DragCompleted += (_, _) => MarkDirty();
        close.Click += (_, _) => { layer.Children.Remove(holder); MarkDirty(); };

        layer.Children.Add(holder);
    }

    // ------------------------------------------------------------------ persistence

    public void LoadContent(byte[]? inkBytes, string? extrasJson)
    {
        if (Ink == null || NotesLayer == null || ObjectLayer == null) return;
        _suppress = true;
        try
        {
            Ink.Strokes.Clear();
            if (inkBytes != null && inkBytes.Length > 0)
            {
                try
                {
                    using var ms = new MemoryStream(inkBytes);
                    Ink.Strokes.Add(new StrokeCollection(ms));
                }
                catch (Exception ex) { AppPaths.LogError(ex); }
            }

            NotesLayer.Children.Clear();
            ObjectLayer.Children.Clear();
            PageExtras extras;
            try { extras = PageExtras.Parse(extrasJson); }
            catch (Exception ex) { AppPaths.LogError(ex); extras = new PageExtras(); }

            foreach (var img in extras.Images)
            {
                var bytes = _doc.Db.LoadImage(img.Id);
                if (bytes == null) continue;
                try { AddImageElement(img, DocumentSource.Decode(bytes)); }
                catch (Exception ex) { AppPaths.LogError(ex); }
            }
            foreach (var sh in extras.Shapes) AddShapeElement(sh);
            foreach (var n in extras.Notes) AddNoteElement(n, false);
        }
        finally { _suppress = false; }
        _undo.Clear();
        _redo.Clear();
        Dirty = false;
    }

    public (byte[]? Ink, string? Extras) Serialize()
    {
        byte[]? ink = null;
        if (Ink != null && Ink.Strokes.Count > 0)
        {
            using var ms = new MemoryStream();
            Ink.Strokes.Save(ms, true);
            ink = ms.ToArray();
        }

        var extras = new PageExtras();
        if (ObjectLayer != null)
            foreach (var child in ObjectLayer.Children)
                if (child is Grid { Tag: ImageItem src } g)
                    extras.Images.Add(new ImageItem
                    {
                        Id = src.Id,
                        X = Canvas.GetLeft(g),
                        Y = Canvas.GetTop(g),
                        W = g.Width,
                        H = g.Height
                    });
        if (ObjectLayer != null)
            foreach (var child in ObjectLayer.Children)
                if (child is ShapeElement se)
                    extras.Shapes.Add(new ShapeItem
                    {
                        Kind = se.Item.Kind, X = se.Item.X, Y = se.Item.Y, W = se.Item.W, H = se.Item.H,
                        Angle = se.Item.Angle, Stroke = se.Item.Stroke, Fill = se.Item.Fill, Thickness = se.Item.Thickness
                    });
        if (NotesLayer != null)
            foreach (var child in NotesLayer.Children)
                if (child is Border { Tag: TextBox tb } box)
                    extras.Notes.Add(new NoteItem
                    {
                        X = Canvas.GetLeft(box),
                        Y = Canvas.GetTop(box),
                        W = tb.ActualWidth > 0 ? tb.ActualWidth : tb.Width,
                        Text = tb.Text
                    });
        return (ink, extras.ToJson());
    }
}
