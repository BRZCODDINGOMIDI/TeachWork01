using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DarsYar.Services;
using ShapePath = System.Windows.Shapes.Path;

namespace DarsYar;

/// <summary>
/// One page in the continuous scroll view. The page is a light white placeholder until it is
/// "realized" (near the viewport): then the page image, object layer (images + shapes), ink canvas and
/// notes layer are created. All coordinates are stable page coordinates (96-dpi units at zoom 1).
/// Undo/Redo works on snapshots of the whole page content (ink + shapes + images + notes).
/// </summary>
public sealed class PageView : Grid, IShapeHost
{
    public const double Gap = 14;
    private const int MaxUndo = 60;

    private sealed record PageState(byte[]? Ink, string? Extras);

    private readonly DocumentView _doc;
    private readonly List<PageState> _undo = new();
    private readonly List<PageState> _redo = new();
    private PageState _last = new(null, null);

    private bool _suppress;
    private bool _inSelection;

    // shape being dragged out (lightweight preview; the real object is created on release)
    private ShapeItem? _dragItem;
    private ShapePath? _preview;
    private Point _dragStart;

    public PageEntry Entry { get; }
    public int Index { get; set; }
    public bool Dirty { get; set; }
    public bool Loading { get; set; }
    public int Generation { get; set; }
    public double RenderedScale { get; set; }

    public Image? Bg { get; private set; }
    public Canvas? ObjectLayer { get; private set; }
    public InkCanvas? Ink { get; private set; }
    public Canvas? NotesLayer { get; private set; }
    public bool Realized => Ink != null;

    public PageView(DocumentView doc, PageEntry entry, int index)
    {
        _doc = doc;
        Entry = entry;
        Index = index;
        Width = entry.Width;
        Height = entry.Height;
        Background = Brushes.White;
        HorizontalAlignment = HorizontalAlignment.Center;
        Margin = new Thickness(0, 0, 0, Gap);
        ClipToBounds = true;
    }

    // ------------------------------------------------------------------ lifecycle

    public void CreateLayers()
    {
        if (Realized) return;

        Bg = new Image { Stretch = Stretch.Fill, IsHitTestVisible = false };
        RenderOptions.SetBitmapScalingMode(Bg, BitmapScalingMode.HighQuality);
        ObjectLayer = new Canvas { IsHitTestVisible = false };
        var ink = new InkCanvas { Background = Brushes.Transparent, EditingMode = InkCanvasEditingMode.None };
        Stylus.SetIsFlicksEnabled(ink, false);
        Stylus.SetIsPressAndHoldEnabled(ink, false);
        Stylus.SetIsTapFeedbackEnabled(ink, false);
        Stylus.SetIsTouchFeedbackEnabled(ink, false);
        Ink = ink;
        NotesLayer = new Canvas { ClipToBounds = true, IsHitTestVisible = false };

        Children.Add(Bg);
        Children.Add(ObjectLayer);
        Children.Add(ink);
        Children.Add(NotesLayer);

        ink.Strokes.StrokesChanged += OnStrokesChanged;
        ink.StrokeCollected += OnStrokeCollected;
        ink.SelectionChanged += OnSelectionChanged;
        ink.SelectionMoved += (_, _) => Commit();
        ink.SelectionResized += (_, _) => Commit();

        // Pen / touch / mouse all go through the InkCanvas. No mouse capture is used anywhere.
        ink.PreviewMouseMove += (_, e) =>
        {
            if (e.StylusDevice != null) return;
            _doc.OnMouseSeen();
            if (_dragItem != null && e.LeftButton == MouseButtonState.Pressed) UpdateDrag(e.GetPosition(ink));
        };
        ink.StylusInRange += (_, e) => _doc.OnStylusInRange(e.StylusDevice);
        ink.StylusOutOfRange += (_, _) => _doc.OnStylusOutOfRange();
        ink.PreviewStylusDown += (_, e) => { _doc.OnPenDown(this); BeginDrag(e.GetPosition(ink)); };
        ink.PreviewStylusMove += (_, e) => { if (_dragItem != null) UpdateDrag(e.GetPosition(ink)); };
        ink.PreviewStylusUp += (_, _) => _doc.OnPenUp();
        ink.PreviewMouseLeftButtonDown += (_, e) =>
        {
            if (e.StylusDevice != null) return;
            _doc.OnPenDown(this);
            BeginDrag(e.GetPosition(ink));
        };
        ink.PreviewMouseLeftButtonUp += (_, e) => { if (e.StylusDevice == null) _doc.OnPenUp(); };
        ink.PreviewTouchDown += (_, _) => _doc.OnPenDown(this);
        ink.PreviewTouchUp += (_, _) => _doc.OnPenUp();

        ObjectLayer.MouseLeftButtonDown += ObjectLayer_MouseLeftButtonDown;
        ApplyTool();
    }

    /// <summary>Drops all heavy content. Caller must have saved first.</summary>
    public void ClearContent()
    {
        CancelDrag();
        Children.Clear();
        Bg = null;
        ObjectLayer = null;
        Ink = null;
        NotesLayer = null;
        _undo.Clear();
        _redo.Clear();
        _last = new PageState(null, null);
        Dirty = false;
        RenderedScale = 0;
    }

    public void SetBackground(BitmapSource bmp, double scale)
    {
        if (Bg == null) return;
        Bg.Source = bmp;
        RenderedScale = scale;
    }

    // ------------------------------------------------------------------ tools & input mode

    public void ApplyTool()
    {
        if (Ink == null || ObjectLayer == null || NotesLayer == null) return;
        var t = ToolState.Instance;
        var da = new DrawingAttributes
        {
            FitToCurve = true,
            IgnorePressure = false,
            StylusTip = StylusTip.Ellipse,
            Color = t.PenColor,
            Width = t.Thickness,
            Height = t.Thickness,
            IsHighlighter = false
        };

        if (t.Tool == Tool.Shape)
        {
            // only a thin guide line while dragging; the real shape object is created on release
            da.Color = Color.FromRgb(37, 99, 235);
            da.Width = 1.5;
            da.Height = 1.5;
            da.IgnorePressure = true;
            da.FitToCurve = false;
        }
        else if (t.Tool == Tool.Highlighter)
        {
            da.IsHighlighter = true;
            da.IgnorePressure = true;
            da.Color = t.HighlighterColor;
            da.StylusTip = StylusTip.Rectangle;
            da.Width = t.Thickness * 4;
            da.Height = t.Thickness * 4;
        }

        Ink.DefaultDrawingAttributes = da;
        double er = t.Thickness * 3 + 6;
        Ink.EraserShape = new EllipseStylusShape(er, er);

        // Layers (z): page image 0, objects 1 (7 while editing objects), ink 5, notes 9.
        // In Select / Note modes the object layer is lifted above the ink so objects can be grabbed.
        bool note = t.Tool == Tool.Note;
        bool select = t.Tool == Tool.Select;
        bool objectsActive = note || select;

        Ink.IsHitTestVisible = !note;
        ObjectLayer.IsHitTestVisible = objectsActive;
        ObjectLayer.Background = note ? Brushes.Transparent : null;   // null: empty clicks fall through to the ink lasso
        NotesLayer.IsHitTestVisible = note || select;
        SetZIndex(Bg!, 0);
        SetZIndex(ObjectLayer, objectsActive ? 7 : 1);
        SetZIndex(Ink, 5);
        SetZIndex(NotesLayer, 9);
        UpdateMode();
    }

    private static InkCanvasEditingMode DesiredMode(Tool t) => t switch
    {
        Tool.Eraser => InkCanvasEditingMode.EraseByStroke,
        Tool.EraserPoint => InkCanvasEditingMode.EraseByPoint,
        Tool.EraserLasso => InkCanvasEditingMode.Select,
        Tool.Select => InkCanvasEditingMode.Select,
        Tool.Note => InkCanvasEditingMode.None,
        _ => InkCanvasEditingMode.Ink          // pen, highlighter, shape (guide stroke)
    };

    public void UpdateMode()
    {
        if (Ink == null) return;
        var mode = DesiredMode(ToolState.Instance.Tool);
        if (_doc.Gesture)
        {
            mode = InkCanvasEditingMode.None;      // two fingers = scroll / zoom
        }
        else
        {
            bool allowed = ToolState.Instance.AllowTouchInk || _doc.PenInRange || _doc.MouseActive;
            if (!allowed) mode = InkCanvasEditingMode.None;
            else if (_doc.PenInRange && _doc.PenInverted && mode == InkCanvasEditingMode.Ink)
                mode = InkCanvasEditingMode.EraseByStroke;   // pen tail = eraser
        }
        if (Ink.EditingMode != mode) Ink.EditingMode = mode;
    }

    // ------------------------------------------------------------------ undo / redo (whole-page snapshots)

    private void MarkDirty()
    {
        if (_suppress) return;
        Dirty = true;
        _doc.OnPageDirty(this);
    }

    /// <summary>A user action finished: remember the previous state for Undo.</summary>
    public void Commit()
    {
        if (_suppress || Ink == null) return;
        var now = Capture();
        if (SameState(now, _last)) { MarkDirty(); return; }
        _undo.Add(_last);
        if (_undo.Count > MaxUndo) _undo.RemoveAt(0);
        _redo.Clear();
        _last = now;
        _doc.ActivePage = this;
        MarkDirty();
    }

    private PageState Capture()
    {
        var (ink, extras) = Serialize();
        return new PageState(ink, extras);
    }

    private static bool SameState(PageState a, PageState b) =>
        a.Extras == b.Extras && (a.Ink?.Length ?? 0) == (b.Ink?.Length ?? 0) &&
        (a.Ink == null || b.Ink == null || a.Ink.AsSpan().SequenceEqual(b.Ink));

    public void Undo()
    {
        if (Ink == null || _undo.Count == 0) return;
        var state = _undo[_undo.Count - 1];
        _undo.RemoveAt(_undo.Count - 1);
        _redo.Add(_last);
        Restore(state);
    }

    public void Redo()
    {
        if (Ink == null || _redo.Count == 0) return;
        var state = _redo[_redo.Count - 1];
        _redo.RemoveAt(_redo.Count - 1);
        _undo.Add(_last);
        Restore(state);
    }

    private void Restore(PageState state)
    {
        _doc.SelectShape(null);
        ApplyContent(state.Ink, state.Extras);
        _last = state;
        Dirty = true;
        _doc.OnPageDirty(this);
    }

    private void OnStrokesChanged(object? sender, StrokeCollectionChangedEventArgs e)
    {
        if (_suppress) return;
        // the invisible guide stroke of the shape tool is not a user action
        if (ToolState.Instance.Tool == Tool.Shape) return;
        Commit();
    }

    public void DeleteSelection()
    {
        if (Ink == null) return;
        var sel = Ink.GetSelectedStrokes();
        if (sel.Count == 0) return;
        Ink.Strokes.Remove(sel);          // StrokesChanged -> Commit
        Ink.Select(new StrokeCollection());
    }

    /// <summary>Eraser "lasso" mode: whatever the lasso selects is deleted immediately.</summary>
    private void OnSelectionChanged(object? sender, EventArgs e)
    {
        if (_inSelection || Ink == null) return;
        if (ToolState.Instance.Tool != Tool.EraserLasso) return;
        var sel = Ink.GetSelectedStrokes();
        if (sel.Count == 0) return;
        _inSelection = true;
        try
        {
            Ink.Strokes.Remove(sel);
            Ink.Select(new StrokeCollection());
        }
        finally { _inSelection = false; }
    }

    /// <summary>Recolours strokes selected with the lasso. Returns false if none are selected.</summary>
    public bool RecolorSelection(Color c)
    {
        if (Ink == null) return false;
        var sel = Ink.GetSelectedStrokes();
        if (sel.Count == 0) return false;
        foreach (var st in sel) st.DrawingAttributes.Color = c;
        Commit();
        return true;
    }

    private void DropStroke(Stroke s, bool wasCommitted)
    {
        if (Ink == null) return;
        _suppress = true;
        try { Ink.Strokes.Remove(s); }
        finally { _suppress = false; }
        if (wasCommitted && _undo.Count > 0)
        {
            _last = _undo[_undo.Count - 1];      // forget the snapshot that included the dropped stroke
            _undo.RemoveAt(_undo.Count - 1);
        }
    }

    private void OnStrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
    {
        if (Ink == null) return;
        bool shapeTool = ToolState.Instance.Tool == Tool.Shape;

        // the first finger started a stroke, then a second finger arrived: it was a scroll/zoom gesture
        if (_doc.DiscardStrokes)
        {
            DropStroke(e.Stroke, !shapeTool);
            CancelDrag();
            return;
        }

        if (!shapeTool) return;

        // shape tool: the stroke was only the drag -> remove it and create the shape object
        var pts = e.Stroke.StylusPoints;
        DropStroke(e.Stroke, false);
        if (_dragItem == null || pts.Count < 2) { CancelDrag(); return; }

        var a = new Point(pts[0].X, pts[0].Y);
        var b = new Point(pts[pts.Count - 1].X, pts[pts.Count - 1].Y);
        var item = _dragItem;
        ApplyDrag(item, a, b);
        CancelDrag();

        bool tiny = ShapeBuilder.IsLineLike(item.Kind) ? item.W < 8 : (item.W < 8 && item.H < 8);
        if (tiny || ObjectLayer == null) return;

        var element = new ShapeElement(item, this);     // fully interactive (hit-testable, selectable, deletable)
        ObjectLayer.Children.Add(element);
        Commit();

        // switch tool after the ink event has finished (changing the editing mode inside it is risky)
        Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
        {
            ToolState.Instance.SetTool(Tool.Select);
            _doc.SelectShape(element);
        }));
    }

    // ------------------------------------------------------------------ shape dragging (preview only)

    private void BeginDrag(Point start)
    {
        if (ObjectLayer == null || ToolState.Instance.Tool != Tool.Shape) return;
        CancelDrag();
        var t = ToolState.Instance;
        _dragStart = start;
        _dragItem = new ShapeItem
        {
            Kind = t.Shape,
            X = start.X,
            Y = start.Y,
            W = 1,
            H = ShapeBuilder.IsLineLike(t.Shape) ? 16 : 1,
            Stroke = t.PenColor.ToString(),
            Thickness = t.Thickness
        };
        _preview = new ShapePath
        {
            Stroke = new SolidColorBrush(t.PenColor),
            StrokeThickness = t.Thickness,
            StrokeLineJoin = PenLineJoin.Round,
            StrokeStartLineCap = PenLineCap.Round,
            StrokeEndLineCap = PenLineCap.Round,
            IsHitTestVisible = false
        };
        ObjectLayer.Children.Add(_preview);
    }

    private void UpdateDrag(Point p)
    {
        if (_dragItem == null || _preview == null) return;
        if (_doc.Gesture) { CancelDrag(); return; }
        ApplyDrag(_dragItem, _dragStart, p);
        var it = _dragItem;
        _preview.Data = ShapeBuilder.CreateGeometry(it.Kind, Math.Max(1, it.W), Math.Max(1, it.H), it.Thickness, false);
        _preview.RenderTransform = new TransformGroup
        {
            Children = { new RotateTransform(it.Angle, it.W / 2, it.H / 2), new TranslateTransform(it.X, it.Y) }
        };
    }

    /// <summary>Fills the shape box from a drag a -> b (lines follow the drag direction).</summary>
    private static void ApplyDrag(ShapeItem it, Point a, Point b)
    {
        if (ShapeBuilder.IsLineLike(it.Kind))
        {
            var v = b - a;
            double len = Math.Max(1, v.Length);
            var c = new Point((a.X + b.X) / 2, (a.Y + b.Y) / 2);
            it.W = len;
            it.H = 16;
            it.X = c.X - it.W / 2;
            it.Y = c.Y - it.H / 2;
            it.Angle = Math.Atan2(v.Y, v.X) * 180.0 / Math.PI;
        }
        else
        {
            it.X = Math.Min(a.X, b.X);
            it.Y = Math.Min(a.Y, b.Y);
            it.W = Math.Max(1, Math.Abs(b.X - a.X));
            it.H = Math.Max(1, Math.Abs(b.Y - a.Y));
            it.Angle = 0;
        }
    }

    private void CancelDrag()
    {
        if (_preview != null) ObjectLayer?.Children.Remove(_preview);
        _preview = null;
        _dragItem = null;
    }

    // ------------------------------------------------------------------ IShapeHost

    public void ShapeChanged() => Commit();
    public void ShapeSelected(ShapeElement element) => _doc.SelectShape(element);
    public Point MouseInLayer() => ObjectLayer != null ? Mouse.GetPosition(ObjectLayer) : new Point();

    public void ShapeDeleteRequested(ShapeElement element)
    {
        if (ReferenceEquals(_doc.SelectedShape, element)) _doc.SelectShape(null);
        ObjectLayer?.Children.Remove(element);
        Commit();
    }

    private void AddShapeElement(ShapeItem item) => ObjectLayer?.Children.Add(new ShapeElement(item, this));

    // ------------------------------------------------------------------ notes

    private void ObjectLayer_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (ObjectLayer == null || !ReferenceEquals(e.OriginalSource, ObjectLayer)) return;
        if (ToolState.Instance.Tool != Tool.Note) return;

        var p = e.GetPosition(ObjectLayer);
        AddNoteElement(new NoteItem
        {
            X = Math.Clamp(p.X, 0, Math.Max(0, Entry.Width - 160)),
            Y = Math.Clamp(p.Y, 0, Math.Max(0, Entry.Height - 80)),
            W = 0,
            Text = ""
        }, true);
        Commit();
        e.Handled = true;
    }

    private void AddNoteElement(NoteItem item, bool focus)
    {
        if (NotesLayer == null) return;
        var layer = NotesLayer;

        var tb = new TextBox
        {
            Text = item.Text,
            AcceptsReturn = true,
            TextWrapping = TextWrapping.Wrap,
            MinWidth = 140,
            MaxWidth = 600,
            BorderThickness = new Thickness(0),
            Background = new SolidColorBrush(Color.FromRgb(255, 249, 196)),
            Foreground = Brushes.Black,
            FontSize = 16,
            Padding = new Thickness(6),
            FlowDirection = FlowDirection.RightToLeft
        };
        if (item.W > 0) tb.Width = item.W;
        tb.TextChanged += (_, _) => MarkDirty();                   // keystrokes: just mark dirty
        tb.LostKeyboardFocus += (_, _) => Commit();                // finished editing: one undo step

        var gold = new SolidColorBrush(Color.FromRgb(212, 175, 55));
        var drag = new Thumb
        {
            Height = NoteItem.HeaderHeight - 2,
            Background = gold,
            Cursor = Cursors.SizeAll,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var close = new Button
        {
            Content = "✕",
            Width = 28,
            Height = NoteItem.HeaderHeight - 2,
            Padding = new Thickness(0),
            BorderThickness = new Thickness(0),
            Background = gold,
            Foreground = Brushes.Black
        };
        var header = new DockPanel { LastChildFill = true };
        DockPanel.SetDock(close, Dock.Right);
        header.Children.Add(close);
        header.Children.Add(drag);

        var stack = new StackPanel();
        stack.Children.Add(header);
        stack.Children.Add(tb);
        var box = new Border
        {
            BorderBrush = gold,
            BorderThickness = new Thickness(1),
            Child = stack,
            Tag = tb
        };
        Canvas.SetLeft(box, item.X);
        Canvas.SetTop(box, item.Y);

        drag.DragDelta += (_, e) =>
        {
            Canvas.SetLeft(box, Math.Clamp(Canvas.GetLeft(box) + e.HorizontalChange, 0, Math.Max(0, Entry.Width - 40)));
            Canvas.SetTop(box, Math.Clamp(Canvas.GetTop(box) + e.VerticalChange, 0, Math.Max(0, Entry.Height - 40)));
        };
        drag.DragCompleted += (_, _) => Commit();
        close.Click += (_, _) => { layer.Children.Remove(box); Commit(); };

        layer.Children.Add(box);
        if (focus) Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() => tb.Focus()));
    }

    // ------------------------------------------------------------------ images

    public void AddImage(ImageItem item, BitmapSource bmp)
    {
        AddImageElement(item, bmp);
        Commit();
    }

    private void AddImageElement(ImageItem item, BitmapSource bmp)
    {
        if (ObjectLayer == null) return;
        var layer = ObjectLayer;
        double aspect = item.W > 0 ? item.H / item.W : 1;

        var holder = new Grid { Width = item.W, Height = item.H, Tag = item };
        var img = new Image { Source = bmp, Stretch = Stretch.Fill };
        RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.HighQuality);

        var gold = new SolidColorBrush(Color.FromArgb(200, 212, 175, 55));
        var drag = new Thumb
        {
            Height = 20,
            Background = gold,
            Cursor = Cursors.SizeAll,
            VerticalAlignment = VerticalAlignment.Top,
            Margin = new Thickness(0, 0, 28, 0)
        };
        var close = new Button
        {
            Content = "✕",
            Width = 28,
            Height = 20,
            Padding = new Thickness(0),
            BorderThickness = new Thickness(0),
            Background = gold,
            Foreground = Brushes.Black,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Top
        };
        var resize = new Thumb
        {
            Width = 22,
            Height = 22,
            Background = new SolidColorBrush(Color.FromArgb(220, 37, 99, 235)),
            Cursor = Cursors.SizeNWSE,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Bottom
        };

        holder.Children.Add(img);
        holder.Children.Add(drag);
        holder.Children.Add(close);
        holder.Children.Add(resize);
        Canvas.SetLeft(holder, item.X);
        Canvas.SetTop(holder, item.Y);

        drag.DragDelta += (_, e) =>
        {
            Canvas.SetLeft(holder, Math.Clamp(Canvas.GetLeft(holder) + e.HorizontalChange, 0, Math.Max(0, Entry.Width - 40)));
            Canvas.SetTop(holder, Math.Clamp(Canvas.GetTop(holder) + e.VerticalChange, 0, Math.Max(0, Entry.Height - 40)));
        };
        drag.DragCompleted += (_, _) => Commit();
        resize.DragDelta += (_, e) =>
        {
            double w = Math.Clamp(holder.Width + e.HorizontalChange, 40, Math.Max(40, Entry.Width * 2));
            holder.Width = w;
            holder.Height = w * aspect;
        };
        resize.DragCompleted += (_, _) => Commit();
        close.Click += (_, _) => { layer.Children.Remove(holder); Commit(); };

        layer.Children.Add(holder);
    }

    // ------------------------------------------------------------------ persistence

    /// <summary>Replaces everything on the page with the given content (no undo bookkeeping).</summary>
    private void ApplyContent(byte[]? inkBytes, string? extrasJson)
    {
        if (Ink == null || NotesLayer == null || ObjectLayer == null) return;
        CancelDrag();
        _suppress = true;
        try
        {
            Ink.Strokes.Clear();
            if (inkBytes != null && inkBytes.Length > 0)
            {
                try
                {
                    using var ms = new MemoryStream(inkBytes);
                    Ink.Strokes.Add(new StrokeCollection(ms));
                }
                catch (Exception ex) { AppPaths.LogError(ex); }
            }

            NotesLayer.Children.Clear();
            ObjectLayer.Children.Clear();
            PageExtras extras;
            try { extras = PageExtras.Parse(extrasJson); }
            catch (Exception ex) { AppPaths.LogError(ex); extras = new PageExtras(); }

            foreach (var img in extras.Images)
            {
                var bytes = _doc.Db.LoadImage(img.Id);
                if (bytes == null) continue;
                try { AddImageElement(img, DocumentSource.Decode(bytes)); }
                catch (Exception ex) { AppPaths.LogError(ex); }
            }
            foreach (var sh in extras.Shapes) AddShapeElement(sh);
            foreach (var n in extras.Notes) AddNoteElement(n, false);
        }
        finally { _suppress = false; }
    }

    public void LoadContent(byte[]? inkBytes, string? extrasJson)
    {
        ApplyContent(inkBytes, extrasJson);
        _undo.Clear();
        _redo.Clear();
        _last = Capture();
        Dirty = false;
    }

    public (byte[]? Ink, string? Extras) Serialize()
    {
        byte[]? ink = null;
        if (Ink != null && Ink.Strokes.Count > 0)
        {
            using var ms = new MemoryStream();
            Ink.Strokes.Save(ms, true);
            ink = ms.ToArray();
        }

        var extras = new PageExtras();
        if (ObjectLayer != null)
            foreach (var child in ObjectLayer.Children)
            {
                if (child is ShapeElement se)
                    extras.Shapes.Add(new ShapeItem
                    {
                        Kind = se.Item.Kind, X = se.Item.X, Y = se.Item.Y, W = se.Item.W, H = se.Item.H,
                        Angle = se.Item.Angle, Stroke = se.Item.Stroke, Fill = se.Item.Fill, Thickness = se.Item.Thickness
                    });
                else if (child is Grid { Tag: ImageItem src } g)
                    extras.Images.Add(new ImageItem
                    {
                        Id = src.Id,
                        X = Canvas.GetLeft(g),
                        Y = Canvas.GetTop(g),
                        W = g.Width,
                        H = g.Height
                    });
            }
        if (NotesLayer != null)
            foreach (var child in NotesLayer.Children)
                if (child is Border { Tag: TextBox tb } box)
                    extras.Notes.Add(new NoteItem
                    {
                        X = Canvas.GetLeft(box),
                        Y = Canvas.GetTop(box),
                        W = tb.ActualWidth > 0 ? tb.ActualWidth : tb.Width,
                        Text = tb.Text
                    });
        return (ink, extras.ToJson());
    }
}
