using System.Windows;
using System.Windows.Threading;

namespace DarsYar;

public partial class App : Application
{
    public static string[] StartupFiles { get; private set; } = Array.Empty<string>();

    private void OnStartup(object sender, StartupEventArgs e)
    {
        StartupFiles = e.Args;
        DispatcherUnhandledException += OnUnhandled;
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            AppPaths.LogError(args.ExceptionObject as Exception);

        var win = new MainWindow();
        MainWindow = win;
        win.Show();
    }

    private void OnUnhandled(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        AppPaths.LogError(e.Exception);
        Dialogs.Error(MainWindow,
            "یک خطای پیش‌بینی‌نشده رخ داد. یادداشت‌های ذخیره‌شده حفظ شده‌اند.\n" +
            "جزئیات در فایل زیر ثبت شد:\n" + AppPaths.LogFile + "\n\n" + e.Exception.Message);
        e.Handled = true;
    }
}
