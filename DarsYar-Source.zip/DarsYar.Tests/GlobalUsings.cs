// Explicit global usings (the project does NOT rely on <ImplicitUsings>).
global using System;
global using System.Collections.Generic;
global using System.IO;
global using System.Linq;
global using System.Threading;
global using System.Threading.Tasks;
