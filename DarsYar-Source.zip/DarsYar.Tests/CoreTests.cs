using System.Text;
using System.Windows.Ink;
using System.Windows.Input;
using DarsYar;
using DarsYar.Services;
using Xunit;

namespace DarsYar.Tests;

public class DatabaseTests : IDisposable
{
    private readonly string _dir = Path.Combine(Path.GetTempPath(), "darsyar-test-" + Guid.NewGuid().ToString("N"));
    private Database NewDb() => new(Path.Combine(_dir, "t.db"));

    public void Dispose()
    {
        Database.ClearPools();
        try { Directory.Delete(_dir, true); } catch { }
    }

    [Fact]
    public void SaveAndLoadPage_RoundTrips()
    {
        var db = NewDb();
        db.OpenDocument("doc1", @"C:\a.pdf", "pdf");
        db.SavePage("doc1", "p3", new byte[] { 1, 2, 3 }, "[{\"X\":1}]");
        var (ink, notes) = db.LoadPage("doc1", "p3");
        Assert.Equal(new byte[] { 1, 2, 3 }, ink);
        Assert.Equal("[{\"X\":1}]", notes);
        Assert.Null(db.LoadPage("doc1", "p4").Ink);   // pages are independent
        Assert.Null(db.LoadPage("doc2", "p3").Ink);   // documents are independent
    }

    [Fact]
    public void EmptyPage_RemovesRow()
    {
        var db = NewDb();
        db.SavePage("d", "p0", new byte[] { 9 }, null);
        Assert.Equal(1, db.CountAnnotatedPages("d"));
        db.SavePage("d", "p0", null, null);
        Assert.Equal(0, db.CountAnnotatedPages("d"));
    }

    [Fact]
    public void Data_SurvivesReopen()
    {
        var db = NewDb();
        db.SavePage("d", "p1", new byte[] { 7, 7 }, null);
        Database.ClearPools();
        var db2 = NewDb();
        Assert.Equal(new byte[] { 7, 7 }, db2.LoadPage("d", "p1").Ink);
    }

    [Fact]
    public void Position_IsRemembered()
    {
        var db = NewDb();
        db.OpenDocument("d", "p", "pdf");
        db.SavePosition("d", 5, 1.5);
        var rec = db.OpenDocument("d", "p2", "pdf");
        Assert.Equal(5, rec.LastPage);
        Assert.Equal(1.5, rec.LastZoom, 3);
        Assert.Equal("p2", rec.Path);  // path updated when file moved
    }

    [Fact]
    public void Backup_ProducesReadableCopy()
    {
        var db = NewDb();
        db.SavePage("d", "p0", new byte[] { 1 }, "x");
        var dest = Path.Combine(_dir, "backup.db");
        db.BackupTo(dest);
        Database.ClearPools();
        var copy = new Database(dest);
        Assert.Equal("x", copy.LoadPage("d", "p0").Notes);
    }

    [Fact]
    public void FileId_IsStable_AndIgnoresPath()
    {
        Directory.CreateDirectory(_dir);
        var a = Path.Combine(_dir, "a.bin");
        var b = Path.Combine(_dir, "b.bin");
        var data = Encoding.UTF8.GetBytes(new string('x', 5000));
        File.WriteAllBytes(a, data);
        File.WriteAllBytes(b, data);
        Assert.Equal(Database.ComputeFileId(a), Database.ComputeFileId(b));
        File.WriteAllBytes(b, Encoding.UTF8.GetBytes(new string('y', 5000)));
        Assert.NotEqual(Database.ComputeFileId(a), Database.ComputeFileId(b));
    }
}

public class PdfWriterTests
{
    [Fact]
    public void Writer_ProducesStructurallyValidPdf()
    {
        // 1x1 white JPEG
        byte[] jpeg = Convert.FromBase64String(
            "/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=");
        using var ms = new MemoryStream();
        var w = new SimplePdfWriter(ms);
        w.AddJpegPage(jpeg, 1, 1, 612, 792);
        w.AddJpegPage(jpeg, 1, 1, 595, 842);
        w.Finish();

        var text = Encoding.Latin1.GetString(ms.ToArray());
        Assert.StartsWith("%PDF-1.4", text);
        Assert.EndsWith("%%EOF\n", text);
        Assert.Contains("/Count 2", text);

        // startxref must point exactly at the "xref" keyword
        int sx = text.LastIndexOf("startxref\n", StringComparison.Ordinal);
        long off = long.Parse(text.Substring(sx + 10, text.IndexOf('\n', sx + 10) - (sx + 10)));
        Assert.Equal("xref", text.Substring((int)off, 4));
    }
}

public class GeometryTests
{
    [Theory]
    [InlineData(0.5)] [InlineData(1.0)] [InlineData(2.0)] [InlineData(3.7)]
    public void PagePoint_IsStable_AcrossZoom(double zoom)
    {
        var (vx, vy) = ViewMath.PageToView(123.4, 567.8, zoom);
        var (px, py) = ViewMath.ViewToPage(vx, vy, zoom);
        Assert.Equal(123.4, px, 6);
        Assert.Equal(567.8, py, 6);
    }

    [Fact]
    public void Fit_ClampsAndHandlesZeroPage()
    {
        Assert.Equal(1, ViewMath.FitWidth(800, 0));
        Assert.InRange(ViewMath.FitWidth(10000, 100), ViewMath.MinZoom, ViewMath.MaxZoom);
        Assert.True(ViewMath.FitPage(1000, 500, 800, 1000) < ViewMath.FitWidth(1000, 800));
    }
}

public class InkSerializationTests
{
    [Fact]
    public void Strokes_RoundTripThroughIsf_KeepPointsAndColor()
    {
        var pts = new StylusPointCollection { new StylusPoint(10, 20), new StylusPoint(30.5, 40.25), new StylusPoint(50, 60) };
        var attrs = new DrawingAttributes { Color = System.Windows.Media.Colors.Red, Width = 4, Height = 4 };
        var sc = new StrokeCollection { new Stroke(pts, attrs) };

        using var ms = new MemoryStream();
        sc.Save(ms, true);
        ms.Position = 0;
        var back = new StrokeCollection(ms);

        Assert.Single(back);
        Assert.Equal(3, back[0].StylusPoints.Count);
        Assert.Equal(30.5, back[0].StylusPoints[1].X, 1);
        Assert.Equal(System.Windows.Media.Colors.Red, back[0].DrawingAttributes.Color);
    }
}


public class LayoutAndPinTests : IDisposable
{
    private readonly string _dir = Path.Combine(Path.GetTempPath(), "darsyar-test2-" + Guid.NewGuid().ToString("N"));
    private Database NewDb() => new(Path.Combine(_dir, "t.db"));
    public void Dispose() { Database.ClearPools(); try { Directory.Delete(_dir, true); } catch { } }

    private static readonly (double W, double H)[] Pages = { (100, 200), (100, 200), (100, 200) };

    [Fact]
    public void Blank_IsInsertedRightAfterItsPage_NewestFirst()
    {
        var db = NewDb();
        var b1 = db.AddBlank("d", "p0", 100, 200);
        var b2 = db.AddBlank("d", "p0", 100, 200);   // newer -> directly after p0
        var list = PageLayout.Build(Pages, db.GetBlanks("d"));
        Assert.Equal(new[] { "p0", "b" + b2.Id, "b" + b1.Id, "p1", "p2" }, list.Select(x => x.Key).ToArray());
    }

    [Fact]
    public void RemovingBlank_ReparentsFollowers_AndDeletesItsData()
    {
        var db = NewDb();
        var a = db.AddBlank("d", "p1", 100, 200);
        var b = db.AddBlank("d", "b" + a.Id, 100, 200);     // blank after a blank
        db.SavePage("d", "b" + a.Id, new byte[] { 1 }, null);
        db.RemoveBlank("d", a.Id);
        var list = PageLayout.Build(Pages, db.GetBlanks("d"));
        Assert.Equal(new[] { "p0", "p1", "b" + b.Id, "p2" }, list.Select(x => x.Key).ToArray());
        Assert.Null(db.LoadPage("d", "b" + a.Id).Ink);
    }

    [Fact]
    public void Pins_AddListRemove()
    {
        var db = NewDb();
        var p = db.AddPin("d", "p2", "پاسخ‌نامه");
        db.AddPin("d", "p0", "سؤال‌ها");
        var pins = db.GetPins("d");
        Assert.Equal(2, pins.Count);
        Assert.Equal("پاسخ‌نامه", pins[0].Label);
        db.RemovePin("d", p.Id);
        Assert.Single(db.GetPins("d"));
    }

    [Fact]
    public void Images_AreStoredOnce_AndReadBack()
    {
        var db = NewDb();
        db.SaveImage("abc", new byte[] { 1, 2, 3 });
        db.SaveImage("abc", new byte[] { 9, 9 });   // same id -> ignored
        Assert.Equal(new byte[] { 1, 2, 3 }, db.LoadImage("abc"));
        Assert.Null(db.LoadImage("nope"));
    }
}

public class ExtrasAndShapeTests
{
    [Fact]
    public void Extras_ReadLegacyNotesList_AndRoundTrip()
    {
        var legacy = PageExtras.Parse("[{\"X\":1,\"Y\":2,\"W\":3,\"Text\":\"hi\"}]");
        Assert.Single(legacy.Notes);
        Assert.Equal("hi", legacy.Notes[0].Text);

        var e = new PageExtras();
        e.Images.Add(new ImageItem { Id = "x", X = 1, Y = 2, W = 3, H = 4 });
        var back = PageExtras.Parse(e.ToJson());
        Assert.Equal("x", back.Images[0].Id);
        Assert.Null(new PageExtras().ToJson());
    }

    [Theory]
    [InlineData(ShapeKind.Line)] [InlineData(ShapeKind.Arrow)] [InlineData(ShapeKind.Rectangle)]
    [InlineData(ShapeKind.Ellipse)] [InlineData(ShapeKind.Triangle)] [InlineData(ShapeKind.RightTriangle)]
    [InlineData(ShapeKind.Diamond)] [InlineData(ShapeKind.Pentagon)] [InlineData(ShapeKind.Hexagon)]
    [InlineData(ShapeKind.Star)] [InlineData(ShapeKind.Cube)] [InlineData(ShapeKind.Cylinder)]
    [InlineData(ShapeKind.Cone)] [InlineData(ShapeKind.Sphere)] [InlineData(ShapeKind.Pyramid)]
    public void EveryShape_ProducesPolylines_InsideTheDragBox(ShapeKind kind)
    {
        var a = new System.Windows.Point(100, 100);
        var b = new System.Windows.Point(300, 260);
        var polys = ShapeBuilder.Build(kind, a, b, 3);
        Assert.NotEmpty(polys);
        foreach (var poly in polys)
        {
            Assert.True(poly.Count >= 2);
            foreach (var p in poly)
            {
                Assert.InRange(p.X, 100 - 40, 300 + 40);   // arrow heads may poke out slightly
                Assert.InRange(p.Y, 100 - 40, 260 + 40);
            }
        }
    }
}


public class ShapeObjectTests
{
    [Fact]
    public void Shapes_RoundTripThroughPageExtras()
    {
        var e = new PageExtras();
        e.Shapes.Add(new ShapeItem { Kind = ShapeKind.Hexagon, X = 10, Y = 20, W = 100, H = 80, Angle = 45, Stroke = "#FFFF0000", Fill = "#FF00FF00", Thickness = 4 });
        var back = PageExtras.Parse(e.ToJson());
        Assert.Single(back.Shapes);
        Assert.Equal(ShapeKind.Hexagon, back.Shapes[0].Kind);
        Assert.Equal(45, back.Shapes[0].Angle);
        Assert.Equal("#FF00FF00", back.Shapes[0].Fill);
    }

    [Fact]
    public void LineLike_ShapesRunHorizontallyThroughTheMiddle()
    {
        var polys = ShapeBuilder.BuildLocal(ShapeKind.Line, 200, 16, 3);
        Assert.Single(polys);
        Assert.Equal(0, polys[0][0].X, 6);
        Assert.Equal(8, polys[0][0].Y, 6);
        Assert.Equal(200, polys[0][1].X, 6);
    }

    [Theory]
    [InlineData(ShapeKind.Rectangle, true)] [InlineData(ShapeKind.Star, true)] [InlineData(ShapeKind.Ellipse, true)]
    [InlineData(ShapeKind.Line, false)] [InlineData(ShapeKind.Arrow, false)] [InlineData(ShapeKind.Cube, false)]
    [InlineData(ShapeKind.Sphere, false)] [InlineData(ShapeKind.Pyramid, false)]
    public void OnlyFlat2DShapesCanBeFilled(ShapeKind kind, bool expected) =>
        Assert.Equal(expected, ShapeBuilder.CanFill(kind));

    [Theory]
    [InlineData(ShapeKind.Rectangle)] [InlineData(ShapeKind.Cylinder)] [InlineData(ShapeKind.Cone)] [InlineData(ShapeKind.Arrow)]
    public void Geometry_IsCreated_AndFrozen(ShapeKind kind)
    {
        var g = ShapeBuilder.CreateGeometry(kind, 120, 90, 3, ShapeBuilder.CanFill(kind));
        Assert.True(g.IsFrozen);
        Assert.False(g.Bounds.IsEmpty);
    }
}
