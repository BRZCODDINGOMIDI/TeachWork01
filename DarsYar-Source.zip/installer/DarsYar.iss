; Inno Setup script for DarsYar (compiled in CI by GitHub Actions on Windows)
#define MyAppName "DarsYar"
#ifndef MyAppVersion
  #define MyAppVersion "1.3.0"
#endif

[Setup]
AppId={{B6F1D7C2-4E8A-4A57-9C55-3D1A2F7B9E10}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=DarsYar
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=..\dist
OutputBaseFilename=DarsYar-Setup
SetupIconFile=DarsYar.ico
UninstallDisplayIcon={app}\DarsYar.exe
UninstallDisplayName={#MyAppName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.19041
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=dialog

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "..\publish\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\DarsYar.exe"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\DarsYar.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\DarsYar.exe"; Description: "Launch DarsYar"; Flags: nowait postinstall skipifsilent

; NOTE: user notes live in %LOCALAPPDATA%\DarsYar and are intentionally NOT listed in
; [UninstallDelete], so uninstalling never removes the user's annotations.
