# ساخت DarsYar-Setup.exe با GitHub (گام‌به‌گام)
1. در github.com حساب رایگان بسازید و وارد شوید.
2. بالا راست «+» ‏> New repository. نام: `DarsYar`، گزینه **Private**، بدون README ‏> Create repository.
3. در صفحه مخزن خالی، لینک «uploading an existing file» را بزنید.
4. ZIP سورس را استخراج کنید. **محتوای داخل پوشه** (پوشه‌های DarsYar، DarsYar.Tests، installer، docs، فایل DarsYar.sln و پوشه مخفی `.github`) را بکشید داخل صفحه. اگر پوشه `.github` (مخفی) آپلود نشد، در ویندوز Explorer ‏> View ‏> Show ‏> Hidden items را روشن کنید.
5. پایین صفحه Commit changes را بزنید.
6. تب **Actions** ‏> اگر پرسید، Enable. workflow با نام «Build DarsYar» خودکار شروع می‌شود (یا Run workflow را بزنید).
7. ۵ تا ۱۰ دقیقه صبر کنید تا علامت سبز ✓ بیاید.
8. روی همان اجرا کلیک کنید، پایین صفحه بخش **Artifacts** ‏> `DarsYar-Windows` را دانلود کنید. داخل ZIP: `DarsYar-Setup.exe`، `DarsYar-Portable.zip`، `DarsYar-Source.zip`.
9. اگر ✗ قرمز شد: روی مرحله قرمز کلیک کنید، متن خطا را کپی و برای من بفرستید.
