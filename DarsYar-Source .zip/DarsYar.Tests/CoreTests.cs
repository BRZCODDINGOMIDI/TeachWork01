using System.Text;
using System.Windows.Ink;
using System.Windows.Input;
using DarsYar;
using DarsYar.Services;
using Xunit;

namespace DarsYar.Tests;

public class DatabaseTests : IDisposable
{
    private readonly string _dir = Path.Combine(Path.GetTempPath(), "darsyar-test-" + Guid.NewGuid().ToString("N"));
    private Database NewDb() => new(Path.Combine(_dir, "t.db"));

    public void Dispose()
    {
        Database.ClearPools();
        try { Directory.Delete(_dir, true); } catch { }
    }

    [Fact]
    public void SaveAndLoadPage_RoundTrips()
    {
        var db = NewDb();
        db.OpenDocument("doc1", @"C:\a.pdf", "pdf");
        db.SavePage("doc1", 3, new byte[] { 1, 2, 3 }, "[{\"X\":1}]");
        var (ink, notes) = db.LoadPage("doc1", 3);
        Assert.Equal(new byte[] { 1, 2, 3 }, ink);
        Assert.Equal("[{\"X\":1}]", notes);
        Assert.Null(db.LoadPage("doc1", 4).Ink);   // pages are independent
        Assert.Null(db.LoadPage("doc2", 3).Ink);   // documents are independent
    }

    [Fact]
    public void EmptyPage_RemovesRow()
    {
        var db = NewDb();
        db.SavePage("d", 0, new byte[] { 9 }, null);
        Assert.Equal(1, db.CountAnnotatedPages("d"));
        db.SavePage("d", 0, null, null);
        Assert.Equal(0, db.CountAnnotatedPages("d"));
    }

    [Fact]
    public void Data_SurvivesReopen()
    {
        var db = NewDb();
        db.SavePage("d", 1, new byte[] { 7, 7 }, null);
        Database.ClearPools();
        var db2 = NewDb();
        Assert.Equal(new byte[] { 7, 7 }, db2.LoadPage("d", 1).Ink);
    }

    [Fact]
    public void Position_IsRemembered()
    {
        var db = NewDb();
        db.OpenDocument("d", "p", "pdf");
        db.SavePosition("d", 5, 1.5);
        var rec = db.OpenDocument("d", "p2", "pdf");
        Assert.Equal(5, rec.LastPage);
        Assert.Equal(1.5, rec.LastZoom, 3);
        Assert.Equal("p2", rec.Path);  // path updated when file moved
    }

    [Fact]
    public void Backup_ProducesReadableCopy()
    {
        var db = NewDb();
        db.SavePage("d", 0, new byte[] { 1 }, "x");
        var dest = Path.Combine(_dir, "backup.db");
        db.BackupTo(dest);
        Database.ClearPools();
        var copy = new Database(dest);
        Assert.Equal("x", copy.LoadPage("d", 0).Notes);
    }

    [Fact]
    public void FileId_IsStable_AndIgnoresPath()
    {
        Directory.CreateDirectory(_dir);
        var a = Path.Combine(_dir, "a.bin");
        var b = Path.Combine(_dir, "b.bin");
        var data = Encoding.UTF8.GetBytes(new string('x', 5000));
        File.WriteAllBytes(a, data);
        File.WriteAllBytes(b, data);
        Assert.Equal(Database.ComputeFileId(a), Database.ComputeFileId(b));
        File.WriteAllBytes(b, Encoding.UTF8.GetBytes(new string('y', 5000)));
        Assert.NotEqual(Database.ComputeFileId(a), Database.ComputeFileId(b));
    }
}

public class PdfWriterTests
{
    [Fact]
    public void Writer_ProducesStructurallyValidPdf()
    {
        // 1x1 white JPEG
        byte[] jpeg = Convert.FromBase64String(
            "/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=");
        using var ms = new MemoryStream();
        var w = new SimplePdfWriter(ms);
        w.AddJpegPage(jpeg, 1, 1, 612, 792);
        w.AddJpegPage(jpeg, 1, 1, 595, 842);
        w.Finish();

        var text = Encoding.Latin1.GetString(ms.ToArray());
        Assert.StartsWith("%PDF-1.4", text);
        Assert.EndsWith("%%EOF\n", text);
        Assert.Contains("/Count 2", text);

        // startxref must point exactly at the "xref" keyword
        int sx = text.LastIndexOf("startxref\n", StringComparison.Ordinal);
        long off = long.Parse(text.Substring(sx + 10, text.IndexOf('\n', sx + 10) - (sx + 10)));
        Assert.Equal("xref", text.Substring((int)off, 4));
    }
}

public class GeometryTests
{
    [Theory]
    [InlineData(0.5)] [InlineData(1.0)] [InlineData(2.0)] [InlineData(3.7)]
    public void PagePoint_IsStable_AcrossZoom(double zoom)
    {
        var (vx, vy) = ViewMath.PageToView(123.4, 567.8, zoom);
        var (px, py) = ViewMath.ViewToPage(vx, vy, zoom);
        Assert.Equal(123.4, px, 6);
        Assert.Equal(567.8, py, 6);
    }

    [Fact]
    public void Fit_ClampsAndHandlesZeroPage()
    {
        Assert.Equal(1, ViewMath.FitWidth(800, 0));
        Assert.InRange(ViewMath.FitWidth(10000, 100), ViewMath.MinZoom, ViewMath.MaxZoom);
        Assert.True(ViewMath.FitPage(1000, 500, 800, 1000) < ViewMath.FitWidth(1000, 800));
    }
}

public class InkSerializationTests
{
    [Fact]
    public void Strokes_RoundTripThroughIsf_KeepPointsAndColor()
    {
        var pts = new StylusPointCollection { new StylusPoint(10, 20), new StylusPoint(30.5, 40.25), new StylusPoint(50, 60) };
        var attrs = new DrawingAttributes { Color = System.Windows.Media.Colors.Red, Width = 4, Height = 4 };
        var sc = new StrokeCollection { new Stroke(pts, attrs) };

        using var ms = new MemoryStream();
        sc.Save(ms, true);
        ms.Position = 0;
        var back = new StrokeCollection(ms);

        Assert.Single(back);
        Assert.Equal(3, back[0].StylusPoints.Count);
        Assert.Equal(30.5, back[0].StylusPoints[1].X, 1);
        Assert.Equal(System.Windows.Media.Colors.Red, back[0].DrawingAttributes.Color);
    }
}
