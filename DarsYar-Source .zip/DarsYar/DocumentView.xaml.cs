using System.Collections.ObjectModel;
using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using DarsYar.Services;

namespace DarsYar;

public partial class DocumentView : UserControl
{
    private enum FitMode { None, Width, Page }

    private sealed class UndoEntry
    {
        public StrokeCollection Added { get; set; } = new();
        public StrokeCollection Removed { get; set; } = new();
    }

    private readonly Database _db;
    private DocumentSource _source = null!;
    private string _docId = "";

    private int _loadedPage = -1;          // page whose annotations are currently on screen
    private Size _pageSize;
    private double _zoom = 1;
    private FitMode _fit = FitMode.Width;

    private int _navToken;
    private int _renderToken;
    private double _renderedScale;

    private bool _dirty;
    private bool _suppress;
    private bool _penActive;
    private DateTime _lastSave = DateTime.UtcNow;
    private Task _writeChain = Task.CompletedTask;
    private readonly DispatcherTimer _saveTimer;
    private readonly DispatcherTimer _rerenderTimer;

    private readonly Stack<UndoEntry> _undo = new();
    private readonly Stack<UndoEntry> _redo = new();

    private bool _penInRange, _penInverted, _mouseActive;
    private InkCanvasEditingMode _desiredMode = InkCanvasEditingMode.Ink;

    private readonly ObservableCollection<ThumbItem> _thumbs = new();
    private CancellationTokenSource _thumbCts = new();
    private bool _updatingThumbSelection;

    public string FilePath { get; private set; } = "";
    public string FileName => Path.GetFileName(FilePath);
    public string DocId => _docId;
    public DocumentSource Source => _source;
    public int PageIndex => Math.Max(0, _loadedPage);
    public int PageCount => _source.PageCount;

    private DocumentView(Database db)
    {
        _db = db;
        InitializeComponent();
        Thumbs.ItemsSource = _thumbs;

        Ink.Strokes.StrokesChanged += OnStrokesChanged;
        Ink.StrokeCollected += OnStrokeCollected;
        Ink.SelectionMoved += (_, _) => MarkDirty();
        Ink.SelectionResized += (_, _) => MarkDirty();

        // Input arbitration: pen/mouse draw, finger pans (unless "touch ink" is enabled).
        Ink.PreviewMouseMove += (_, e) =>
        {
            if (e.StylusDevice == null && !_mouseActive)
            {
                _mouseActive = true; _penInRange = false;
                UpdateInputMode();
            }
        };
        Ink.StylusInRange += (_, e) =>
        {
            if (e.StylusDevice?.TabletDevice?.Type == TabletDeviceType.Stylus)
            {
                _penInRange = true; _mouseActive = false;
                _penInverted = e.StylusDevice.Inverted;
                UpdateInputMode();
            }
        };
        Ink.StylusOutOfRange += (_, _) => { _penInRange = false; _penInverted = false; UpdateInputMode(); };
        Ink.PreviewTouchDown += (_, _) => { _mouseActive = false; UpdateInputMode(); };

        Ink.PreviewStylusDown += (_, _) => _penActive = true;
        Ink.PreviewStylusUp += (_, _) => PenReleased();
        Ink.PreviewMouseLeftButtonDown += (_, e) => { if (e.StylusDevice == null) _penActive = true; };
        Ink.PreviewMouseLeftButtonUp += (_, e) => { if (e.StylusDevice == null) PenReleased(); };

        NotesLayer.MouseLeftButtonDown += NotesLayer_MouseLeftButtonDown;
        Scroller.PreviewMouseWheel += (_, e) =>
        {
            if (Keyboard.Modifiers == ModifierKeys.Control)
            {
                e.Handled = true;
                if (e.Delta > 0) ZoomIn(); else ZoomOut();
            }
        };

        _saveTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };
        _saveTimer.Tick += (_, _) =>
        {
            _saveTimer.Stop();
            if (_penActive) { _saveTimer.Start(); return; } // never save in the middle of a stroke
            SaveCurrentPage(false);
        };

        _rerenderTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(350) };
        _rerenderTimer.Tick += (_, _) => { _rerenderTimer.Stop(); _ = RerenderIfNeededAsync(); };

        ToolState.Instance.Changed += ApplyTool;
        ApplyTool();
    }

    // ------------------------------------------------------------------ creation

    public static async Task<DocumentView> CreateAsync(Database db, string path)
    {
        var view = new DocumentView(db) { FilePath = path };
        view._source = await DocumentSource.OpenAsync(path);
        if (view._source.PageCount < 1) throw new InvalidDataException("سند هیچ صفحه‌ای ندارد.");
        view._docId = await Task.Run(() => Database.ComputeFileId(path));
        var rec = db.OpenDocument(view._docId, path, view._source.Type);

        view.FileNameText.Text = view.FileName;
        for (int i = 0; i < view._source.PageCount; i++)
            view._thumbs.Add(new ThumbItem { Index = i, Label = (i + 1).ToString(CultureInfo.InvariantCulture) });

        if (rec.LastZoom > 0) { view._fit = FitMode.None; view._zoom = ViewMath.Clamp(rec.LastZoom); }
        await view.GoToPageAsync(Math.Clamp(rec.LastPage, 0, view._source.PageCount - 1));
        _ = view.LoadThumbnailsAsync(view._thumbCts.Token);
        return view;
    }

    // ------------------------------------------------------------------ navigation

    private async void Navigate(int index)
    {
        try { await GoToPageAsync(index); }
        catch (Exception ex) { AppPaths.LogError(ex); SetStatus("خطا در نمایش صفحه: " + ex.Message); }
    }

    public async Task GoToPageAsync(int index)
    {
        if (index < 0 || index >= _source.PageCount) return;
        int token = ++_navToken;

        SaveCurrentPage(false);                       // keep notes of the page we are leaving
        var size = await _source.GetPageSizeAsync(index);
        if (token != _navToken) return;
        await _writeChain;                            // make sure the page we load is up to date
        if (token != _navToken) return;
        var (inkBytes, notesJson) = _db.LoadPage(_docId, index);

        _suppress = true;
        try
        {
            _loadedPage = index;
            _pageSize = size;
            PageHost.Width = size.Width;
            PageHost.Height = size.Height;
            LoadInk(inkBytes);
            LoadNotes(notesJson);
            _undo.Clear(); _redo.Clear();
            _dirty = false;
        }
        finally { _suppress = false; }

        PageImage.Source = null;
        Scroller.ScrollToTop();
        if (_fit != FitMode.None) ApplyFit(); else SetZoom(_zoom, true);
        UpdateBar();
        try { _db.SavePosition(_docId, index, _fit == FitMode.None ? _zoom : 0); } catch { }

        await RenderPageImageAsync();
    }

    public void NextPage() => Navigate(PageIndex + 1);
    public void PrevPage() => Navigate(PageIndex - 1);

    private void Prev_Click(object s, RoutedEventArgs e) => PrevPage();
    private void Next_Click(object s, RoutedEventArgs e) => NextPage();

    private void PageBox_KeyDown(object s, KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        if (int.TryParse(ToLatinDigits(PageBox.Text), NumberStyles.Integer, CultureInfo.InvariantCulture, out int n)
            && n >= 1 && n <= PageCount)
            Navigate(n - 1);
        else
        {
            UpdateBar();
            SetStatus($"شماره صفحه باید بین ۱ و {PageCount} باشد.");
        }
        Keyboard.ClearFocus();
        Focus();
    }

    private void PageBox_LostFocus(object s, RoutedEventArgs e) => UpdateBar();

    private static string ToLatinDigits(string s)
    {
        var sb = new System.Text.StringBuilder(s.Length);
        foreach (char c in s)
        {
            if (c >= '۰' && c <= '۹') sb.Append((char)('0' + (c - '۰')));
            else if (c >= '٠' && c <= '٩') sb.Append((char)('0' + (c - '٠')));
            else sb.Append(c);
        }
        return sb.ToString().Trim();
    }

    // ------------------------------------------------------------------ rendering & zoom

    private async Task RenderPageImageAsync()
    {
        int token = ++_renderToken;
        double dpi = VisualTreeHelper.GetDpi(this).DpiScaleX;
        double scale = Math.Clamp(_zoom * dpi, 1.5, 4.0);
        int page = PageIndex;
        try
        {
            var bmp = await _source.RenderAsync(page, scale);
            if (token != _renderToken || page != PageIndex) return;
            PageImage.Source = bmp;
            _renderedScale = scale;
        }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            SetStatus("نمایش صفحه ناموفق بود: " + ex.Message);
        }
    }

    private async Task RerenderIfNeededAsync()
    {
        if (_source.Type == "image") return;
        double dpi = VisualTreeHelper.GetDpi(this).DpiScaleX;
        double want = Math.Clamp(_zoom * dpi, 1.5, 4.0);
        if (_renderedScale <= 0 || Math.Abs(want - _renderedScale) / _renderedScale > 0.25)
            await RenderPageImageAsync();
    }

    private void SetZoom(double z, bool fromFit)
    {
        _zoom = ViewMath.Clamp(z);
        ZoomTransform.ScaleX = _zoom;
        ZoomTransform.ScaleY = _zoom;
        if (!fromFit) _fit = FitMode.None;
        ZoomText.Text = (_zoom * 100).ToString("0", CultureInfo.InvariantCulture) + "%";
        _rerenderTimer.Stop();
        _rerenderTimer.Start();
    }

    public void ZoomIn() => SetZoom(_zoom * 1.25, false);
    public void ZoomOut() => SetZoom(_zoom / 1.25, false);

    private void ApplyFit()
    {
        if (_fit == FitMode.None || _pageSize.Width <= 0) return;
        double vw = Scroller.ActualWidth - SystemParameters.VerticalScrollBarWidth;
        double vh = Scroller.ActualHeight - SystemParameters.HorizontalScrollBarHeight;
        if (vw <= 60 || vh <= 60) return;
        double z = _fit == FitMode.Width
            ? ViewMath.FitWidth(vw, _pageSize.Width)
            : ViewMath.FitPage(vw, vh, _pageSize.Width, _pageSize.Height);
        SetZoom(z, true);
    }

    private void Scroller_SizeChanged(object s, SizeChangedEventArgs e) => ApplyFit();
    private void ZoomIn_Click(object s, RoutedEventArgs e) => ZoomIn();
    private void ZoomOut_Click(object s, RoutedEventArgs e) => ZoomOut();
    private void FitWidth_Click(object s, RoutedEventArgs e) { _fit = FitMode.Width; ApplyFit(); }
    private void FitPage_Click(object s, RoutedEventArgs e) { _fit = FitMode.Page; ApplyFit(); }

    private void UpdateBar()
    {
        PageBox.Text = (PageIndex + 1).ToString(CultureInfo.InvariantCulture);
        PageCountText.Text = "از " + PageCount.ToString(CultureInfo.InvariantCulture);
        ZoomText.Text = (_zoom * 100).ToString("0", CultureInfo.InvariantCulture) + "%";
        _updatingThumbSelection = true;
        Thumbs.SelectedIndex = PageIndex;
        if (Thumbs.SelectedItem != null) Thumbs.ScrollIntoView(Thumbs.SelectedItem);
        _updatingThumbSelection = false;
    }

    private void Thumbs_SelectionChanged(object s, SelectionChangedEventArgs e)
    {
        if (_updatingThumbSelection || Thumbs.SelectedIndex < 0) return;
        if (Thumbs.SelectedIndex != PageIndex) Navigate(Thumbs.SelectedIndex);
    }

    private async Task LoadThumbnailsAsync(CancellationToken ct)
    {
        try
        {
            double dpi = VisualTreeHelper.GetDpi(this).DpiScaleX;
            for (int i = 0; i < _source.PageCount && !ct.IsCancellationRequested; i++)
            {
                var size = await _source.GetPageSizeAsync(i);
                double scale = Math.Min(1.0, 130.0 * dpi / Math.Max(1, size.Width));
                var bmp = await _source.RenderAsync(i, scale);
                if (ct.IsCancellationRequested) return;
                _thumbs[i].Image = bmp;
                await Task.Delay(5, ct);
            }
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) { AppPaths.LogError(ex); }
    }

    // ------------------------------------------------------------------ tools & input

    private void ApplyTool()
    {
        var t = ToolState.Instance;
        var da = new DrawingAttributes
        {
            FitToCurve = true,
            IgnorePressure = false,
            StylusTip = StylusTip.Ellipse,
            Color = t.PenColor,
            Width = t.Thickness,
            Height = t.Thickness,
            IsHighlighter = false
        };

        switch (t.Tool)
        {
            case Tool.Pen:
                _desiredMode = InkCanvasEditingMode.Ink;
                break;
            case Tool.Highlighter:
                _desiredMode = InkCanvasEditingMode.Ink;
                da.IsHighlighter = true;
                da.IgnorePressure = true;
                da.Color = t.HighlighterColor;
                da.StylusTip = StylusTip.Rectangle;
                da.Width = t.Thickness * 4;
                da.Height = t.Thickness * 4;
                break;
            case Tool.Line:
            case Tool.Arrow:
            case Tool.Rectangle:
                _desiredMode = InkCanvasEditingMode.Ink;
                da.IgnorePressure = true;
                da.FitToCurve = false;
                break;
            case Tool.Eraser:
                _desiredMode = InkCanvasEditingMode.EraseByStroke;
                break;
            case Tool.Select:
                _desiredMode = InkCanvasEditingMode.Select;
                break;
            case Tool.Note:
                _desiredMode = InkCanvasEditingMode.None;
                break;
        }

        Ink.DefaultDrawingAttributes = da;
        NotesLayer.IsHitTestVisible = t.Tool == Tool.Note;
        UpdateInputMode();
    }

    private void UpdateInputMode()
    {
        var mode = _desiredMode;
        bool allowed = _penInRange || _mouseActive || ToolState.Instance.AllowTouchInk;
        if (!allowed) mode = InkCanvasEditingMode.None;
        else if (_penInRange && _penInverted && mode == InkCanvasEditingMode.Ink) mode = InkCanvasEditingMode.EraseByStroke; // pen tail = eraser
        if (Ink.EditingMode != mode) Ink.EditingMode = mode;
    }

    private void PenReleased()
    {
        _penActive = false;
        if (_dirty && (DateTime.UtcNow - _lastSave).TotalSeconds > 10)
            Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => SaveCurrentPage(false)));
    }

    // ------------------------------------------------------------------ undo / redo

    private void OnStrokesChanged(object? sender, StrokeCollectionChangedEventArgs e)
    {
        if (_suppress) return;
        _undo.Push(new UndoEntry
        {
            Added = new StrokeCollection(e.Added),
            Removed = new StrokeCollection(e.Removed)
        });
        _redo.Clear();
        MarkDirty();
    }

    public void Undo()
    {
        if (_undo.Count == 0) return;
        var e = _undo.Pop();
        _suppress = true;
        try
        {
            if (e.Added.Count > 0) Ink.Strokes.Remove(e.Added);
            if (e.Removed.Count > 0) Ink.Strokes.Add(e.Removed);
        }
        finally { _suppress = false; }
        _redo.Push(e);
        MarkDirty();
    }

    public void Redo()
    {
        if (_redo.Count == 0) return;
        var e = _redo.Pop();
        _suppress = true;
        try
        {
            if (e.Removed.Count > 0) Ink.Strokes.Remove(e.Removed);
            if (e.Added.Count > 0) Ink.Strokes.Add(e.Added);
        }
        finally { _suppress = false; }
        _undo.Push(e);
        MarkDirty();
    }

    public void DeleteSelection()
    {
        var sel = Ink.GetSelectedStrokes();
        if (sel.Count > 0)
        {
            Ink.Strokes.Remove(sel);
            Ink.Select(new StrokeCollection());
        }
    }

    // ------------------------------------------------------------------ shapes (line / arrow / rectangle)

    private void OnStrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
    {
        var tool = ToolState.Instance.Tool;
        if (tool != Tool.Line && tool != Tool.Arrow && tool != Tool.Rectangle) return;
        var pts = e.Stroke.StylusPoints;
        if (pts.Count < 2) return;

        var a = new Point(pts[0].X, pts[0].Y);
        var b = new Point(pts[pts.Count - 1].X, pts[pts.Count - 1].Y);
        if ((b - a).Length < 6) return;

        var path = BuildShape(tool, a, b);
        var spc = new StylusPointCollection();
        foreach (var p in Densify(path, 3)) spc.Add(new StylusPoint(p.X, p.Y));

        var attrs = e.Stroke.DrawingAttributes.Clone();
        attrs.FitToCurve = false;
        attrs.IgnorePressure = true;
        var shape = new Stroke(spc, attrs);

        _suppress = true;
        try
        {
            Ink.Strokes.Remove(e.Stroke);
            Ink.Strokes.Add(shape);
        }
        finally { _suppress = false; }

        // keep a single undo step for the whole shape
        if (_undo.Count > 0 && _undo.Peek().Added.Contains(e.Stroke))
            _undo.Peek().Added = new StrokeCollection { shape };
        MarkDirty();
    }

    private static List<Point> BuildShape(Tool tool, Point a, Point b)
    {
        switch (tool)
        {
            case Tool.Rectangle:
                return new List<Point> { a, new Point(b.X, a.Y), b, new Point(a.X, b.Y), a };
            case Tool.Arrow:
            {
                var d = b - a;
                d.Normalize();
                double len = Math.Max(16, ToolState.Instance.Thickness * 5);
                var back = -d * len;
                var w1 = b + Rotate(back, 25);
                var w2 = b + Rotate(back, -25);
                return new List<Point> { a, b, w1, b, w2 };
            }
            default:
                return new List<Point> { a, b };
        }
    }

    private static Vector Rotate(Vector v, double degrees)
    {
        double r = degrees * Math.PI / 180.0;
        double c = Math.Cos(r), s = Math.Sin(r);
        return new Vector(v.X * c - v.Y * s, v.X * s + v.Y * c);
    }

    private static IEnumerable<Point> Densify(List<Point> pts, double step)
    {
        for (int i = 0; i < pts.Count - 1; i++)
        {
            var p0 = pts[i];
            var p1 = pts[i + 1];
            double dist = (p1 - p0).Length;
            int n = Math.Max(1, (int)Math.Ceiling(dist / step));
            for (int k = 0; k < n; k++)
                yield return new Point(p0.X + (p1.X - p0.X) * k / n, p0.Y + (p1.Y - p0.Y) * k / n);
        }
        yield return pts[pts.Count - 1];
    }

    // ------------------------------------------------------------------ text notes

    private void NotesLayer_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (ToolState.Instance.Tool != Tool.Note || !ReferenceEquals(e.OriginalSource, NotesLayer)) return;
        var p = e.GetPosition(NotesLayer);
        AddNoteControl(new NoteItem
        {
            X = Math.Clamp(p.X, 0, Math.Max(0, _pageSize.Width - 160)),
            Y = Math.Clamp(p.Y, 0, Math.Max(0, _pageSize.Height - 80)),
            W = 0,
            Text = ""
        }, true);
        MarkDirty();
        e.Handled = true;
    }

    private void AddNoteControl(NoteItem item, bool focus)
    {
        var tb = new TextBox
        {
            Text = item.Text,
            AcceptsReturn = true,
            TextWrapping = TextWrapping.Wrap,
            MinWidth = 140,
            MaxWidth = 600,
            BorderThickness = new Thickness(0),
            Background = new SolidColorBrush(Color.FromRgb(255, 249, 196)),
            Foreground = Brushes.Black,
            FontSize = 16,
            Padding = new Thickness(6),
            FlowDirection = FlowDirection.RightToLeft
        };
        if (item.W > 0) tb.Width = item.W;
        tb.TextChanged += (_, _) => { if (!_suppress) MarkDirty(); };

        var drag = new Thumb
        {
            Height = NoteItem.HeaderHeight - 2,
            Background = new SolidColorBrush(Color.FromRgb(212, 175, 55)),
            Cursor = Cursors.SizeAll,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var close = new Button
        {
            Content = "✕",
            Width = 28,
            Height = NoteItem.HeaderHeight - 2,
            Padding = new Thickness(0),
            BorderThickness = new Thickness(0),
            Background = new SolidColorBrush(Color.FromRgb(212, 175, 55)),
            Foreground = Brushes.Black
        };
        var header = new DockPanel { LastChildFill = true };
        DockPanel.SetDock(close, Dock.Right);
        header.Children.Add(close);
        header.Children.Add(drag);

        var stack = new StackPanel();
        stack.Children.Add(header);
        stack.Children.Add(tb);
        var box = new Border
        {
            BorderBrush = new SolidColorBrush(Color.FromRgb(212, 175, 55)),
            BorderThickness = new Thickness(1),
            Child = stack,
            Tag = tb
        };
        Canvas.SetLeft(box, item.X);
        Canvas.SetTop(box, item.Y);

        drag.DragDelta += (_, e) =>
        {
            double nx = Math.Clamp(Canvas.GetLeft(box) + e.HorizontalChange, 0, Math.Max(0, _pageSize.Width - 40));
            double ny = Math.Clamp(Canvas.GetTop(box) + e.VerticalChange, 0, Math.Max(0, _pageSize.Height - 40));
            Canvas.SetLeft(box, nx);
            Canvas.SetTop(box, ny);
        };
        drag.DragCompleted += (_, _) => MarkDirty();
        close.Click += (_, _) => { NotesLayer.Children.Remove(box); MarkDirty(); };

        NotesLayer.Children.Add(box);
        if (focus) Dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() => tb.Focus()));
    }

    private void LoadNotes(string? json)
    {
        NotesLayer.Children.Clear();
        if (string.IsNullOrWhiteSpace(json)) return;
        try
        {
            var list = JsonSerializer.Deserialize<List<NoteItem>>(json) ?? new();
            foreach (var n in list) AddNoteControl(n, false);
        }
        catch (Exception ex) { AppPaths.LogError(ex); SetStatus("بازیابی یادداشت‌های متنی این صفحه ناموفق بود."); }
    }

    private string? SerializeNotes()
    {
        var list = new List<NoteItem>();
        foreach (var child in NotesLayer.Children)
        {
            if (child is Border { Tag: TextBox tb } box)
                list.Add(new NoteItem
                {
                    X = Canvas.GetLeft(box),
                    Y = Canvas.GetTop(box),
                    W = tb.ActualWidth > 0 ? tb.ActualWidth : tb.Width,
                    Text = tb.Text
                });
        }
        return list.Count == 0 ? null : JsonSerializer.Serialize(list);
    }

    // ------------------------------------------------------------------ ink persistence

    private void LoadInk(byte[]? bytes)
    {
        Ink.Strokes.Clear();
        if (bytes == null || bytes.Length == 0) return;
        try
        {
            using var ms = new MemoryStream(bytes);
            Ink.Strokes.Add(new StrokeCollection(ms));
        }
        catch (Exception ex) { AppPaths.LogError(ex); SetStatus("بازیابی نوشته‌های این صفحه ناموفق بود."); }
    }

    private byte[]? SerializeInk()
    {
        if (Ink.Strokes.Count == 0) return null;
        using var ms = new MemoryStream();
        Ink.Strokes.Save(ms, true);
        return ms.ToArray();
    }

    // ------------------------------------------------------------------ saving

    private void MarkDirty()
    {
        if (_suppress && _loadedPage < 0) return;
        _dirty = true;
        SetStatus("تغییرات ذخیره‌نشده…");
        _saveTimer.Stop();
        _saveTimer.Start();
    }

    /// <summary>Saves the current page. sync=true is used on close/export so nothing is lost.</summary>
    private void SaveCurrentPage(bool sync)
    {
        if (!_dirty || _loadedPage < 0) return;
        _dirty = false;
        _saveTimer.Stop();

        byte[]? ink = SerializeInk();
        string? notes = SerializeNotes();
        string id = _docId;
        int page = _loadedPage;
        _lastSave = DateTime.UtcNow;

        if (sync)
        {
            try { _writeChain.Wait(); } catch { }
            try
            {
                _db.SavePage(id, page, ink, notes);
                SetStatus("ذخیره شد ✓ " + DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture));
            }
            catch (Exception ex)
            {
                _dirty = true;
                AppPaths.LogError(ex);
                SetStatus("خطا در ذخیره‌سازی: " + ex.Message);
            }
            return;
        }

        SetStatus("در حال ذخیره…");
        _writeChain = _writeChain.ContinueWith(_ =>
        {
            try
            {
                _db.SavePage(id, page, ink, notes);
                Dispatcher.BeginInvoke(new Action(() =>
                    SetStatus("ذخیره شد ✓ " + DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture))));
            }
            catch (Exception ex)
            {
                AppPaths.LogError(ex);
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    _dirty = true;
                    SetStatus("خطا در ذخیره‌سازی: " + ex.Message);
                }));
            }
        }, TaskScheduler.Default);
    }

    /// <summary>Manual save / flush (Ctrl+S, before export, on close).</summary>
    public void FlushSave()
    {
        SaveCurrentPage(true);
        try { _writeChain.Wait(); } catch { }
        try { _db.SavePosition(_docId, PageIndex, _fit == FitMode.None ? _zoom : 0); } catch { }
    }

    public void CloseDocument()
    {
        FlushSave();
        _thumbCts.Cancel();
        _saveTimer.Stop();
        _rerenderTimer.Stop();
        ToolState.Instance.Changed -= ApplyTool;
        _source.Dispose();
    }

    private void SetStatus(string text) => StatusText.Text = text;
}
