using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DarsYar.Services;
using Microsoft.Win32;

namespace DarsYar;

public partial class MainWindow : Window
{
    private readonly Database? _db;
    private bool _dark;

    private static readonly string[] Palette =
    {
        "#000000", "#DC2626", "#2563EB", "#16A34A", "#F59E0B", "#9333EA", "#FFFF00", "#F472B6"
    };

    public MainWindow()
    {
        InitializeComponent();

        try { _db = new Database(AppPaths.DbFile); }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            Dialogs.Error(this, "پایگاه داده محلی باز نشد. برنامه بدون ذخیره‌سازی قابل استفاده نیست.\n" + ex.Message);
            Loaded += (_, _) => Close();
            return;
        }

        foreach (var hex in Palette)
        {
            var color = (Color)ColorConverter.ConvertFromString(hex);
            var b = new Button { Style = (Style)FindResource("ColorDot"), Background = new SolidColorBrush(color) };
            b.Click += (_, _) => ToolState.Instance.SetColor(color);
            ColorPanel.Children.Add(b);
        }

        UpdateEmptyHint();
        Loaded += async (_, _) =>
        {
            foreach (var f in App.StartupFiles)
                if (File.Exists(f) && DocumentSource.IsSupported(f)) await OpenDocumentAsync(f);
        };
    }

    private DocumentView? CurrentView => (Tabs.SelectedItem as TabItem)?.Content as DocumentView;

    private void UpdateEmptyHint() =>
        EmptyHint.Visibility = Tabs.Items.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

    // ------------------------------------------------------------ open

    private async Task OpenDocumentAsync(string path)
    {
        if (_db == null) return;
        if (!File.Exists(path))
        {
            Dialogs.Error(this, "فایل اصلی پیدا نشد (جابه‌جا یا حذف شده است):\n" + path +
                "\n\nیادداشت‌های قبلی حذف نشده‌اند. اگر فایل را به‌جای دیگری منتقل کرده‌اید، " +
                "از «باز کردن» همان فایل را انتخاب کنید؛ یادداشت‌ها دوباره به آن متصل می‌شوند.");
            return;
        }

        foreach (TabItem t in Tabs.Items)
            if (t.Content is DocumentView v && string.Equals(v.FilePath, path, StringComparison.OrdinalIgnoreCase))
            { Tabs.SelectedItem = t; return; }

        Mouse.OverrideCursor = Cursors.Wait;
        try
        {
            var view = await DocumentView.CreateAsync(_db, path);
            var tab = new TabItem { Content = view, Header = MakeHeader(view) };
            Tabs.Items.Add(tab);
            Tabs.SelectedItem = tab;
            UpdateEmptyHint();
        }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            Dialogs.Error(this, "باز کردن فایل ممکن نشد. ممکن است فایل خراب، رمزدار یا ناسازگار باشد.\n\n" +
                path + "\n" + ex.Message);
        }
        finally { Mouse.OverrideCursor = null; }
    }

    private UIElement MakeHeader(DocumentView view)
    {
        var panel = new StackPanel { Orientation = Orientation.Horizontal };
        panel.Children.Add(new TextBlock
        {
            Text = view.FileName, MaxWidth = 180, TextTrimming = TextTrimming.CharacterEllipsis,
            VerticalAlignment = VerticalAlignment.Center, ToolTip = view.FilePath
        });
        var close = new Button
        {
            Content = "✕", Margin = new Thickness(8, 0, 0, 0), Padding = new Thickness(6, 2, 6, 2),
            BorderThickness = new Thickness(0), Background = Brushes.Transparent, MinWidth = 32, MinHeight = 32
        };
        close.Click += (_, _) => CloseTab(view);
        panel.Children.Add(close);
        return panel;
    }

    private void CloseTab(DocumentView view)
    {
        foreach (TabItem t in Tabs.Items)
        {
            if (!ReferenceEquals(t.Content, view)) continue;
            view.CloseDocument();
            Tabs.Items.Remove(t);
            break;
        }
        UpdateEmptyHint();
    }

    private async void Open_Click(object s, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Title = "باز کردن سند",
            Filter = "PDF و تصاویر|*.pdf;*.jpg;*.jpeg;*.png;*.bmp|PDF|*.pdf|تصاویر|*.jpg;*.jpeg;*.png;*.bmp",
            Multiselect = true
        };
        if (dlg.ShowDialog(this) != true) return;
        foreach (var f in dlg.FileNames) await OpenDocumentAsync(f);
    }

    private void Recent_Click(object s, RoutedEventArgs e)
    {
        if (_db == null) return;
        RecentMenu.Items.Clear();
        var items = _db.Recent(15);
        if (items.Count == 0)
        {
            RecentMenu.Items.Add(new MenuItem { Header = "(موردی نیست)", IsEnabled = false });
        }
        foreach (var rec in items)
        {
            bool exists = File.Exists(rec.Path);
            var mi = new MenuItem
            {
                Header = System.IO.Path.GetFileName(rec.Path) + (exists ? "" : "  (فایل پیدا نشد)"),
                ToolTip = rec.Path
            };
            var path = rec.Path;
            mi.Click += async (_, _) => await OpenDocumentAsync(path);
            RecentMenu.Items.Add(mi);
        }
        RecentMenu.PlacementTarget = RecentButton;
        RecentMenu.IsOpen = true;
    }

    private async void Window_Drop(object s, DragEventArgs e)
    {
        if (e.Data.GetData(DataFormats.FileDrop) is not string[] files) return;
        foreach (var f in files)
            if (DocumentSource.IsSupported(f)) await OpenDocumentAsync(f);
    }

    // ------------------------------------------------------------ save / export / backup

    private void Save_Click(object s, RoutedEventArgs e)
    {
        CurrentView?.FlushSave();
        StatusText.Text = "ذخیره شد ✓";
    }

    private async void Export_Click(object s, RoutedEventArgs e)
    {
        var view = CurrentView;
        if (view == null || _db == null) { Dialogs.Info(this, "ابتدا یک سند باز کنید."); return; }

        var dlg = new SaveFileDialog
        {
            Title = "ذخیره PDF همراه با یادداشت‌ها",
            Filter = "PDF|*.pdf",
            FileName = System.IO.Path.GetFileNameWithoutExtension(view.FileName) + "-annotated.pdf",
            OverwritePrompt = true
        };
        if (dlg.ShowDialog(this) != true) return;

        if (string.Equals(System.IO.Path.GetFullPath(dlg.FileName), System.IO.Path.GetFullPath(view.FilePath),
                StringComparison.OrdinalIgnoreCase))
        {
            Dialogs.Error(this, "مسیر خروجی نمی‌تواند همان فایل اصلی باشد. فایل اصلی هرگز بازنویسی نمی‌شود.\nنام یا مسیر دیگری انتخاب کنید.");
            return;
        }

        view.FlushSave();
        IsEnabled = false;
        Mouse.OverrideCursor = Cursors.Wait;
        try
        {
            var progress = new Progress<(int Done, int Total)>(p =>
                StatusText.Text = $"خروجی PDF: صفحه {p.Done} از {p.Total}…");
            await ExportService.ExportAsync(view.Source, _db, view.DocId, dlg.FileName, progress, CancellationToken.None);
            StatusText.Text = "خروجی ساخته شد ✓";
            Dialogs.Info(this, "فایل PDF با موفقیت ساخته شد:\n" + dlg.FileName +
                "\n\nتوجه: در این نسخه هر صفحه به‌صورت تصویر ذخیره می‌شود (متن قابل جست‌وجوی PDF اصلی در خروجی نیست).");
        }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            StatusText.Text = "";
            Dialogs.Error(this, "ساخت PDF ناموفق بود:\n" + ex.Message);
        }
        finally
        {
            Mouse.OverrideCursor = null;
            IsEnabled = true;
        }
    }

    private void Backup_Click(object s, RoutedEventArgs e)
    {
        if (_db == null) return;
        var dlg = new SaveFileDialog
        {
            Title = "نسخه پشتیبان از همه یادداشت‌ها",
            Filter = "پشتیبان درس‌یار|*.db",
            FileName = $"DarsYar-backup-{DateTime.Now:yyyyMMdd-HHmm}.db"
        };
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            foreach (TabItem t in Tabs.Items) (t.Content as DocumentView)?.FlushSave();
            _db.BackupTo(dlg.FileName);
            Dialogs.Info(this, "نسخه پشتیبان ساخته شد:\n" + dlg.FileName);
        }
        catch (Exception ex)
        {
            AppPaths.LogError(ex);
            Dialogs.Error(this, "پشتیبان‌گیری ناموفق بود:\n" + ex.Message);
        }
    }

    // ------------------------------------------------------------ tools

    private void Tool_Checked(object s, RoutedEventArgs e)
    {
        if (s is RadioButton { Tag: string tag } && Enum.TryParse<Tool>(tag, out var t))
            ToolState.Instance.SetTool(t);
    }

    private void Thickness_Changed(object s, RoutedPropertyChangedEventArgs<double> e)
    {
        if (IsLoaded) ToolState.Instance.SetThickness(e.NewValue);
    }

    private void TouchInk_Changed(object s, RoutedEventArgs e) =>
        ToolState.Instance.SetAllowTouchInk(TouchInkBox.IsChecked == true);

    private void Undo_Click(object s, RoutedEventArgs e) => CurrentView?.Undo();
    private void Redo_Click(object s, RoutedEventArgs e) => CurrentView?.Redo();
    private void DeleteSel_Click(object s, RoutedEventArgs e) => CurrentView?.DeleteSelection();

    private void Theme_Click(object s, RoutedEventArgs e)
    {
        _dark = !_dark;
        ThemeManager.Apply(_dark);
    }

    private void Window_PreviewKeyDown(object s, KeyEventArgs e)
    {
        bool ctrl = Keyboard.Modifiers == ModifierKeys.Control;
        bool typing = Keyboard.FocusedElement is TextBox;

        if (ctrl && e.Key == Key.O) { Open_Click(s, e); e.Handled = true; }
        else if (ctrl && e.Key == Key.S) { Save_Click(s, e); e.Handled = true; }
        else if (ctrl && !typing && e.Key == Key.Z) { CurrentView?.Undo(); e.Handled = true; }
        else if (ctrl && !typing && e.Key == Key.Y) { CurrentView?.Redo(); e.Handled = true; }
        else if (!typing && e.Key == Key.Delete) { CurrentView?.DeleteSelection(); e.Handled = true; }
        else if (!typing && e.Key == Key.PageDown) { CurrentView?.NextPage(); e.Handled = true; }
        else if (!typing && e.Key == Key.PageUp) { CurrentView?.PrevPage(); e.Handled = true; }
    }

    private void Window_Closing(object? s, System.ComponentModel.CancelEventArgs e)
    {
        // Flush everything synchronously: nothing is lost on close.
        foreach (TabItem t in Tabs.Items)
        {
            try { (t.Content as DocumentView)?.CloseDocument(); }
            catch (Exception ex) { AppPaths.LogError(ex); }
        }
        Database.ClearPools();
    }
}
