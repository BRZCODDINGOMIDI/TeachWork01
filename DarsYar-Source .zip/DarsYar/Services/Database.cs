using System.Globalization;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;

namespace DarsYar.Services;

/// <summary>
/// Local SQLite storage. Annotations live here; the original document is never modified.
/// Thread-safe (single lock). WAL mode so an abrupt close does not corrupt saved data.
/// </summary>
public sealed class Database
{
    private readonly string _cs;
    private readonly object _gate = new();
    public string DbPath { get; }

    public Database(string dbPath)
    {
        DbPath = dbPath;
        var dir = Path.GetDirectoryName(dbPath);
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
        _cs = new SqliteConnectionStringBuilder
        {
            DataSource = dbPath,
            Mode = SqliteOpenMode.ReadWriteCreate
        }.ToString();
        Init();
    }

    private SqliteConnection Open()
    {
        var c = new SqliteConnection(_cs);
        c.Open();
        return c;
    }

    private static void Exec(SqliteConnection c, string sql)
    {
        using var cmd = c.CreateCommand();
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }

    private void Init()
    {
        lock (_gate)
        {
            using var c = Open();
            Exec(c, "PRAGMA journal_mode=WAL;");
            Exec(c, "PRAGMA synchronous=NORMAL;");
            Exec(c, @"
CREATE TABLE IF NOT EXISTS documents(
  id            TEXT PRIMARY KEY,
  path          TEXT NOT NULL,
  type          TEXT NOT NULL,
  created_utc   TEXT NOT NULL,
  last_used_utc TEXT NOT NULL,
  last_page     INTEGER NOT NULL DEFAULT 0,
  last_zoom     REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS page_annotations(
  doc_id      TEXT NOT NULL,
  page        INTEGER NOT NULL,
  ink         BLOB,
  notes       TEXT,
  updated_utc TEXT NOT NULL,
  PRIMARY KEY(doc_id, page)
);
PRAGMA user_version=1;");
        }
    }

    public static void ClearPools() => SqliteConnection.ClearAllPools();

    /// <summary>
    /// Stable document identity: SHA-256 of (length + first 1 MB). Moving/renaming a file keeps its notes.
    /// </summary>
    public static string ComputeFileId(string path)
    {
        using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        long len = fs.Length;
        int want = (int)Math.Min(1 << 20, len);
        var buf = new byte[8 + want];
        BitConverter.GetBytes(len).CopyTo(buf, 0);
        int read = 0;
        while (read < want)
        {
            int n = fs.Read(buf, 8 + read, want - read);
            if (n == 0) break;
            read += n;
        }
        return Convert.ToHexString(SHA256.HashData(buf.AsSpan(0, 8 + read)));
    }

    private static string Now() => DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture);

    private static DateTime ParseDate(string s) =>
        DateTime.Parse(s, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);

    public DocumentRecord OpenDocument(string id, string path, string type)
    {
        lock (_gate)
        {
            using var c = Open();
            using (var sel = c.CreateCommand())
            {
                sel.CommandText = "SELECT last_page, last_zoom FROM documents WHERE id=$id";
                sel.Parameters.AddWithValue("$id", id);
                using var r = sel.ExecuteReader();
                if (r.Read())
                {
                    int page = r.GetInt32(0);
                    double zoom = r.GetDouble(1);
                    r.Close();
                    using var upd = c.CreateCommand();
                    upd.CommandText = "UPDATE documents SET path=$p, type=$t, last_used_utc=$u WHERE id=$id";
                    upd.Parameters.AddWithValue("$p", path);
                    upd.Parameters.AddWithValue("$t", type);
                    upd.Parameters.AddWithValue("$u", Now());
                    upd.Parameters.AddWithValue("$id", id);
                    upd.ExecuteNonQuery();
                    return new DocumentRecord(id, path, type, DateTime.UtcNow, page, zoom);
                }
            }
            using var ins = c.CreateCommand();
            ins.CommandText = "INSERT INTO documents(id,path,type,created_utc,last_used_utc) VALUES($id,$p,$t,$n,$n)";
            ins.Parameters.AddWithValue("$id", id);
            ins.Parameters.AddWithValue("$p", path);
            ins.Parameters.AddWithValue("$t", type);
            ins.Parameters.AddWithValue("$n", Now());
            ins.ExecuteNonQuery();
            return new DocumentRecord(id, path, type, DateTime.UtcNow, 0, 0);
        }
    }

    public void SavePosition(string id, int page, double zoom)
    {
        lock (_gate)
        {
            using var c = Open();
            using var cmd = c.CreateCommand();
            cmd.CommandText = "UPDATE documents SET last_page=$pg, last_zoom=$z, last_used_utc=$u WHERE id=$id";
            cmd.Parameters.AddWithValue("$pg", page);
            cmd.Parameters.AddWithValue("$z", zoom);
            cmd.Parameters.AddWithValue("$u", Now());
            cmd.Parameters.AddWithValue("$id", id);
            cmd.ExecuteNonQuery();
        }
    }

    /// <summary>Stores a page's ink (ISF bytes) and notes (JSON). Both empty -> row removed.</summary>
    public void SavePage(string id, int page, byte[]? ink, string? notesJson)
    {
        lock (_gate)
        {
            using var c = Open();
            using var cmd = c.CreateCommand();
            if ((ink == null || ink.Length == 0) && string.IsNullOrEmpty(notesJson))
            {
                cmd.CommandText = "DELETE FROM page_annotations WHERE doc_id=$id AND page=$pg";
                cmd.Parameters.AddWithValue("$id", id);
                cmd.Parameters.AddWithValue("$pg", page);
                cmd.ExecuteNonQuery();
                return;
            }
            cmd.CommandText = @"
INSERT INTO page_annotations(doc_id,page,ink,notes,updated_utc) VALUES($id,$pg,$ink,$notes,$u)
ON CONFLICT(doc_id,page) DO UPDATE SET ink=excluded.ink, notes=excluded.notes, updated_utc=excluded.updated_utc";
            cmd.Parameters.AddWithValue("$id", id);
            cmd.Parameters.AddWithValue("$pg", page);
            cmd.Parameters.AddWithValue("$ink", (object?)ink ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$notes", (object?)notesJson ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$u", Now());
            cmd.ExecuteNonQuery();
        }
    }

    public (byte[]? Ink, string? Notes) LoadPage(string id, int page)
    {
        lock (_gate)
        {
            using var c = Open();
            using var cmd = c.CreateCommand();
            cmd.CommandText = "SELECT ink, notes FROM page_annotations WHERE doc_id=$id AND page=$pg";
            cmd.Parameters.AddWithValue("$id", id);
            cmd.Parameters.AddWithValue("$pg", page);
            using var r = cmd.ExecuteReader();
            if (!r.Read()) return (null, null);
            byte[]? ink = r.IsDBNull(0) ? null : (byte[])r.GetValue(0);
            string? notes = r.IsDBNull(1) ? null : r.GetString(1);
            return (ink, notes);
        }
    }

    public int CountAnnotatedPages(string id)
    {
        lock (_gate)
        {
            using var c = Open();
            using var cmd = c.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM page_annotations WHERE doc_id=$id";
            cmd.Parameters.AddWithValue("$id", id);
            return Convert.ToInt32(cmd.ExecuteScalar(), CultureInfo.InvariantCulture);
        }
    }

    public List<DocumentRecord> Recent(int count)
    {
        lock (_gate)
        {
            var list = new List<DocumentRecord>();
            using var c = Open();
            using var cmd = c.CreateCommand();
            cmd.CommandText = "SELECT id,path,type,last_used_utc,last_page,last_zoom FROM documents ORDER BY last_used_utc DESC LIMIT $n";
            cmd.Parameters.AddWithValue("$n", count);
            using var r = cmd.ExecuteReader();
            while (r.Read())
                list.Add(new DocumentRecord(r.GetString(0), r.GetString(1), r.GetString(2),
                    ParseDate(r.GetString(3)), r.GetInt32(4), r.GetDouble(5)));
            return list;
        }
    }

    /// <summary>Consistent backup copy of the whole database (VACUUM INTO).</summary>
    public void BackupTo(string destPath)
    {
        lock (_gate)
        {
            if (File.Exists(destPath)) File.Delete(destPath);
            using var c = Open();
            Exec(c, "VACUUM INTO '" + destPath.Replace("'", "''") + "'");
        }
    }
}
