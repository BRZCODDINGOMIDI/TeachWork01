using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Ink;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DarsYar.Services;

/// <summary>
/// Builds a NEW pdf: every page = original page + ink + notes, flattened to a JPEG image.
/// The original file is never opened for writing. Must run on the UI thread (WPF rendering).
/// </summary>
public static class ExportService
{
    /// <summary>Render scale relative to 96-dpi page size. 2.5 ≈ 240 dpi.</summary>
    public const double PageScale = 2.5;
    public const int JpegQuality = 88;

    public static async Task ExportAsync(
        DocumentSource source, Database db, string docId, string destPath,
        IProgress<(int Done, int Total)>? progress, CancellationToken ct)
    {
        string tmp = destPath + ".tmp";
        try
        {
            using (var fs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                var writer = new SimplePdfWriter(fs);
                int n = source.PageCount;
                for (int i = 0; i < n; i++)
                {
                    ct.ThrowIfCancellationRequested();
                    var size = await source.GetPageSizeAsync(i);
                    var bg = await source.RenderAsync(i, PageScale);
                    var (ink, notes) = db.LoadPage(docId, i);

                    int pw = Math.Max(1, (int)Math.Round(size.Width * PageScale));
                    int ph = Math.Max(1, (int)Math.Round(size.Height * PageScale));
                    byte[] jpeg = ComposePage(bg, size, pw, ph, ink, notes);
                    writer.AddJpegPage(jpeg, pw, ph, size.Width * 0.75, size.Height * 0.75);

                    progress?.Report((i + 1, n));
                    await Task.Delay(1, ct); // let the UI breathe
                }
                writer.Finish();
            }
            File.Move(tmp, destPath, true);
        }
        catch
        {
            try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
            throw;
        }
    }

    private static byte[] ComposePage(BitmapSource bg, Size size, int pw, int ph, byte[]? ink, string? notesJson)
    {
        var dv = new DrawingVisual();
        using (var dc = dv.RenderOpen())
        {
            var rect = new Rect(0, 0, size.Width, size.Height);
            dc.DrawRectangle(Brushes.White, null, rect);
            dc.DrawImage(bg, rect);

            if (ink != null && ink.Length > 0)
            {
                using var ms = new MemoryStream(ink);
                new StrokeCollection(ms).Draw(dc);
            }

            if (!string.IsNullOrEmpty(notesJson))
            {
                var notes = JsonSerializer.Deserialize<List<NoteItem>>(notesJson) ?? new();
                foreach (var n in notes) DrawNote(dc, n);
            }
        }

        double dpiX = 96.0 * pw / size.Width;
        double dpiY = 96.0 * ph / size.Height;
        var rtb = new RenderTargetBitmap(pw, ph, dpiX, dpiY, PixelFormats.Pbgra32);
        rtb.Render(dv);

        var enc = new JpegBitmapEncoder { QualityLevel = JpegQuality };
        enc.Frames.Add(BitmapFrame.Create(rtb));
        using var o = new MemoryStream();
        enc.Save(o);
        return o.ToArray();
    }

    private static void DrawNote(DrawingContext dc, NoteItem n)
    {
        double w = n.W > 0 ? n.W : 200;
        var ft = new FormattedText(
            n.Text ?? "", CultureInfo.GetCultureInfo("fa-IR"), FlowDirection.RightToLeft,
            new Typeface("Segoe UI"), 16, Brushes.Black, 1.0)
        {
            MaxTextWidth = Math.Max(40, w - 12),
            TextAlignment = TextAlignment.Right
        };
        double top = n.Y + NoteItem.HeaderHeight;
        var box = new Rect(n.X, top, w, ft.Height + 12);
        dc.DrawRectangle(new SolidColorBrush(Color.FromRgb(255, 249, 196)),
            new Pen(new SolidColorBrush(Color.FromRgb(212, 175, 55)), 1), box);
        dc.DrawText(ft, new Point(n.X + 6, top + 6));
    }
}
