using System.ComponentModel;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DarsYar;

public enum Tool { Pen, Highlighter, Eraser, Select, Line, Arrow, Rectangle, Note }

/// <summary>Shared tool settings (singleton). Views subscribe to Changed.</summary>
public sealed class ToolState
{
    public static ToolState Instance { get; } = new();

    public Tool Tool { get; private set; } = Tool.Pen;
    public Color PenColor { get; private set; } = Colors.Black;
    public Color HighlighterColor { get; private set; } = Colors.Yellow;
    public double Thickness { get; private set; } = 3;
    public bool AllowTouchInk { get; private set; }

    public event Action? Changed;

    public void SetTool(Tool t) { Tool = t; Changed?.Invoke(); }

    public void SetColor(Color c)
    {
        if (Tool == Tool.Highlighter) HighlighterColor = c; else PenColor = c;
        Changed?.Invoke();
    }

    public void SetThickness(double v) { Thickness = v; Changed?.Invoke(); }
    public void SetAllowTouchInk(bool v) { AllowTouchInk = v; Changed?.Invoke(); }
}

/// <summary>A text note, stored in stable page coordinates (96-dpi units at zoom 1).</summary>
public sealed class NoteItem
{
    public double X { get; set; }
    public double Y { get; set; }
    public double W { get; set; }
    public string Text { get; set; } = "";

    public const double HeaderHeight = 24;
}

public sealed record DocumentRecord(string Id, string Path, string Type, DateTime LastUsed, int LastPage, double LastZoom);

public sealed class ThumbItem : INotifyPropertyChanged
{
    private BitmapSource? _image;
    public int Index { get; init; }
    public string Label { get; init; } = "";
    public BitmapSource? Image
    {
        get => _image;
        set { _image = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Image))); }
    }
    public event PropertyChangedEventHandler? PropertyChanged;
}
